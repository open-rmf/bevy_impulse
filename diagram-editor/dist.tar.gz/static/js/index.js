(() => { // webpackBootstrap
"use strict";
var __webpack_modules__ = ({
23: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
// extracted by css-extract-rspack-plugin


}),
143: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(439);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(678);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(713);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _editor_mode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(144);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(147);
/* ESM import */var _utils_add_operation_catalog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(701);
/* ESM import */var _utils_namespace__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(671);








const StyledOperationButton = (0,_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"])(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"])({
    justifyContent: 'flex-start'
});
function AddOperation(param) {
    let { parentId, newNodePosition, onAdd } = param;
    const [editorMode] = (0,_editor_mode__WEBPACK_IMPORTED_MODULE_2__.useEditorMode)();
    const nodeManager = (0,_node_manager__WEBPACK_IMPORTED_MODULE_3__.useNodeManager)();
    const [search, setSearch] = react__WEBPACK_IMPORTED_MODULE_1___default().useState('');
    const namespace = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        const parentNode = parentId && nodeManager.tryGetNode(parentId);
        if (!parentNode || !(0,_nodes__WEBPACK_IMPORTED_MODULE_4__.isOperationNode)(parentNode)) {
            return _utils_namespace__WEBPACK_IMPORTED_MODULE_6__.ROOT_NAMESPACE;
        }
        return (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_6__.joinNamespaces)(parentNode.data.namespace, parentNode.data.opId);
    }, [
        parentId,
        nodeManager
    ]);
    const compatibleOperations = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        return (0,_utils_add_operation_catalog__WEBPACK_IMPORTED_MODULE_5__.getVisibleAddOperations)({
            isTemplateMode: editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_2__.EditorMode.Template,
            namespace
        });
    }, [
        editorMode.mode,
        namespace
    ]);
    const operations = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        const trimmedSearch = search.trim().toLowerCase();
        if (!trimmedSearch) {
            return compatibleOperations;
        }
        return compatibleOperations.filter((operation)=>operation.label.toLowerCase().includes(trimmedSearch));
    }, [
        compatibleOperations,
        search
    ]);
    const emptyMessage = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        if (operations.length > 0) {
            return null;
        }
        return search.trim() ? 'No operations match this filter.' : 'No operations are available here yet.';
    }, [
        operations.length,
        search
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
        spacing: 1,
        sx: {
            px: 1.5,
            pt: 1.5,
            pb: 1.5,
            width: 260
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                variant: "subtitle2",
                children: "Add operation"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                size: "small",
                placeholder: "Filter operations",
                value: search,
                onChange: (event)=>setSearch(event.target.value)
            }),
            operations.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                orientation: "vertical",
                variant: "contained",
                size: "small",
                "aria-label": "Add operation button group",
                sx: {
                    width: '100%'
                },
                children: operations.map((operation)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(StyledOperationButton, {
                        startIcon: (0,_nodes__WEBPACK_IMPORTED_MODULE_4__.getAddOperationIcon)(operation.key),
                        onClick: ()=>{
                            var _changes_;
                            const changes = operation.createChanges({
                                namespace,
                                parentId,
                                newNodePosition,
                                nodeManager
                            });
                            const primaryNodeId = (_changes_ = changes[0]) === null || _changes_ === void 0 ? void 0 : _changes_.item.id;
                            if (!primaryNodeId) {
                                return;
                            }
                            onAdd === null || onAdd === void 0 ? void 0 : onAdd({
                                changes,
                                primaryNodeId
                            });
                        },
                        children: operation.label
                    }, operation.key))
            }),
            emptyMessage && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                variant: "body2",
                children: emptyMessage
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddOperation);


}),
151: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ApiClientProvider: () => (ApiClientProvider),
  useApiClient: () => (useApiClient)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _api_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(152);



const ApiClientContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(new _api_client__WEBPACK_IMPORTED_MODULE_2__.ApiClient());
function ApiClientProvider(param) {
    let { value, children } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ApiClientContext.Provider, {
        value: value,
        children: children
    });
}
const useApiClient = ()=>{
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(ApiClientContext);
};


}),
153: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ApiClient: () => (/* reexport safe */ _rest_client_ts__WEBPACK_IMPORTED_MODULE_0__.ApiClient)
});
/* ESM import */var _rest_client_ts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(154);



}),
296: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);



}),
152: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ApiClient: () => (/* reexport safe */ _api_client__WEBPACK_IMPORTED_MODULE_0__.ApiClient),
  InteractionSession: () => (/* reexport safe */ _interaction_session__WEBPACK_IMPORTED_MODULE_2__.InteractionSession)
});
/* ESM import */var _api_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(153);
/* ESM import */var _base_api_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(296);
/* ESM import */var _interaction_session__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(252);





}),
252: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  InteractionSession: () => (InteractionSession)
});
/* ESM import */var _swc_helpers_define_property__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(146);
/* ESM import */var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(253);
/* ESM import */var _utils_ajv__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(155);



const validateInteractionSessionMessage = (0,_utils_ajv__WEBPACK_IMPORTED_MODULE_0__.getSchema)('InteractionSessionMessage');
class InteractionSession {
    close() {
        if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING) {
            this.ws.close();
        }
    }
    constructor(ws){
        (0,_swc_helpers_define_property__WEBPACK_IMPORTED_MODULE_1__._)(this, "interactionMessages$", void 0);
        (0,_swc_helpers_define_property__WEBPACK_IMPORTED_MODULE_1__._)(this, "interactionMessagesSubject$", void 0);
        (0,_swc_helpers_define_property__WEBPACK_IMPORTED_MODULE_1__._)(this, "ws", void 0);
        this.ws = ws;
        this.interactionMessagesSubject$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.ReplaySubject(1000);
        ws.onmessage = (ev)=>{
            try {
                const msg = JSON.parse(ev.data);
                if (!validateInteractionSessionMessage(msg)) {
                    console.error(validateInteractionSessionMessage.errors);
                    return;
                }
                this.interactionMessagesSubject$.next(msg);
            } catch (e) {
                console.error(e.message);
            }
        };
        ws.onerror = ()=>{
            this.interactionMessagesSubject$.error(new Error('interaction websocket error'));
        };
        ws.onclose = ()=>{
            this.interactionMessagesSubject$.complete();
        };
        this.interactionMessages$ = this.interactionMessagesSubject$;
    }
}


}),
154: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ApiClient: () => (ApiClient)
});
/* ESM import */var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(274);
/* ESM import */var _utils_ajv__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(155);
/* ESM import */var _interaction_session__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(252);



const validateRegistry = (0,_utils_ajv__WEBPACK_IMPORTED_MODULE_0__.getSchema)('DiagramElementMetadata');
async function getErrorMessage(response) {
    const text = await response.text();
    return text || `${response.status} ${response.statusText}`;
}
class ApiClient {
    getRegistry() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.from)((async ()=>{
            const response = await fetch('/api/registry');
            if (!response.ok) {
                throw new Error(await getErrorMessage(response));
            }
            const data = await response.json();
            if (!validateRegistry(data)) {
                throw validateRegistry.errors;
            }
            return data;
        })());
    }
    postRunWorkflow(diagram, request) {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.from)((async ()=>{
            const body = {
                diagram,
                request
            };
            const response = await fetch('/api/executor/run', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });
            if (!response.ok) {
                throw new Error(await getErrorMessage(response));
            }
            return response.json();
        })());
    }
    checkCompatibility(request) {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.from)((async ()=>{
            const response = await fetch('/api/executor/compatibility', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(request)
            });
            if (!response.ok) {
                throw new Error(await getErrorMessage(response));
            }
            return response.json();
        })());
    }
    async wsInteractWithWorkflow(diagram, request) {
        const url = new URL('/api/executor/interaction', window.location.href);
        url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
        const ws = new WebSocket(url);
        return new Promise((resolve, reject)=>{
            ws.onopen = ()=>{
                const session = new _interaction_session__WEBPACK_IMPORTED_MODULE_1__.InteractionSession(ws);
                const body = {
                    diagram,
                    request
                };
                ws.send(JSON.stringify(body));
                resolve(session);
            };
            ws.onerror = ()=>reject(new Error('interaction websocket error'));
        });
    }
}


}),
17: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _fontsource_roboto_300_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18);
/* ESM import */var _fontsource_roboto_400_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19);
/* ESM import */var _fontsource_roboto_500_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20);
/* ESM import */var _fontsource_roboto_700_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21);
/* ESM import */var _xyflow_react_dist_style_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(348);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1201);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1214);
/* ESM import */var _app_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23);
/* ESM import */var _diagram_editor__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(24);
/* ESM import */var _diagram_properties_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(691);
/* ESM import */var _diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(769);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(321);
/* ESM import */var _templates_provider__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(459);
/* ESM import */var _transient_editor_drafts__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(845);














const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"])({
    palette: {
        mode: 'dark'
    },
    cssVariables: true
});
const App = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
        theme: theme,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                enableColorScheme: true
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    width: '100vw',
                    height: '100vh'
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_registry_provider__WEBPACK_IMPORTED_MODULE_10__.RegistryProvider, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_transient_editor_drafts__WEBPACK_IMPORTED_MODULE_12__.TransientEditorDraftProvider, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_templates_provider__WEBPACK_IMPORTED_MODULE_11__.TemplatesProvider, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_8__.DiagramPropertiesProvider, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_9__.DiagramSidePanelProvider, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_diagram_editor__WEBPACK_IMPORTED_MODULE_7__["default"], {})
                                })
                            })
                        })
                    })
                })
            })
        ]
    });
};
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);


}),
717: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(766);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(678);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(147);
/* ESM import */var _utils_auto_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(718);
/* ESM import */var _utils_layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(677);







const nodesEdgesSelector = (state)=>({
        nodes: state.nodes,
        edges: state.edges
    });
function AutoLayoutButton(param) {
    let { onNodeChanges } = param;
    const { nodes, edges } = (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_5__.useStore)(nodesEdgesSelector);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
        title: "Auto Layout",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
            onClick: ()=>{
                const changes = (0,_utils_auto_layout__WEBPACK_IMPORTED_MODULE_3__.autoLayout)(nodes, edges, _utils_layout__WEBPACK_IMPORTED_MODULE_4__.LAYOUT_OPTIONS);
                onNodeChanges(changes);
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_2__.MaterialSymbol, {
                symbol: "dashboard"
            })
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(AutoLayoutButton));


}),
716: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(439);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(437);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(713);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(766);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(678);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _auto_layout_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(717);
/* ESM import */var _diagram_side_panel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(768);
/* ESM import */var _diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(769);
/* ESM import */var _edit_templates_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(844);
/* ESM import */var _editor_mode__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(144);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(147);
/* ESM import */var _transient_editor_drafts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(845);











const VisuallyHiddenInput = (0,_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"])('input')({
    clip: 'rect(0 0 0 0)',
    clipPath: 'inset(50%)',
    height: 1,
    overflow: 'hidden',
    position: 'absolute',
    bottom: 0,
    left: 0,
    whiteSpace: 'nowrap',
    width: 1
});
function CommandPanel(param) {
    let { onNodeChanges, onNewDiagram, onExportClick, onLoadDiagram, enableExport, exportDisabledReason, isDirty, scriptNodeBinding } = param;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"])();
    const [openEditTemplatesDialog, setOpenEditTemplatesDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [runRequestJson, setRunRequestJson] = react__WEBPACK_IMPORTED_MODULE_1___default().useState('');
    const [editorMode] = (0,_editor_mode__WEBPACK_IMPORTED_MODULE_6__.useEditorMode)();
    const { drafts } = (0,_transient_editor_drafts__WEBPACK_IMPORTED_MODULE_8__.useTransientEditorDrafts)();
    const { state: { open: openSidePanel, tab: sidePanelTab }, toggleTab } = (0,_diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_4__.useDiagramSidePanel)();
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (drafts.templateRename) {
            setOpenEditTemplatesDialog(true);
        }
    }, [
        drafts.templateRename
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_11__.Panel, {
                position: "top-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                    variant: "contained",
                    children: [
                        editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_6__.EditorMode.Normal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                            title: isDirty ? 'New Diagram (unsaved changes)' : 'New Diagram',
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                onClick: onNewDiagram,
                                "aria-label": "new diagram",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_7__.MaterialSymbol, {
                                    symbol: "note_add"
                                })
                            })
                        }),
                        editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_6__.EditorMode.Normal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                            title: "Run Workflow",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                onClick: ()=>toggleTab('run'),
                                sx: openSidePanel && sidePanelTab === 'run' ? {
                                    backgroundColor: theme.palette.primary.light
                                } : undefined,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_7__.MaterialSymbol, {
                                    symbol: "play_arrow"
                                })
                            })
                        }),
                        editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_6__.EditorMode.Normal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                            title: "Script Environment Manager",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                onClick: ()=>toggleTab('environments'),
                                sx: openSidePanel && sidePanelTab === 'environments' ? {
                                    backgroundColor: theme.palette.primary.light
                                } : undefined,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_7__.MaterialSymbol, {
                                    symbol: "code"
                                })
                            })
                        }),
                        editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_6__.EditorMode.Normal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                            title: "Diagram properties",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                onClick: ()=>toggleTab('properties'),
                                sx: openSidePanel && sidePanelTab === 'properties' ? {
                                    backgroundColor: theme.palette.primary.light
                                } : undefined,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_7__.MaterialSymbol, {
                                    symbol: "info"
                                })
                            })
                        }),
                        editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_6__.EditorMode.Normal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                            title: "Templates",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                onClick: ()=>setOpenEditTemplatesDialog(true),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_7__.MaterialSymbol, {
                                    symbol: "architecture"
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_auto_layout_button__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            onNodeChanges: onNodeChanges
                        }),
                        editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_6__.EditorMode.Normal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                            title: enableExport ? 'Export Diagram' : exportDisabledReason || 'Export Diagram (disabled)',
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                onClick: onExportClick,
                                disabled: !enableExport,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_7__.MaterialSymbol, {
                                    symbol: "download"
                                })
                            })
                        }),
                        editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_6__.EditorMode.Normal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                            title: "Load Diagram",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                component: "label",
                                role: undefined,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_7__.MaterialSymbol, {
                                        symbol: "upload_file"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(VisuallyHiddenInput, {
                                        type: "file",
                                        accept: "application/json",
                                        "aria-label": "load diagram",
                                        onChange: async (ev)=>{
                                            if (ev.target.files) {
                                                const json = await ev.target.files[0].text();
                                                onLoadDiagram(json, ev.target.files[0].name);
                                            }
                                        },
                                        onClick: (ev)=>{
                                            // Reset the input value so that the same file can be loaded multiple times
                                            ev.target.value = '';
                                        }
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_edit_templates_dialog__WEBPACK_IMPORTED_MODULE_5__["default"], {
                open: openEditTemplatesDialog,
                onClose: ()=>setOpenEditTemplatesDialog(false)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_diagram_side_panel__WEBPACK_IMPORTED_MODULE_3__["default"], {
                runRequestJson: runRequestJson,
                onRunRequestJsonChange: setRunRequestJson,
                scriptNodeBinding: scriptNodeBinding
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(CommandPanel));


}),
847: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  CompatibleAddOperation: () => (CompatibleAddOperation)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(439);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(678);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(713);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(150);
/* ESM import */var _editor_mode__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(144);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(147);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(321);
/* ESM import */var _utils_add_operation_catalog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(701);
/* ESM import */var _utils_connection__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(298);
/* ESM import */var _utils_namespace__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(671);











const StyledOperationButton = (0,_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"])(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"])({
    justifyContent: 'flex-start'
});
function CompatibleAddOperation(param) {
    let { parentId, newNodePosition, sourceConnection, onAdd, onContentChange } = param;
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_6__.useRegistry)();
    const nodeManager = (0,_node_manager__WEBPACK_IMPORTED_MODULE_4__.useNodeManager)();
    const { setMenuPreview } = (0,_connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_2__.useCompatibilityChecker)();
    const [editorMode] = (0,_editor_mode__WEBPACK_IMPORTED_MODULE_3__.useEditorMode)();
    const [search, setSearch] = react__WEBPACK_IMPORTED_MODULE_1___default().useState('');
    const [inspectedKey, setInspectedKey] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const namespace = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        const parentNode = parentId && nodeManager.tryGetNode(parentId);
        if (!parentNode || !(0,_nodes__WEBPACK_IMPORTED_MODULE_5__.isOperationNode)(parentNode)) {
            return _utils_namespace__WEBPACK_IMPORTED_MODULE_9__.ROOT_NAMESPACE;
        }
        return (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_9__.joinNamespaces)(parentNode.data.namespace, parentNode.data.opId);
    }, [
        parentId,
        nodeManager
    ]);
    const candidates = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        const sourceNode = nodeManager.tryGetNode(sourceConnection.sourceNodeId);
        if (!sourceNode) {
            return [];
        }
        const visibleBuiltins = (0,_utils_add_operation_catalog__WEBPACK_IMPORTED_MODULE_7__.getVisibleAddOperations)({
            isTemplateMode: editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_3__.EditorMode.Template,
            namespace
        });
        const allCandidates = (0,_utils_add_operation_catalog__WEBPACK_IMPORTED_MODULE_7__.getAddOperationCandidates)(registry, {
            includeGenericNode: false,
            includeRegistryNodes: true,
            includeBuiltins: true,
            builtins: visibleBuiltins
        });
        return (0,_utils_add_operation_catalog__WEBPACK_IMPORTED_MODULE_7__.filterCompatibleAddOperations)(allCandidates, sourceNode, sourceConnection.sourceHandle, {
            namespace,
            parentId
        }, sourceConnection.sourceHandleType);
    }, [
        editorMode.mode,
        namespace,
        nodeManager,
        parentId,
        registry,
        sourceConnection.sourceHandle,
        sourceConnection.sourceHandleType,
        sourceConnection.sourceNodeId
    ]);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        const candidate = candidates.find((param)=>{
            let { key } = param;
            return key === inspectedKey;
        });
        if (candidate) {
            var _nodeChanges_;
            const nodeChanges = candidate.createChanges({
                namespace,
                parentId,
                newNodePosition,
                nodeManager
            });
            const primaryNode = (_nodeChanges_ = nodeChanges[0]) === null || _nodeChanges_ === void 0 ? void 0 : _nodeChanges_.item;
            if (primaryNode) setMenuPreview({
                connection: (0,_utils_connection__WEBPACK_IMPORTED_MODULE_8__.createConnectionFromHandles)({
                    nodeId: sourceConnection.sourceNodeId,
                    id: sourceConnection.sourceHandle,
                    type: sourceConnection.sourceHandleType
                }, primaryNode.id, null),
                nodeChanges
            });
        } else setMenuPreview(null);
        return ()=>setMenuPreview(null);
    }, [
        candidates,
        inspectedKey,
        namespace,
        parentId,
        newNodePosition,
        nodeManager,
        sourceConnection,
        setMenuPreview
    ]);
    const operations = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        const trimmedSearch = search.trim().toLowerCase();
        if (!trimmedSearch) {
            return candidates;
        }
        return candidates.filter((operation)=>operation.label.toLowerCase().includes(trimmedSearch));
    }, [
        candidates,
        search
    ]);
    const title = sourceConnection.sourceHandleType === 'target' ? 'Add previous operation' : 'Add next operation';
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (operations) {
            onContentChange === null || onContentChange === void 0 ? void 0 : onContentChange();
        }
    }, [
        onContentChange,
        operations
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
        spacing: 1,
        sx: {
            px: 1.5,
            pt: 1.5,
            pb: 1.5,
            width: 260
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                variant: "subtitle2",
                children: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                size: "small",
                placeholder: "Filter operations",
                value: search,
                onChange: (event)=>setSearch(event.target.value)
            }),
            operations.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                orientation: "vertical",
                variant: "contained",
                size: "small",
                "aria-label": "Add operation button group",
                sx: {
                    width: '100%'
                },
                children: operations.map((operation)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(StyledOperationButton, {
                        startIcon: (0,_nodes__WEBPACK_IMPORTED_MODULE_5__.getAddOperationIcon)(operation.key),
                        onMouseEnter: ()=>setInspectedKey(operation.key),
                        onMouseLeave: ()=>setInspectedKey(null),
                        onFocus: ()=>setInspectedKey(operation.key),
                        onBlur: ()=>setInspectedKey(null),
                        onClick: ()=>{
                            var _changes_;
                            const changes = operation.createChanges({
                                namespace,
                                parentId,
                                newNodePosition,
                                nodeManager
                            });
                            const primaryNodeId = (_changes_ = changes[0]) === null || _changes_ === void 0 ? void 0 : _changes_.item.id;
                            if (!primaryNodeId) {
                                return;
                            }
                            onAdd === null || onAdd === void 0 ? void 0 : onAdd({
                                changes,
                                primaryNodeId
                            });
                        },
                        children: operation.label
                    }, operation.key))
            }),
            operations.length === 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                variant: "body2",
                children: search.trim() ? 'No operations match this filter.' : 'No operations are available here yet.'
            })
        ]
    });
}


}),
150: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ConnectionCompatibilityProvider: () => (ConnectionCompatibilityProvider),
  useCompatibilityChecker: () => (useCompatibilityChecker),
  useCompatibilityGraph: () => (useCompatibilityGraph),
  useConnectionCompatibility: () => (useConnectionCompatibility),
  useDraggedConnectionCompatibility: () => (useDraggedConnectionCompatibility)
});
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* ESM import */var _api_client_provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(151);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(145);
/* ESM import */var _utils_compatibility__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(297);
/* ESM import */var _utils_connection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(298);






const EMPTY_RESULTS = new Map();
function unknownResult(id, error) {
    return {
        id,
        status: 'unknown',
        reason: String(error)
    };
}
function useCompatibilityGraph(graph, reconnectingEdgeId) {
    const apiClient = (0,_api_client_provider__WEBPACK_IMPORTED_MODULE_1__.useApiClient)();
    // Layout and UI state do not change the workflow's types.
    const serialized = JSON.stringify({
        templateId: graph.templateId,
        registry: graph.registry,
        nodes: graph.nodeManager.nodes.map((param)=>{
            let { id, type, parentId, data } = param;
            return {
                id,
                type,
                parentId,
                data
            };
        }),
        edges: graph.edges.map((param)=>{
            let { id, type, source, target, sourceHandle, targetHandle, data } = param;
            return {
                id,
                type,
                source,
                target,
                sourceHandle,
                targetHandle,
                data
            };
        }),
        templates: graph.templates,
        diagramProperties: {
            script_environments: graph.diagramProperties.script_environments
        }
    });
    const snapshot = react__WEBPACK_IMPORTED_MODULE_0___default().useMemo(()=>{
        const { nodes, ...rest } = JSON.parse(serialized);
        return {
            ...rest,
            nodeManager: new _node_manager__WEBPACK_IMPORTED_MODULE_2__.NodeManager(nodes)
        };
    }, [
        serialized
    ]);
    const [diagnostics, setDiagnostics] = react__WEBPACK_IMPORTED_MODULE_0___default().useState();
    const [menuPreview, setMenuPreview] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(null);
    react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(()=>{
        if (snapshot.edges.length === 0) return;
        let active = true;
        const timer = setTimeout(async ()=>{
            let results;
            let localResults = [];
            try {
                const built = (0,_utils_compatibility__WEBPACK_IMPORTED_MODULE_3__.buildCompatibilityRequest)(snapshot);
                localResults = built.localResults;
                results = await (0,_utils_compatibility__WEBPACK_IMPORTED_MODULE_3__.checkCompatibility)(apiClient, built.request);
            } catch (error) {
                results = new Map(snapshot.edges.map((param)=>{
                    let { id } = param;
                    return [
                        id,
                        unknownResult(id, error)
                    ];
                }));
            }
            for (const result of localResults)results.set(result.id, result);
            if (active) setDiagnostics({
                snapshot,
                results
            });
        }, 150);
        return ()=>{
            active = false;
            clearTimeout(timer);
        };
    }, [
        snapshot,
        apiClient
    ]);
    // A cache belongs to one graph and reconnect operation, not to UI callers.
    const checkConnection = react__WEBPACK_IMPORTED_MODULE_0___default().useMemo(()=>{
        const cache = new Map();
        return (input)=>{
            const key = JSON.stringify(input);
            const cached = cache.get(key);
            if (cached) return cached;
            const pending = (async ()=>{
                try {
                    const built = (0,_utils_compatibility__WEBPACK_IMPORTED_MODULE_3__.buildConnectionPreview)({
                        ...snapshot,
                        ...input,
                        edgeId: reconnectingEdgeId
                    });
                    if (!built.request) return {
                        ...built.localResults[0],
                        blocked: true
                    };
                    const results = await (0,_utils_compatibility__WEBPACK_IMPORTED_MODULE_3__.checkCompatibility)(apiClient, built.request);
                    return results.get('preview');
                } catch (error) {
                    return unknownResult('preview', error);
                }
            })();
            cache.set(key, pending);
            return pending;
        };
    }, [
        snapshot,
        reconnectingEdgeId,
        apiClient
    ]);
    return react__WEBPACK_IMPORTED_MODULE_0___default().useMemo(()=>({
            edgeResults: (diagnostics === null || diagnostics === void 0 ? void 0 : diagnostics.snapshot) === snapshot ? diagnostics.results : EMPTY_RESULTS,
            checkConnection,
            menuPreview,
            setMenuPreview
        }), [
        diagnostics,
        snapshot,
        checkConnection,
        menuPreview
    ]);
}
const ConnectionCompatibilityContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createContext(null);
const ConnectionCompatibilityProvider = ConnectionCompatibilityContext.Provider;
function useCompatibilityChecker() {
    const context = react__WEBPACK_IMPORTED_MODULE_0___default().useContext(ConnectionCompatibilityContext);
    if (!context) throw new Error('Missing ConnectionCompatibilityProvider');
    return context;
}
function useConnectionCompatibility(connection, nodeChanges) {
    const context = react__WEBPACK_IMPORTED_MODULE_0___default().useContext(ConnectionCompatibilityContext);
    const checkConnection = context === null || context === void 0 ? void 0 : context.checkConnection;
    const [response, setResponse] = react__WEBPACK_IMPORTED_MODULE_0___default().useState();
    react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(()=>{
        if (!connection || !checkConnection) return;
        let active = true;
        checkConnection({
            connection,
            nodeChanges
        }).then((result)=>{
            if (active) setResponse({
                connection,
                nodeChanges,
                checker: checkConnection,
                result
            });
        });
        return ()=>{
            active = false;
        };
    }, [
        connection,
        nodeChanges,
        checkConnection
    ]);
    return (response === null || response === void 0 ? void 0 : response.connection) === connection && (response === null || response === void 0 ? void 0 : response.nodeChanges) === nodeChanges && (response === null || response === void 0 ? void 0 : response.checker) === checkConnection ? response.result : null;
}
function useDraggedConnectionCompatibility(param) {
    let { otherNodeId, otherHandleId, otherHandleType } = param;
    const { inProgress, fromHandle, toHandle } = (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_5__.useConnection)();
    const fromNodeId = fromHandle === null || fromHandle === void 0 ? void 0 : fromHandle.nodeId;
    const fromId = fromHandle === null || fromHandle === void 0 ? void 0 : fromHandle.id;
    const fromType = fromHandle === null || fromHandle === void 0 ? void 0 : fromHandle.type;
    const hovered = inProgress && (toHandle === null || toHandle === void 0 ? void 0 : toHandle.nodeId) === otherNodeId && ((toHandle === null || toHandle === void 0 ? void 0 : toHandle.id) || null) === (otherHandleId || null) && (toHandle === null || toHandle === void 0 ? void 0 : toHandle.type) === otherHandleType;
    const direction = fromType ? (0,_utils_connection__WEBPACK_IMPORTED_MODULE_4__.validateDraggedHandlePair)({
        fromHandleType: fromType,
        otherHandleType
    }) : {
        valid: true
    };
    const connection = react__WEBPACK_IMPORTED_MODULE_0___default().useMemo(()=>hovered && fromNodeId && fromType && otherNodeId && fromType !== otherHandleType ? (0,_utils_connection__WEBPACK_IMPORTED_MODULE_4__.createConnectionFromHandles)({
            nodeId: fromNodeId,
            id: fromId,
            type: fromType
        }, otherNodeId, otherHandleId) : null, [
        hovered,
        fromNodeId,
        fromId,
        fromType,
        otherNodeId,
        otherHandleId,
        otherHandleType
    ]);
    const result = useConnectionCompatibility(connection);
    return hovered && !direction.valid ? {
        id: 'preview',
        status: 'incompatible',
        reason: direction.error,
        blocked: true
    } : result;
}


}),
848: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ConnectionHintPanel: () => (ConnectionHintPanel)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(522);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(435);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(25);
/* ESM import */var _connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(150);
/* ESM import */var _interaction_visualization_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(676);
/* ESM import */var _use_edges__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(813);
/* ESM import */var _utils_connection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(298);







function ConnectionHintPanel(param) {
    let { nodeManager, reconnectingEdgeId, edgeResult } = param;
    var _connection_toHandle, _connection_toHandle1, _connection_toHandle2, _connection_fromHandle, _connection_fromHandle1;
    const connection = (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_5__.useConnection)();
    const edges = (0,_use_edges__WEBPACK_IMPORTED_MODULE_3__.useEdges)();
    const dragResult = (0,_connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_1__.useDraggedConnectionCompatibility)({
        otherNodeId: (_connection_toHandle = connection.toHandle) === null || _connection_toHandle === void 0 ? void 0 : _connection_toHandle.nodeId,
        otherHandleId: (_connection_toHandle1 = connection.toHandle) === null || _connection_toHandle1 === void 0 ? void 0 : _connection_toHandle1.id,
        otherHandleType: ((_connection_toHandle2 = connection.toHandle) === null || _connection_toHandle2 === void 0 ? void 0 : _connection_toHandle2.type) ?? 'target'
    });
    const { menuPreview } = (0,_connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_1__.useCompatibilityChecker)();
    const menuResult = (0,_connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_1__.useConnectionCompatibility)((menuPreview === null || menuPreview === void 0 ? void 0 : menuPreview.connection) ?? null, menuPreview === null || menuPreview === void 0 ? void 0 : menuPreview.nodeChanges);
    const { isWorkflowRunning } = (0,_interaction_visualization_provider__WEBPACK_IMPORTED_MODULE_2__.useInteractionVisualization)();
    if (isWorkflowRunning || !connection.inProgress && !menuPreview && !edgeResult) {
        return null;
    }
    const sourceNode = connection.fromHandle && nodeManager.tryGetNode(connection.fromHandle.nodeId);
    const sourceOutputCapacity = sourceNode && ((_connection_fromHandle = connection.fromHandle) === null || _connection_fromHandle === void 0 ? void 0 : _connection_fromHandle.type) === 'source' ? (0,_utils_connection__WEBPACK_IMPORTED_MODULE_4__.validateSourceOutputCapacity)(sourceNode, connection.fromHandle.id, edges, reconnectingEdgeId) : {
        valid: true
    };
    let message = !sourceOutputCapacity.valid ? sourceOutputCapacity.error : reconnectingEdgeId ? 'Drop on a port, or release on empty space to keep the original connection.' : ((_connection_fromHandle1 = connection.fromHandle) === null || _connection_fromHandle1 === void 0 ? void 0 : _connection_fromHandle1.type) === 'target' ? 'Drop on an output, or release on empty space to add a previous operation.' : 'Drop on an input, or release on empty space to add a next operation.';
    let tone = sourceOutputCapacity.valid ? 'info' : 'error';
    const previewing = connection.inProgress || !!menuPreview;
    const compatibility = connection.inProgress ? dragResult : menuPreview ? menuResult : edgeResult;
    if (connection.inProgress && connection.toHandle || menuPreview || edgeResult) {
        message = (compatibility === null || compatibility === void 0 ? void 0 : compatibility.reason) ?? "Checking compatibility\u2026";
        tone = (compatibility === null || compatibility === void 0 ? void 0 : compatibility.status) === 'incompatible' ? 'error' : (compatibility === null || compatibility === void 0 ? void 0 : compatibility.status) === 'compatible' ? 'success' : 'info';
        if (previewing && (compatibility === null || compatibility === void 0 ? void 0 : compatibility.status) === 'incompatible' && !('blocked' in compatibility && compatibility.blocked)) {
            message += ' You can still create this connection.';
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_5__.Panel, {
        position: "top-left",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
            elevation: 3,
            sx: {
                px: 2,
                py: 1.5,
                width: 320,
                border: 1,
                borderColor: tone === 'success' ? 'success.main' : tone === 'error' ? 'error.main' : 'divider'
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                spacing: 0.5,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        variant: "subtitle2",
                        children: "Connection Helper"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        variant: "body2",
                        children: message
                    }),
                    (compatibility === null || compatibility === void 0 ? void 0 : compatibility.sourceType) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        variant: "caption",
                        color: "text.secondary",
                        children: [
                            "Source: ",
                            compatibility.sourceType
                        ]
                    }),
                    (compatibility === null || compatibility === void 0 ? void 0 : compatibility.targetType) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        variant: "caption",
                        color: "text.secondary",
                        children: [
                            "Target: ",
                            compatibility.targetType
                        ]
                    })
                ]
            })
        })
    });
}


}),
24: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(437);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(358);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(1193);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(487);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(1195);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(795);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(835);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(838);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(840);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(842);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(678);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(25);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(27);
/* ESM import */var fflate__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(142);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _add_operation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(143);
/* ESM import */var _command_panel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(716);
/* ESM import */var _compatible_add_operation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(847);
/* ESM import */var _connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(150);
/* ESM import */var _connection_hint_panel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(848);
/* ESM import */var _diagram_properties_provider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(691);
/* ESM import */var _diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(769);
/* ESM import */var _diagram_side_panel_layout__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(815);
/* ESM import */var _draft_workspace__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(846);
/* ESM import */var _edges__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(299);
/* ESM import */var _editor_mode__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(144);
/* ESM import */var _export_diagram_dialog__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(849);
/* ESM import */var _forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(851);
/* ESM import */var _forms_edit_scope_form__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(857);
/* ESM import */var _forms_use_script_environment_navigation__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(871);
/* ESM import */var _interaction_visualization_provider__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(676);
/* ESM import */var _load_context_provider__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(811);
/* ESM import */var _new_diagram_dialog__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1184);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(147);
/* ESM import */var _notification_provider__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(794);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(321);
/* ESM import */var _responsive_edit_popover__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(1187);
/* ESM import */var _templates_provider__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(459);
/* ESM import */var _transient_editor_drafts__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(845);
/* ESM import */var _use_before_unload_warning__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(1188);
/* ESM import */var _use_draft_pagehide_flush__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(1189);
/* ESM import */var _use_edges__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(813);
/* ESM import */var _utils_auto_layout__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(718);
/* ESM import */var _utils_change__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(1190);
/* ESM import */var _utils_compatibility__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(297);
/* ESM import */var _utils_connection__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(298);
/* ESM import */var _utils_editing_target__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(1191);
/* ESM import */var _utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(319);
/* ESM import */var _utils_export_diagram__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(670);
/* ESM import */var _utils_layout__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(677);
/* ESM import */var _utils_load_diagram__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(1192);
/* ESM import */var _utils_namespace__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(671);











































const NonCapturingPopoverContainer = (param)=>{
    let { children } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: children
    });
};
function decodeDiagramParam(diagramParam) {
    const binaryString = atob(diagramParam);
    const byteArray = new Uint8Array(binaryString.length);
    for(let i = 0; i < binaryString.length; i++){
        byteArray[i] = binaryString.charCodeAt(i);
    }
    return (0,fflate__WEBPACK_IMPORTED_MODULE_40__.strFromU8)((0,fflate__WEBPACK_IMPORTED_MODULE_40__.inflateSync)(byteArray));
}
function cloneSerializable(value) {
    return JSON.parse(JSON.stringify(value));
}
function snapshotGraph(nodes, edges) {
    return {
        nodes: nodes.map((param)=>{
            let { selected: _selected, dragging: _dragging, ...node } = param;
            return cloneSerializable(node);
        }),
        edges: edges.map((param)=>{
            let { selected: _selected, ...edge } = param;
            return cloneSerializable(edge);
        })
    };
}
/**
 * Given a node change, get the parent id and the new position if the change would be applied.
 * Returns null if the change does not result in any position changes.
 */ function getChangeParentIdAndPosition(nodeManager, change) {
    switch(change.type){
        case 'position':
            {
                const changedNode = nodeManager.tryGetNode(change.id);
                if (!changedNode) {
                    return null;
                }
                return change.position ? [
                    change.id,
                    changedNode.parentId || null,
                    change.position
                ] : null;
            }
        case 'add':
        case 'replace':
            {
                return [
                    change.item.id,
                    change.item.parentId || null,
                    change.item.position
                ];
            }
        default:
            {
                return null;
            }
    }
}
function Providers(param) {
    let { editorModeContext, interactionVisualizationContext, loadContext, nodeManager, edges, compatibility, children } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorModeProvider, {
        value: editorModeContext,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_load_context_provider__WEBPACK_IMPORTED_MODULE_18__.LoadContextProvider, {
            value: loadContext,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_node_manager__WEBPACK_IMPORTED_MODULE_20__.NodeManagerProvider, {
                value: nodeManager,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_use_edges__WEBPACK_IMPORTED_MODULE_29__.EdgesProvider, {
                    value: edges,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_5__.ConnectionCompatibilityProvider, {
                        value: compatibility,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_interaction_visualization_provider__WEBPACK_IMPORTED_MODULE_17__.InteractionVisualizationProvider, {
                            value: interactionVisualizationContext,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_notification_provider__WEBPACK_IMPORTED_MODULE_22__.NotificationProvider, {
                                children: children
                            })
                        })
                    })
                })
            })
        })
    });
}
function getInteractionNodeId(operationId, nodeManager) {
    const normalizedId = operationId.startsWith(':') ? operationId.slice(1) : operationId;
    if (normalizedId === '(terminate)') {
        var _nodeManager_tryGetNode;
        return ((_nodeManager_tryGetNode = nodeManager.tryGetNode((0,_utils_namespace__WEBPACK_IMPORTED_MODULE_39__.joinNamespaces)(_utils_namespace__WEBPACK_IMPORTED_MODULE_39__.ROOT_NAMESPACE, _nodes__WEBPACK_IMPORTED_MODULE_21__.TERMINATE_ID))) === null || _nodeManager_tryGetNode === void 0 ? void 0 : _nodeManager_tryGetNode.id) ?? null;
    }
    if (normalizedId.endsWith(':(terminate)')) {
        var _nodeManager_tryGetNode1;
        const namespace = normalizedId.slice(0, -':(terminate)'.length);
        return ((_nodeManager_tryGetNode1 = nodeManager.tryGetNode((0,_utils_namespace__WEBPACK_IMPORTED_MODULE_39__.joinNamespaces)(_utils_namespace__WEBPACK_IMPORTED_MODULE_39__.ROOT_NAMESPACE, namespace, _nodes__WEBPACK_IMPORTED_MODULE_21__.TERMINATE_ID))) === null || _nodeManager_tryGetNode1 === void 0 ? void 0 : _nodeManager_tryGetNode1.id) ?? null;
    }
    if (normalizedId.startsWith('(') || normalizedId.includes(':(exposed):')) {
        return null;
    }
    const parts = normalizedId.split(':');
    const opId = parts.at(-1);
    if (!opId) {
        return null;
    }
    try {
        return nodeManager.getNodeFromNamespaceOpId((0,_utils_namespace__WEBPACK_IMPORTED_MODULE_39__.joinNamespaces)(_utils_namespace__WEBPACK_IMPORTED_MODULE_39__.ROOT_NAMESPACE, ...parts.slice(0, -1)), opId).id;
    } catch  {
        return null;
    }
}
function DiagramEditor() {
    const reactFlowInstance = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(null);
    const suppressNextPaneClick = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(false);
    const [editorMode, setEditorMode] = react__WEBPACK_IMPORTED_MODULE_1___default().useState({
        mode: _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Normal
    });
    const [nodes, setNodes] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(()=>(0,_utils_load_diagram__WEBPACK_IMPORTED_MODULE_38__.loadEmpty)().nodes);
    const nodeManager = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>new _node_manager__WEBPACK_IMPORTED_MODULE_20__.NodeManager(nodes), [
        nodes
    ]);
    const [interactionActiveNodeIds, setInteractionActiveNodeIds] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(()=>new Set());
    const [interactionVisitedNodeIds, setInteractionVisitedNodeIds] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(()=>new Set());
    const [isWorkflowRunning, setWorkflowRunning] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const clearInteractionVisualization = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        setInteractionActiveNodeIds(new Set());
        setInteractionVisitedNodeIds(new Set());
    }, []);
    const markInteractionFinished = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        setInteractionActiveNodeIds(new Set());
    }, []);
    const markInteractionOperationFinished = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((operationId)=>{
        const nodeId = getInteractionNodeId(operationId, nodeManager);
        if (!nodeId) {
            return;
        }
        setInteractionActiveNodeIds((prev)=>{
            const next = new Set(prev);
            next.delete(nodeId);
            return next;
        });
        setInteractionVisitedNodeIds((prev)=>{
            const next = new Set(prev);
            next.add(nodeId);
            return next;
        });
    }, [
        nodeManager
    ]);
    const markInteractionOperationStarted = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((operationId)=>{
        const nodeId = getInteractionNodeId(operationId, nodeManager);
        if (!nodeId) {
            return;
        }
        setInteractionVisitedNodeIds((prev)=>{
            const next = new Set(prev);
            next.delete(nodeId);
            return next;
        });
        setInteractionActiveNodeIds((prev)=>{
            const next = new Set(prev);
            next.add(nodeId);
            return next;
        });
    }, [
        nodeManager
    ]);
    const interactionVisualizationContext = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>({
            activeNodeIds: interactionActiveNodeIds,
            visitedNodeIds: interactionVisitedNodeIds,
            isWorkflowRunning,
            setWorkflowRunning,
            clearInteractionVisualization,
            markInteractionFinished,
            markInteractionOperationFinished,
            markInteractionOperationStarted
        }), [
        clearInteractionVisualization,
        interactionActiveNodeIds,
        interactionVisitedNodeIds,
        isWorkflowRunning,
        markInteractionFinished,
        markInteractionOperationFinished,
        markInteractionOperationStarted
    ]);
    const savedNodes = react__WEBPACK_IMPORTED_MODULE_1___default().useRef([]);
    const [edges, setEdges] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([]);
    const [reconnectingEdgeId, setReconnectingEdgeId] = react__WEBPACK_IMPORTED_MODULE_1___default().useState();
    const [hoveredEdgeId, setHoveredEdgeId] = react__WEBPACK_IMPORTED_MODULE_1___default().useState();
    const [selectedEdgeId, setSelectedEdgeId] = react__WEBPACK_IMPORTED_MODULE_1___default().useState();
    const clearEdgeInspection = ()=>{
        setHoveredEdgeId(undefined);
        setSelectedEdgeId(undefined);
    };
    const reconnectingEdge = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(undefined);
    const savedEdges = react__WEBPACK_IMPORTED_MODULE_1___default().useRef([]);
    const [templates, setTemplates] = (0,_templates_provider__WEBPACK_IMPORTED_MODULE_25__.useTemplates)();
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_23__.useRegistry)();
    const [diagramProperties, setDiagramProperties] = (0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_7__.useDiagramProperties)();
    const compatibility = (0,_connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_5__.useCompatibilityGraph)({
        registry,
        nodeManager,
        edges,
        templates,
        diagramProperties,
        templateId: editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Template ? editorMode.templateId : undefined
    }, reconnectingEdgeId);
    const displayEdges = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>edges.map((edge)=>{
            var _compatibility_edgeResults_get;
            return !isWorkflowRunning && ((_compatibility_edgeResults_get = compatibility.edgeResults.get(edge.id)) === null || _compatibility_edgeResults_get === void 0 ? void 0 : _compatibility_edgeResults_get.status) === 'incompatible' ? {
                ...edge,
                className: [
                    edge.className,
                    'edge-incompatible'
                ].filter(Boolean).join(' ')
            } : edge;
        }), [
        edges,
        compatibility.edgeResults,
        isWorkflowRunning
    ]);
    const inspectedEdgeId = hoveredEdgeId ?? selectedEdgeId;
    const { drafts: transientEditorDrafts, replaceDrafts: replaceTransientEditorDrafts, clearDrafts: clearTransientEditorDrafts, clearOperationConfigDrafts, hasUncommittedBuffers } = (0,_transient_editor_drafts__WEBPACK_IMPORTED_MODULE_26__.useTransientEditorDrafts)();
    const openScriptEnvironment = (0,_forms_use_script_environment_navigation__WEBPACK_IMPORTED_MODULE_16__.useScriptEnvironmentNavigation)();
    const { state: { open: sidePanelOpen, expanded: sidePanelExpanded, tab: sidePanelTab } } = (0,_diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_8__.useDiagramSidePanel)();
    const updateEditorModeAction = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((newMode)=>{
        switch(newMode.mode){
            case _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Normal:
                {
                    var _reactFlowInstance_current;
                    setNodes([
                        ...savedNodes.current
                    ]);
                    setEdges([
                        ...savedEdges.current
                    ]);
                    (_reactFlowInstance_current = reactFlowInstance.current) === null || _reactFlowInstance_current === void 0 ? void 0 : _reactFlowInstance_current.fitView();
                    break;
                }
            case _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Template:
                {
                    var _reactFlowInstance_current1;
                    const template = templates[newMode.templateId];
                    if (!template) {
                        throw new Error(`template ${newMode.templateId} not found`);
                    }
                    const graph = (0,_utils_load_diagram__WEBPACK_IMPORTED_MODULE_38__.loadTemplate)(template);
                    const changes = (0,_utils_auto_layout__WEBPACK_IMPORTED_MODULE_30__.autoLayout)(graph.nodes, graph.edges, _utils_layout__WEBPACK_IMPORTED_MODULE_37__.LAYOUT_OPTIONS);
                    // using callback form so that `nodes` and `edges` don't need to be part of dependencies.
                    setNodes((prev)=>{
                        savedNodes.current = [
                            ...prev
                        ];
                        return (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_41__.applyNodeChanges)(changes, graph.nodes);
                    });
                    setEdges((prev)=>{
                        savedEdges.current = [
                            ...prev
                        ];
                        return graph.edges;
                    });
                    (_reactFlowInstance_current1 = reactFlowInstance.current) === null || _reactFlowInstance_current1 === void 0 ? void 0 : _reactFlowInstance_current1.fitView();
                    break;
                }
            default:
                {
                    (0,_utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_35__.exhaustiveCheck)(newMode);
                    throw new Error('unknown editor mode');
                }
        }
        setEditorMode(newMode);
    }, [
        templates
    ]);
    const handleEdgeChanges = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((changes)=>{
        setEdges((prev)=>(0,_xyflow_react__WEBPACK_IMPORTED_MODULE_41__.applyEdgeChanges)(changes, prev));
    }, []);
    const handleEdgeChange = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((change)=>{
        handleEdgeChanges([
            change
        ]);
    }, [
        handleEdgeChanges
    ]);
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_42__["default"])();
    const backgroundColor = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        switch(editorMode.mode){
            case _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Normal:
                return theme.palette.background.default;
            case _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Template:
                return (0,_mui_material__WEBPACK_IMPORTED_MODULE_43__.darken)(theme.palette.primary.main, 0.8);
            default:
                (0,_utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_35__.exhaustiveCheck)(editorMode);
                throw new Error('unknown editor mode');
        }
    }, [
        editorMode,
        theme
    ]);
    const handleNodeChanges = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((changes)=>{
        const transitiveChanges = [];
        // resize and reposition scope
        for (const change of changes){
            const changeIdPos = getChangeParentIdAndPosition(nodeManager, change);
            if (!changeIdPos) {
                continue;
            }
            const [changeId, changeParentId, changePosition] = changeIdPos;
            if (!changeParentId) {
                continue;
            }
            const scopeNode = nodeManager.tryGetNode(changeParentId);
            if (!scopeNode) {
                continue;
            }
            const scopeChildren = nodeManager.nodes.filter((n)=>n.parentId === changeParentId && n.id !== changeId);
            const calculatedBounds = (0,_utils_layout__WEBPACK_IMPORTED_MODULE_37__.calculateScopeBounds)([
                ...scopeChildren.map((n)=>n.position),
                {
                    // react flow does some kind of rounding (or maybe it is due to floating point accuracies)
                    // that results in gitches when resizing a scope quickly. This rounding reduces the
                    // impact of the glitches.
                    x: Math.round(changePosition.x),
                    y: Math.round(changePosition.y)
                }
            ]);
            const newScopeBounds = {
                x: scopeNode.position.x,
                y: scopeNode.position.y,
                width: scopeNode.width ?? calculatedBounds.width,
                height: scopeNode.height ?? calculatedBounds.height
            };
            // React Flow cannot handle fast changing of a parent's position while changing the
            // children's position as well (some kind of race condition that causes the node positions to jump around).
            // Workaround by resizing the scope only if it hits a certain threshold.
            if (Math.abs(calculatedBounds.x) > _utils_layout__WEBPACK_IMPORTED_MODULE_37__.LAYOUT_OPTIONS.scopePadding.leftRight || Math.abs(calculatedBounds.y) > _utils_layout__WEBPACK_IMPORTED_MODULE_37__.LAYOUT_OPTIONS.scopePadding.topBottom || scopeNode.width && Math.abs(calculatedBounds.width - scopeNode.width) > _utils_layout__WEBPACK_IMPORTED_MODULE_37__.LAYOUT_OPTIONS.scopePadding.leftRight || scopeNode.height && Math.abs(calculatedBounds.height - scopeNode.height) > _utils_layout__WEBPACK_IMPORTED_MODULE_37__.LAYOUT_OPTIONS.scopePadding.topBottom) {
                newScopeBounds.x += calculatedBounds.x;
                newScopeBounds.width = calculatedBounds.width;
                newScopeBounds.y += calculatedBounds.y;
                newScopeBounds.height = calculatedBounds.height;
            }
            if (newScopeBounds.x !== scopeNode.position.x || newScopeBounds.y !== scopeNode.position.y || newScopeBounds.width !== scopeNode.width || newScopeBounds.height !== scopeNode.height) {
                transitiveChanges.push({
                    type: 'position',
                    id: changeParentId,
                    position: {
                        x: newScopeBounds.x,
                        y: newScopeBounds.y
                    }
                });
                transitiveChanges.push({
                    type: 'dimensions',
                    id: changeParentId,
                    dimensions: {
                        width: newScopeBounds.width,
                        height: newScopeBounds.height
                    },
                    setAttributes: true
                });
                // when the scope is moved, the relative position of the nodes will change so we
                // need to update them to keep them in place.
                for (const child of scopeChildren){
                    transitiveChanges.push({
                        type: 'position',
                        id: child.id,
                        position: {
                            x: child.position.x - calculatedBounds.x,
                            y: child.position.y - calculatedBounds.y
                        }
                    });
                }
            }
        }
        // remove children nodes of a removed parent
        const removedNodes = new Set(changes.filter((change)=>(0,_utils_change__WEBPACK_IMPORTED_MODULE_31__.isRemoveChange)(change)).map((change)=>change.id));
        while(true){
            let newChanges = false;
            for (const node of nodeManager.nodes){
                if (node.parentId && removedNodes.has(node.parentId) && !removedNodes.has(node.id)) {
                    transitiveChanges.push({
                        type: 'remove',
                        id: node.id
                    });
                    removedNodes.add(node.id);
                    newChanges = true;
                }
            }
            if (!newChanges) {
                break;
            }
        }
        clearOperationConfigDrafts(removedNodes);
        // clean up dangling edges when a node is removed.
        const edgeChanges = [];
        for (const edge of edges){
            if (removedNodes.has(edge.source) || removedNodes.has(edge.target)) {
                edgeChanges.push({
                    type: 'remove',
                    id: edge.id
                });
            }
        }
        handleEdgeChanges(edgeChanges);
        setNodes((prev)=>(0,_xyflow_react__WEBPACK_IMPORTED_MODULE_41__.applyNodeChanges)([
                ...changes,
                ...transitiveChanges
            ], prev));
    }, [
        clearOperationConfigDrafts,
        handleEdgeChanges,
        nodeManager,
        edges
    ]);
    const handleNodeChange = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((change)=>{
        handleNodeChanges([
            change
        ]);
    }, [
        handleNodeChanges
    ]);
    const [addOperationPopover, setAddOperationPopover] = react__WEBPACK_IMPORTED_MODULE_1___default().useState({
        open: false,
        popOverPosition: {
            left: 0,
            top: 0
        },
        parentId: null,
        sourceConnection: null
    });
    const addOperationPopoverActions = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(null);
    const updateAddOperationPopoverPosition = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        var _addOperationPopoverActions_current;
        (_addOperationPopoverActions_current = addOperationPopoverActions.current) === null || _addOperationPopoverActions_current === void 0 ? void 0 : _addOperationPopoverActions_current.updatePosition();
    }, []);
    const addOperationNewNodePosition = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        var _reactFlowInstance_current;
        if (!reactFlowInstance.current) {
            return {
                x: 0,
                y: 0
            };
        }
        const parentNode = addOperationPopover.parentId ? nodeManager.tryGetNode(addOperationPopover.parentId) : null;
        const parentPosition = (parentNode === null || parentNode === void 0 ? void 0 : parentNode.position) ? parentNode.position : {
            x: 0,
            y: 0
        };
        return ((_reactFlowInstance_current = reactFlowInstance.current) === null || _reactFlowInstance_current === void 0 ? void 0 : _reactFlowInstance_current.screenToFlowPosition({
            x: addOperationPopover.popOverPosition.left - parentPosition.x,
            y: addOperationPopover.popOverPosition.top - parentPosition.y
        })) || {
            x: 0,
            y: 0
        };
    }, [
        nodeManager,
        addOperationPopover.parentId,
        addOperationPopover.popOverPosition
    ]);
    const [editingNodeId, setEditingNodeId] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const [pendingScriptEnvironmentNodeId, setPendingScriptEnvironmentNodeId] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (!sidePanelOpen || sidePanelTab !== 'environments') {
            setPendingScriptEnvironmentNodeId(null);
        }
    }, [
        sidePanelOpen,
        sidePanelTab
    ]);
    const scriptNodeBinding = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        const nodeId = editingNodeId || pendingScriptEnvironmentNodeId;
        const node = nodeId ? nodeManager.tryGetNode(nodeId) : undefined;
        if (!node || node.type !== 'script') {
            return undefined;
        }
        const environmentName = node.data.op.environment;
        return {
            environmentName: typeof environmentName === 'string' ? environmentName || undefined : undefined,
            nodeControlsSelection: editingNodeId === node.id,
            assignEnvironment: (environmentName)=>{
                handleNodeChange({
                    type: 'replace',
                    id: node.id,
                    item: {
                        ...node,
                        data: {
                            ...node.data,
                            op: {
                                ...node.data.op,
                                environment: environmentName
                            }
                        }
                    }
                });
                if (pendingScriptEnvironmentNodeId === node.id) {
                    setPendingScriptEnvironmentNodeId(null);
                }
            }
        };
    }, [
        editingNodeId,
        handleNodeChange,
        nodeManager,
        pendingScriptEnvironmentNodeId
    ]);
    const [editingEdgeId, setEditingEdgeId] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const editingEdge = (()=>{
        if (!editingEdgeId) {
            return null;
        }
        const edge = edges.find((e)=>e.id === editingEdgeId);
        if (!edge) {
            console.error(`cannot find edge ${editingEdgeId}`);
            return null;
        }
        const sourceNode = nodeManager.tryGetNode(edge.source);
        if (!sourceNode) {
            console.error(`cannot find node ${edge.source}`);
            return null;
        }
        const targetNode = nodeManager.tryGetNode(edge.target);
        if (!targetNode) {
            console.error(`cannot find node ${edge.target}`);
            return null;
        }
        return {
            edge,
            sourceNode,
            targetNode
        };
    })();
    const closeAllPopovers = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        setEditingNodeId(null);
        setPendingScriptEnvironmentNodeId(null);
        setEditingEdgeId(null);
        setAddOperationPopover((prev)=>({
                ...prev,
                open: false,
                sourceConnection: null
            }));
        setEditOpFormPopoverProps({
            open: false
        });
    }, []);
    const [editOpFormPopoverProps, setEditOpFormPopoverProps] = react__WEBPACK_IMPORTED_MODULE_1___default().useState({
        open: false
    });
    const renderEditForm = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((nodeId)=>{
        const node = nodeManager.tryGetNode(nodeId);
        if (!node || (0,_nodes__WEBPACK_IMPORTED_MODULE_21__.isBuiltinNode)(node)) {
            return null;
        }
        const handleDelete = (change)=>{
            handleNodeChange(change);
            closeAllPopovers();
        };
        if (node.type === 'scope') {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_forms_edit_scope_form__WEBPACK_IMPORTED_MODULE_15__["default"], {
                node: node,
                onChange: handleNodeChange,
                onDelete: handleDelete,
                onAddOperationClick: (ev)=>{
                    setAddOperationPopover({
                        open: true,
                        popOverPosition: {
                            left: ev.clientX,
                            top: ev.clientY
                        },
                        parentId: node.id,
                        sourceConnection: null
                    });
                }
            });
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_forms__WEBPACK_IMPORTED_MODULE_14__.EditNodeForm, {
            node: node,
            onChange: handleNodeChange,
            onDelete: handleDelete
        }, editingNodeId);
    }, [
        nodeManager,
        editingNodeId,
        handleNodeChange,
        closeAllPopovers
    ]);
    const mouseDownTime = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(0);
    const [errorToast, setErrorToast] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const [openErrorToast, setOpenErrorToast] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const showErrorToast = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((message)=>{
        setErrorToast(message);
        setOpenErrorToast(true);
        setEnableExport(false);
    }, []);
    const [loadContext, setLoadContext] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const [recentlyUsedFilename, setRecentlyUsedFilename] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const [hydrationResolved, setHydrationResolved] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [isDirty, setIsDirty] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const dirtyRef = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(false);
    const baselineFingerprint = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(null);
    const markCleanOnNextSnapshot = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(false);
    const latestDraftContent = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(null);
    const autosaveTimer = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(null);
    const [draftStorageFailed, setDraftStorageFailed] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [recoveryCandidate, setRecoveryCandidate] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const clearStoredDraft = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        try {
            (0,_draft_workspace__WEBPACK_IMPORTED_MODULE_10__.clearDraftWorkspace)();
            setDraftStorageFailed(false);
        } catch  {
            setDraftStorageFailed(true);
        }
    }, []);
    const prepareDiagram = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(async (jsonStr, filename)=>{
        const [diagram, loaded] = await (0,_utils_load_diagram__WEBPACK_IMPORTED_MODULE_38__.loadDiagramJson)(jsonStr);
        return {
            diagram,
            loaded,
            filename
        };
    }, []);
    const applyPreparedDiagram = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((prepared)=>{
        const { diagram, loaded, filename } = prepared;
        const { graph, isRestored } = loaded;
        clearInteractionVisualization();
        setLoadContext({
            diagram
        });
        setDiagramProperties({
            description: diagram.description ?? '',
            input_examples: diagram.input_examples ?? [],
            script_environments: diagram.script_environments ?? {}
        });
        const nextNodes = isRestored ? graph.nodes : (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_41__.applyNodeChanges)((0,_utils_auto_layout__WEBPACK_IMPORTED_MODULE_30__.autoLayout)(graph.nodes, graph.edges, _utils_layout__WEBPACK_IMPORTED_MODULE_37__.LAYOUT_OPTIONS), graph.nodes);
        savedNodes.current = [];
        savedEdges.current = [];
        setEditorMode({
            mode: _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Normal
        });
        setNodes(nextNodes);
        setEdges(graph.edges);
        setTemplates(diagram.templates || {});
        setRecentlyUsedFilename(filename);
        clearTransientEditorDrafts();
        closeAllPopovers();
        markCleanOnNextSnapshot.current = true;
        setHydrationResolved(true);
        clearStoredDraft();
        requestAnimationFrame(()=>{
            var _reactFlowInstance_current;
            return (_reactFlowInstance_current = reactFlowInstance.current) === null || _reactFlowInstance_current === void 0 ? void 0 : _reactFlowInstance_current.fitView();
        });
    }, [
        clearInteractionVisualization,
        clearStoredDraft,
        clearTransientEditorDrafts,
        closeAllPopovers,
        setDiagramProperties
    ]);
    const loadDiagram = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(async (jsonStr, filename)=>{
        try {
            const prepared = await prepareDiagram(jsonStr, filename);
            if ((isDirty || hasUncommittedBuffers) && !window.confirm('Replace the current diagram and discard its unsaved changes?')) {
                return;
            }
            applyPreparedDiagram(prepared);
        } catch (e) {
            showErrorToast(`failed to load diagram: ${e}`);
        }
    }, [
        applyPreparedDiagram,
        hasUncommittedBuffers,
        isDirty,
        prepareDiagram,
        showErrorToast
    ]);
    const [openExportDiagramDialog, setOpenExportDiagramDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [openNewDiagramDialog, setOpenNewDiagramDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const handleMouseDown = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        mouseDownTime.current = Date.now();
    }, []);
    const getClientPosition = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((event)=>{
        if ('clientX' in event) {
            return {
                x: event.clientX,
                y: event.clientY
            };
        }
        const touch = event.changedTouches[0] || event.touches[0];
        if (!touch) {
            return null;
        }
        return {
            x: touch.clientX,
            y: touch.clientY
        };
    }, []);
    const tryCreateEdge = function(connection, edgeId) {
        let nodeChanges = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
        const result = (0,_utils_compatibility__WEBPACK_IMPORTED_MODULE_32__.prepareConnection)({
            connection,
            edgeId,
            nodeManager: nodeChanges.length ? new _node_manager__WEBPACK_IMPORTED_MODULE_20__.NodeManager([
                ...nodes,
                ...nodeChanges.map((param)=>{
                    let { item } = param;
                    return item;
                })
            ]) : nodeManager,
            edges,
            registry,
            templates
        });
        if (!result.valid) {
            showErrorToast(result.error);
            return null;
        }
        return result.edge;
    };
    const [enableExport, setEnableExport] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(true);
    const draftContent = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        const { highlightedEnvironment: _highlightedEnvironment, ...persistedDiagramProperties } = diagramProperties;
        const mainGraph = editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Template ? snapshotGraph(savedNodes.current, savedEdges.current) : snapshotGraph(nodes, edges);
        const activeTemplate = editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Template ? {
            templateId: editorMode.templateId,
            graph: snapshotGraph(nodes, edges)
        } : undefined;
        return {
            mainGraph,
            activeTemplate,
            templates: cloneSerializable(templates),
            diagramProperties: cloneSerializable(persistedDiagramProperties),
            sourceExtensions: (loadContext === null || loadContext === void 0 ? void 0 : loadContext.diagram.extensions) ? cloneSerializable(loadContext.diagram.extensions) : undefined,
            filename: recentlyUsedFilename,
            transientEditors: cloneSerializable(transientEditorDrafts)
        };
    }, [
        diagramProperties,
        edges,
        editorMode,
        loadContext,
        nodes,
        recentlyUsedFilename,
        templates,
        transientEditorDrafts
    ]);
    const persistLatestDraft = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        if (!dirtyRef.current || !latestDraftContent.current) {
            return;
        }
        try {
            (0,_draft_workspace__WEBPACK_IMPORTED_MODULE_10__.writeDraftWorkspace)(latestDraftContent.current);
            setDraftStorageFailed(false);
        } catch  {
            setDraftStorageFailed(true);
        }
    }, []);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        latestDraftContent.current = draftContent;
        if (!hydrationResolved) {
            return;
        }
        const fingerprint = (0,_draft_workspace__WEBPACK_IMPORTED_MODULE_10__.draftWorkspaceFingerprint)(draftContent);
        if (markCleanOnNextSnapshot.current) {
            markCleanOnNextSnapshot.current = false;
            baselineFingerprint.current = fingerprint;
            dirtyRef.current = false;
            setIsDirty(false);
            clearStoredDraft();
            return;
        }
        if (baselineFingerprint.current === null) {
            baselineFingerprint.current = fingerprint;
            dirtyRef.current = false;
            setIsDirty(false);
            return;
        }
        const dirty = fingerprint !== baselineFingerprint.current;
        dirtyRef.current = dirty;
        setIsDirty(dirty);
        if (!dirty) {
            clearStoredDraft();
            return;
        }
        if (autosaveTimer.current !== null) {
            clearTimeout(autosaveTimer.current);
        }
        autosaveTimer.current = setTimeout(persistLatestDraft, 500);
        return ()=>{
            if (autosaveTimer.current !== null) {
                clearTimeout(autosaveTimer.current);
                autosaveTimer.current = null;
            }
        };
    }, [
        clearStoredDraft,
        draftContent,
        hydrationResolved,
        persistLatestDraft
    ]);
    (0,_use_draft_pagehide_flush__WEBPACK_IMPORTED_MODULE_28__.useDraftPagehideFlush)(latestDraftContent, hydrationResolved && (isDirty || hasUncommittedBuffers), setDraftStorageFailed);
    (0,_use_before_unload_warning__WEBPACK_IMPORTED_MODULE_27__.useBeforeUnloadWarning)(isDirty || hasUncommittedBuffers);
    const resetToNewDiagram = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        const empty = (0,_utils_load_diagram__WEBPACK_IMPORTED_MODULE_38__.loadEmpty)();
        clearInteractionVisualization();
        closeAllPopovers();
        savedNodes.current = [];
        savedEdges.current = [];
        setEditorMode({
            mode: _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Normal
        });
        setNodes(empty.nodes);
        setEdges(empty.edges);
        setTemplates({});
        setDiagramProperties((0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_7__.createEmptyDiagramProperties)());
        setLoadContext(null);
        setRecentlyUsedFilename(null);
        clearTransientEditorDrafts();
        markCleanOnNextSnapshot.current = true;
        setHydrationResolved(true);
        clearStoredDraft();
        requestAnimationFrame(()=>{
            var _reactFlowInstance_current;
            return (_reactFlowInstance_current = reactFlowInstance.current) === null || _reactFlowInstance_current === void 0 ? void 0 : _reactFlowInstance_current.fitView();
        });
    }, [
        clearInteractionVisualization,
        clearStoredDraft,
        clearTransientEditorDrafts,
        closeAllPopovers,
        setDiagramProperties
    ]);
    const handleNewDiagram = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        if (isDirty || hasUncommittedBuffers) {
            setOpenNewDiagramDialog(true);
            return;
        }
        resetToNewDiagram();
    }, [
        hasUncommittedBuffers,
        isDirty,
        resetToNewDiagram
    ]);
    const restoreRecoveryDraft = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        if (!recoveryCandidate) {
            return;
        }
        const { draft } = recoveryCandidate;
        savedNodes.current = cloneSerializable(draft.mainGraph.nodes);
        savedEdges.current = cloneSerializable(draft.mainGraph.edges);
        if (draft.activeTemplate) {
            setNodes(cloneSerializable(draft.activeTemplate.graph.nodes));
            setEdges(cloneSerializable(draft.activeTemplate.graph.edges));
            setEditorMode({
                mode: _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Template,
                templateId: draft.activeTemplate.templateId
            });
        } else {
            setNodes(cloneSerializable(draft.mainGraph.nodes));
            setEdges(cloneSerializable(draft.mainGraph.edges));
            setEditorMode({
                mode: _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Normal
            });
        }
        setTemplates(cloneSerializable(draft.templates));
        setDiagramProperties(cloneSerializable(draft.diagramProperties));
        setRecentlyUsedFilename(draft.filename);
        replaceTransientEditorDrafts(cloneSerializable(draft.transientEditors));
        const restoredDiagram = {
            version: '0.1.0',
            start: {
                builtin: 'dispose'
            },
            ops: {},
            templates: cloneSerializable(draft.templates),
            description: draft.diagramProperties.description,
            input_examples: draft.diagramProperties.input_examples,
            script_environments: draft.diagramProperties.script_environments,
            extensions: draft.sourceExtensions
        };
        setLoadContext({
            diagram: restoredDiagram
        });
        baselineFingerprint.current = '__restored_recovery_draft__';
        dirtyRef.current = true;
        setIsDirty(true);
        setHydrationResolved(true);
        setRecoveryCandidate(null);
        requestAnimationFrame(()=>{
            var _reactFlowInstance_current;
            return (_reactFlowInstance_current = reactFlowInstance.current) === null || _reactFlowInstance_current === void 0 ? void 0 : _reactFlowInstance_current.fitView();
        });
    }, [
        recoveryCandidate,
        replaceTransientEditorDrafts,
        setDiagramProperties
    ]);
    const discardRecoveryDraft = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        if (!recoveryCandidate) {
            return;
        }
        const linkedDiagram = recoveryCandidate.linkedDiagram;
        setRecoveryCandidate(null);
        clearStoredDraft();
        if (linkedDiagram) {
            applyPreparedDiagram(linkedDiagram);
            return;
        }
        const empty = (0,_utils_load_diagram__WEBPACK_IMPORTED_MODULE_38__.loadEmpty)();
        setNodes(empty.nodes);
        setEdges(empty.edges);
        setTemplates({});
        setDiagramProperties((0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_7__.createEmptyDiagramProperties)());
        setLoadContext(null);
        setRecentlyUsedFilename(null);
        clearTransientEditorDrafts();
        baselineFingerprint.current = null;
        markCleanOnNextSnapshot.current = true;
        setHydrationResolved(true);
    }, [
        applyPreparedDiagram,
        clearStoredDraft,
        clearTransientEditorDrafts,
        recoveryCandidate,
        setDiagramProperties
    ]);
    const markExportCompleted = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback((filename)=>{
        setRecentlyUsedFilename(filename);
        if (latestDraftContent.current) {
            const exportedContent = {
                ...latestDraftContent.current,
                filename
            };
            latestDraftContent.current = exportedContent;
            baselineFingerprint.current = (0,_draft_workspace__WEBPACK_IMPORTED_MODULE_10__.draftWorkspaceFingerprint)(exportedContent);
        }
        markCleanOnNextSnapshot.current = false;
        dirtyRef.current = false;
        setIsDirty(false);
        clearStoredDraft();
    }, [
        clearStoredDraft
    ]);
    const handleStartNewAfterExport = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>{
        setOpenExportDiagramDialog(false);
        resetToNewDiagram();
    }, [
        resetToNewDiagram
    ]);
    const newDiagramAfterExport = (0,_new_diagram_dialog__WEBPACK_IMPORTED_MODULE_19__.useNewDiagramAfterExport)(markExportCompleted, handleStartNewAfterExport);
    const startupInitialized = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Providers, {
        editorModeContext: [
            editorMode,
            updateEditorModeAction
        ],
        interactionVisualizationContext: interactionVisualizationContext,
        loadContext: loadContext,
        nodeManager: nodeManager,
        edges: edges,
        compatibility: compatibility,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_xyflow_react__WEBPACK_IMPORTED_MODULE_41__.ReactFlow, {
            nodes: nodes,
            edges: displayEdges,
            fitView: true,
            fitViewOptions: {
                padding: 0.2
            },
            nodeTypes: _nodes__WEBPACK_IMPORTED_MODULE_21__.NODE_TYPES,
            edgeTypes: _edges__WEBPACK_IMPORTED_MODULE_11__.EDGE_TYPES,
            onInit: (instance)=>{
                reactFlowInstance.current = instance;
                if (startupInitialized.current) {
                    return;
                }
                startupInitialized.current = true;
                void (async ()=>{
                    let linkedDiagram = null;
                    const diagramParam = new URLSearchParams(window.location.search).get('diagram');
                    if (diagramParam) {
                        try {
                            linkedDiagram = await prepareDiagram(decodeDiagramParam(diagramParam), null);
                        } catch (error) {
                            showErrorToast(`failed to load linked diagram: ${error instanceof Error ? error.message : error}`);
                        }
                    }
                    let storedDraft = null;
                    try {
                        storedDraft = (0,_draft_workspace__WEBPACK_IMPORTED_MODULE_10__.readDraftWorkspace)();
                    } catch (error) {
                        clearStoredDraft();
                        showErrorToast(`failed to read recovery draft: ${error instanceof Error ? error.message : error}`);
                    }
                    if (storedDraft) {
                        setRecoveryCandidate({
                            draft: storedDraft,
                            linkedDiagram
                        });
                        return;
                    }
                    if (linkedDiagram) {
                        applyPreparedDiagram(linkedDiagram);
                        return;
                    }
                    markCleanOnNextSnapshot.current = true;
                    setHydrationResolved(true);
                })();
            },
            onNodesChange: handleNodeChanges,
            onNodesDelete: ()=>{
                closeAllPopovers();
            },
            onEdgesChange: handleEdgeChanges,
            onEdgesDelete: ()=>{
                clearEdgeInspection();
                closeAllPopovers();
            },
            onConnectStart: clearEdgeInspection,
            onConnect: (conn)=>{
                clearEdgeInspection();
                const newEdge = tryCreateEdge(conn);
                if (newEdge) {
                    setEdges((prev)=>(0,_xyflow_react__WEBPACK_IMPORTED_MODULE_44__.addEdge)(newEdge, prev));
                }
            },
            isValidConnection: (conn)=>{
                return (0,_utils_connection__WEBPACK_IMPORTED_MODULE_33__.validateConnectionSimple)(conn, nodeManager, edges.filter((edge)=>edge.id !== reconnectingEdge.current)).valid;
            },
            onReconnectStart: (_, edge)=>{
                clearEdgeInspection();
                reconnectingEdge.current = edge.id;
                setReconnectingEdgeId(edge.id);
            },
            onReconnectEnd: ()=>{
                reconnectingEdge.current = undefined;
                setReconnectingEdgeId(undefined);
            },
            onReconnect: (oldEdge, newConnection)=>{
                const newEdge = tryCreateEdge(newConnection, oldEdge.id);
                if (newEdge) {
                    setEdges((prev)=>{
                        // React Flow's oldEdge includes display-only diagnostics.
                        const updatedEdge = {
                            ...prev.find((edge)=>edge.id === oldEdge.id),
                            type: newEdge.type,
                            data: newEdge.data
                        };
                        return (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_44__.reconnectEdge)(updatedEdge, newConnection, prev);
                    });
                }
            },
            onConnectEnd: (event, connectionState)=>{
                clearEdgeInspection();
                // React Flow also calls this new-wire handler when reconnecting.
                if (reconnectingEdge.current && !connectionState.toHandle) {
                    return;
                }
                if (!connectionState.fromHandle) {
                    return;
                }
                if (connectionState.isValid === false && connectionState.toHandle) {
                    const direction = (0,_utils_connection__WEBPACK_IMPORTED_MODULE_33__.validateDraggedHandlePair)({
                        fromHandleType: connectionState.fromHandle.type,
                        otherHandleType: connectionState.toHandle.type
                    });
                    if (!direction.valid) {
                        showErrorToast(direction.error);
                        return;
                    }
                    const result = (0,_utils_connection__WEBPACK_IMPORTED_MODULE_33__.validateConnectionSimple)((0,_utils_connection__WEBPACK_IMPORTED_MODULE_33__.createConnectionFromHandles)(connectionState.fromHandle, connectionState.toHandle.nodeId, connectionState.toHandle.id), nodeManager, edges.filter((edge)=>edge.id !== reconnectingEdge.current));
                    if (!result.valid) {
                        showErrorToast(result.error);
                    }
                    return;
                }
                if (connectionState.toHandle) {
                    return;
                }
                const sourceNode = nodeManager.tryGetNode(connectionState.fromHandle.nodeId);
                const clientPosition = getClientPosition(event);
                if (!sourceNode || !clientPosition) {
                    return;
                }
                if (connectionState.fromHandle.type === 'source') {
                    const outputCapacity = (0,_utils_connection__WEBPACK_IMPORTED_MODULE_33__.validateSourceOutputCapacity)(sourceNode, connectionState.fromHandle.id, edges);
                    if (!outputCapacity.valid) {
                        showErrorToast(outputCapacity.error);
                        return;
                    }
                }
                setAddOperationPopover({
                    open: true,
                    popOverPosition: {
                        left: clientPosition.x,
                        top: clientPosition.y
                    },
                    parentId: sourceNode.parentId || null,
                    sourceConnection: {
                        sourceNodeId: sourceNode.id,
                        sourceHandle: connectionState.fromHandle.id || null,
                        sourceHandleType: connectionState.fromHandle.type
                    }
                });
                suppressNextPaneClick.current = true;
            },
            onNodeClick: (ev, node)=>{
                ev.stopPropagation();
                closeAllPopovers();
                if ((0,_nodes__WEBPACK_IMPORTED_MODULE_21__.isBuiltinNode)(node)) {
                    return;
                }
                if (node.type === 'script') {
                    const environmentName = node.data.op.environment;
                    openScriptEnvironment(typeof environmentName === 'string' ? environmentName || undefined : undefined, false);
                }
                setEditingNodeId(node.id);
                setEditOpFormPopoverProps({
                    open: true,
                    anchorReference: 'anchorPosition',
                    anchorPosition: (0,_diagram_side_panel_layout__WEBPACK_IMPORTED_MODULE_9__.getEditPopoverPositionForNode)({
                        nodeRect: ev.currentTarget.getBoundingClientRect(),
                        viewportWidth: window.innerWidth,
                        sidePanel: {
                            open: sidePanelOpen,
                            expanded: sidePanelExpanded
                        }
                    })
                });
            },
            onEdgeClick: (ev, edge)=>{
                ev.stopPropagation();
                closeAllPopovers();
                const sourceNode = nodes.find((n)=>n.id === edge.source);
                const targetNode = nodes.find((n)=>n.id === edge.target);
                if (!sourceNode || !targetNode) {
                    throw new Error('unable to find source or target node');
                }
                setEditingEdgeId(edge.id);
                setSelectedEdgeId(edge.id);
                setEditOpFormPopoverProps({
                    open: true,
                    anchorReference: 'anchorPosition',
                    anchorPosition: {
                        left: ev.clientX,
                        top: ev.clientY
                    }
                });
            },
            onEdgeMouseEnter: (_, edge)=>setHoveredEdgeId(edge.id),
            onEdgeMouseLeave: ()=>setHoveredEdgeId(undefined),
            onSelectionChange: (param)=>{
                let { edges: selected } = param;
                var _selected_;
                return setSelectedEdgeId((_selected_ = selected[0]) === null || _selected_ === void 0 ? void 0 : _selected_.id);
            },
            onPaneClick: (ev)=>{
                clearEdgeInspection();
                if (suppressNextPaneClick.current) {
                    suppressNextPaneClick.current = false;
                    return;
                }
                if (addOperationPopover.open || editOpFormPopoverProps.open) {
                    closeAllPopovers();
                    return;
                }
                // filter out erroneous click after connecting an edge
                const now = Date.now();
                if (now - mouseDownTime.current > 200) {
                    return;
                }
                setAddOperationPopover({
                    open: true,
                    popOverPosition: {
                        left: ev.clientX,
                        top: ev.clientY
                    },
                    parentId: null,
                    sourceConnection: null
                });
            },
            onMouseDownCapture: handleMouseDown,
            onTouchStartCapture: handleMouseDown,
            colorMode: "dark",
            deleteKeyCode: 'Delete',
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_41__.Background, {
                    bgColor: backgroundColor,
                    color: (0,_mui_material__WEBPACK_IMPORTED_MODULE_43__.alpha)(theme.palette.text.primary, 0.3),
                    gap: 30
                }),
                editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Template && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_41__.Panel, {
                    position: "top-left",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_45__["default"], {
                        variant: "h4",
                        children: editorMode.templateId
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_connection_hint_panel__WEBPACK_IMPORTED_MODULE_6__.ConnectionHintPanel, {
                    nodeManager: nodeManager,
                    reconnectingEdgeId: reconnectingEdgeId,
                    edgeResult: inspectedEdgeId ? compatibility.edgeResults.get(inspectedEdgeId) : undefined
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_command_panel__WEBPACK_IMPORTED_MODULE_3__["default"], {
                    onNodeChanges: handleNodeChanges,
                    onNewDiagram: handleNewDiagram,
                    onExportClick: react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(()=>setOpenExportDiagramDialog(true), []),
                    onLoadDiagram: loadDiagram,
                    enableExport: enableExport && !hasUncommittedBuffers,
                    exportDisabledReason: hasUncommittedBuffers ? 'Save or discard unfinished editor fields before exporting' : undefined,
                    isDirty: isDirty,
                    scriptNodeBinding: scriptNodeBinding
                }),
                editorMode.mode === _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Template && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_46__["default"], {
                    color: "primary",
                    "aria-label": "Save",
                    sx: {
                        position: 'absolute',
                        right: 64,
                        bottom: 64
                    },
                    onClick: ()=>{
                        const exportedTemplate = (0,_utils_export_diagram__WEBPACK_IMPORTED_MODULE_36__.exportTemplate)(registry, nodeManager, edges);
                        setTemplates((prev)=>({
                                ...prev,
                                [editorMode.templateId]: exportedTemplate
                            }));
                        updateEditorModeAction({
                            mode: _editor_mode__WEBPACK_IMPORTED_MODULE_12__.EditorMode.Normal
                        });
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_21__.MaterialSymbol, {
                        symbol: "check"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_47__["default"], {
                    action: addOperationPopoverActions,
                    open: addOperationPopover.open,
                    onClose: closeAllPopovers,
                    anchorReference: "anchorPosition",
                    anchorPosition: addOperationPopover.popOverPosition,
                    // use a custom component to prevent the popover from creating an invisible element that blocks clicks
                    component: NonCapturingPopoverContainer,
                    children: addOperationPopover.sourceConnection ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_compatible_add_operation__WEBPACK_IMPORTED_MODULE_4__.CompatibleAddOperation, {
                        parentId: addOperationPopover.parentId || undefined,
                        newNodePosition: addOperationNewNodePosition,
                        sourceConnection: addOperationPopover.sourceConnection,
                        onContentChange: updateAddOperationPopoverPosition,
                        onAdd: (param)=>{
                            let { changes, primaryNodeId } = param;
                            var _changes_find;
                            const targetNode = ((_changes_find = changes.find((change)=>change.item.id === primaryNodeId)) === null || _changes_find === void 0 ? void 0 : _changes_find.item) || null;
                            if (!targetNode || !addOperationPopover.sourceConnection) {
                                return;
                            }
                            const connection = (0,_utils_connection__WEBPACK_IMPORTED_MODULE_33__.createConnectionFromHandles)({
                                nodeId: addOperationPopover.sourceConnection.sourceNodeId,
                                id: addOperationPopover.sourceConnection.sourceHandle,
                                type: addOperationPopover.sourceConnection.sourceHandleType
                            }, targetNode.id, null);
                            const newEdge = tryCreateEdge(connection, undefined, changes);
                            if (!newEdge) {
                                return;
                            }
                            handleNodeChanges(changes);
                            setEdges((prev)=>(0,_xyflow_react__WEBPACK_IMPORTED_MODULE_44__.addEdge)(newEdge, prev));
                            closeAllPopovers();
                            if (targetNode.type === 'script') {
                                const environmentName = targetNode.data.op.environment;
                                openScriptEnvironment(typeof environmentName === 'string' ? environmentName || undefined : undefined, true);
                                setPendingScriptEnvironmentNodeId(targetNode.id);
                            }
                        }
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_add_operation__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        parentId: addOperationPopover.parentId || undefined,
                        newNodePosition: addOperationNewNodePosition,
                        onAdd: (param)=>{
                            let { changes, primaryNodeId } = param;
                            var _changes_find;
                            handleNodeChanges(changes);
                            const primaryNode = ((_changes_find = changes.find((change)=>change.item.id === primaryNodeId)) === null || _changes_find === void 0 ? void 0 : _changes_find.item) || null;
                            closeAllPopovers();
                            if ((primaryNode === null || primaryNode === void 0 ? void 0 : primaryNode.type) === 'script') {
                                const environmentName = primaryNode.data.op.environment;
                                openScriptEnvironment(typeof environmentName === 'string' ? environmentName || undefined : undefined, true);
                                setPendingScriptEnvironmentNodeId(primaryNode.id);
                            }
                        }
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_responsive_edit_popover__WEBPACK_IMPORTED_MODULE_24__.ResponsiveEditPopover, {
                    ...editOpFormPopoverProps,
                    onClose: (_event, reason)=>{
                        if (reason === 'escapeKeyDown' && (0,_utils_editing_target__WEBPACK_IMPORTED_MODULE_34__.shouldIgnoreEscapeClose)(document.activeElement)) {
                            return;
                        }
                        setEditOpFormPopoverProps({
                            open: false
                        });
                    },
                    // use a custom component to prevent the popover from creating an invisible element that blocks clicks
                    component: NonCapturingPopoverContainer,
                    children: [
                        editingNodeId && renderEditForm(editingNodeId),
                        editingEdge && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_forms__WEBPACK_IMPORTED_MODULE_14__.EditEdgeForm, {
                            edge: editingEdge.edge,
                            allowedEdgeTypes: (0,_utils_connection__WEBPACK_IMPORTED_MODULE_33__.getValidEdgeTypes)(editingEdge.sourceNode, editingEdge.edge.sourceHandle, editingEdge.targetNode, editingEdge.edge.targetHandle),
                            nodeManager: nodeManager,
                            onChange: handleEdgeChange,
                            onDelete: (changes)=>{
                                setEdges((prev)=>(0,_xyflow_react__WEBPACK_IMPORTED_MODULE_41__.applyEdgeChanges)([
                                        changes
                                    ], prev));
                                closeAllPopovers();
                            }
                        }, editingEdgeId)
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_48__["default"], {
                    open: openErrorToast,
                    onClose: (_, reason)=>{
                        if (reason === 'clickaway') {
                            return;
                        }
                        setOpenErrorToast(false);
                    },
                    anchorOrigin: {
                        vertical: 'bottom',
                        horizontal: 'center'
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_49__["default"], {
                        onClose: ()=>setOpenErrorToast(false),
                        severity: "error",
                        children: errorToast
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_48__["default"], {
                    open: draftStorageFailed,
                    anchorOrigin: {
                        vertical: 'bottom',
                        horizontal: 'center'
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_49__["default"], {
                        severity: "warning",
                        children: "Draft recovery is unavailable. Save your diagram to a file before leaving."
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_new_diagram_dialog__WEBPACK_IMPORTED_MODULE_19__.NewDiagramDialog, {
                    open: openNewDiagramDialog,
                    canSave: enableExport && !hasUncommittedBuffers,
                    onCancel: ()=>setOpenNewDiagramDialog(false),
                    onDiscard: ()=>{
                        setOpenNewDiagramDialog(false);
                        resetToNewDiagram();
                    },
                    onSave: ()=>{
                        if (!enableExport || hasUncommittedBuffers) {
                            return;
                        }
                        setOpenNewDiagramDialog(false);
                        newDiagramAfterExport.begin();
                        setOpenExportDiagramDialog(true);
                    }
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_50__["default"], {
                    open: recoveryCandidate !== null,
                    disableEscapeKeyDown: true,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_51__["default"], {
                            children: "Restore previous diagram?"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_52__["default"], {
                            children: (recoveryCandidate === null || recoveryCandidate === void 0 ? void 0 : recoveryCandidate.linkedDiagram) ? 'Restore the previous diagram from this tab, or replace it with the linked diagram.' : 'Restore the diagram from before the refresh, or start with an empty diagram.'
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_53__["default"], {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_54__["default"], {
                                    onClick: discardRecoveryDraft,
                                    children: (recoveryCandidate === null || recoveryCandidate === void 0 ? void 0 : recoveryCandidate.linkedDiagram) ? 'Load Linked Diagram' : 'Start Empty'
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_54__["default"], {
                                    variant: "contained",
                                    onClick: restoreRecoveryDraft,
                                    children: "Restore"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react__WEBPACK_IMPORTED_MODULE_1__.Suspense, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_export_diagram_dialog__WEBPACK_IMPORTED_MODULE_13__.ExportDiagramDialog, {
                        open: openExportDiagramDialog,
                        suggestedFilename: recentlyUsedFilename,
                        onExportCompleted: newDiagramAfterExport.complete,
                        onClose: ()=>{
                            setOpenExportDiagramDialog(false);
                            newDiagramAfterExport.cancel();
                        },
                        onValidDiagram: (maybeValid)=>{
                            setEnableExport(maybeValid.ok);
                            if (!maybeValid.ok) {
                                showErrorToast(maybeValid.errorMessage);
                            }
                        }
                    })
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DiagramEditor);


}),
691: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  DiagramPropertiesProvider: () => (DiagramPropertiesProvider),
  createEmptyDiagramProperties: () => (createEmptyDiagramProperties),
  useDiagramProperties: () => (useDiagramProperties)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function createEmptyDiagramProperties() {
    return {
        description: '',
        input_examples: [],
        script_environments: {}
    };
}
const DiagramPropertiesContextComp = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
function DiagramPropertiesProvider(param) {
    let { children } = param;
    const [diagramProperties, setDiagramProperties] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(createEmptyDiagramProperties);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(DiagramPropertiesContextComp.Provider, {
        value: [
            diagramProperties,
            setDiagramProperties
        ],
        children: children
    });
}
const useDiagramProperties = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(DiagramPropertiesContextComp);
    if (!context) {
        throw new Error('useDiagramProperties must be used within a TemplatesProvider');
    }
    return context;
};


}),
769: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  DiagramSidePanelProvider: () => (DiagramSidePanelProvider),
  useDiagramSidePanel: () => (useDiagramSidePanel)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const InitialState = {
    open: true,
    tab: 'properties',
    mode: 'view',
    expanded: false
};
const DiagramSidePanelContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
function DiagramSidePanelProvider(param) {
    let { children } = param;
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(InitialState);
    const close = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setState((prev)=>({
                ...prev,
                open: false,
                mode: 'view',
                expanded: false
            }));
    }, []);
    const showTab = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((tab)=>{
        setState((prev)=>({
                ...prev,
                open: true,
                tab,
                mode: tab === 'environments' ? prev.mode : 'view',
                expanded: tab === 'environments' ? prev.expanded : false
            }));
    }, []);
    const toggleTab = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((tab)=>{
        setState((prev)=>{
            if (prev.open && prev.tab === tab) {
                return {
                    ...prev,
                    open: false,
                    mode: 'view',
                    expanded: false
                };
            }
            return {
                ...prev,
                open: true,
                tab,
                mode: tab === 'environments' ? prev.mode : 'view',
                expanded: tab === 'environments' ? prev.expanded : false
            };
        });
    }, []);
    const openEnvironments = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function() {
        let { environmentName, create = false } = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        setState((prev)=>({
                ...prev,
                open: true,
                tab: 'environments',
                selectedEnvironmentName: environmentName,
                mode: create ? 'create' : 'view',
                expanded: create
            }));
    }, []);
    const selectEnvironment = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((name)=>{
        setState((prev)=>({
                ...prev,
                selectedEnvironmentName: name
            }));
    }, []);
    const startEnvironmentCreate = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setState((prev)=>({
                ...prev,
                open: true,
                tab: 'environments',
                selectedEnvironmentName: undefined,
                mode: 'create',
                expanded: true
            }));
    }, []);
    const startEnvironmentEdit = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setState((prev)=>({
                ...prev,
                open: true,
                tab: 'environments',
                mode: 'edit',
                expanded: true
            }));
    }, []);
    const finishEnvironmentEdit = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setState((prev)=>({
                ...prev,
                mode: 'view',
                expanded: false
            }));
    }, []);
    const setExpanded = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((expanded)=>{
        setState((prev)=>({
                ...prev,
                expanded
            }));
    }, []);
    const value = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>({
            state,
            close,
            showTab,
            toggleTab,
            openEnvironments,
            selectEnvironment,
            startEnvironmentCreate,
            startEnvironmentEdit,
            finishEnvironmentEdit,
            setExpanded
        }), [
        close,
        finishEnvironmentEdit,
        openEnvironments,
        selectEnvironment,
        setExpanded,
        showTab,
        startEnvironmentCreate,
        startEnvironmentEdit,
        state,
        toggleTab
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(DiagramSidePanelContext.Provider, {
        value: value,
        children: children
    });
}
function useDiagramSidePanel() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(DiagramSidePanelContext);
    if (!context) {
        throw new Error('useDiagramSidePanel must be used within a DiagramSidePanelProvider');
    }
    return context;
}


}),
815: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  EditPopoverMargin: () => (EditPopoverMargin),
  EditPopoverSidePanelGap: () => (EditPopoverSidePanelGap),
  EditPopoverWidth: () => (EditPopoverWidth),
  ExpandedSidePanelWidth: () => (ExpandedSidePanelWidth),
  MinimumVisibleCanvasWidth: () => (MinimumVisibleCanvasWidth),
  NormalSidePanelWidth: () => (NormalSidePanelWidth),
  constrainEditPopoverPosition: () => (constrainEditPopoverPosition),
  getDiagramSidePanelWidth: () => (getDiagramSidePanelWidth),
  getEditPopoverPositionForNode: () => (getEditPopoverPositionForNode)
});
const NormalSidePanelWidth = 420;
const ExpandedSidePanelWidth = 900;
const MinimumVisibleCanvasWidth = 56;
const EditPopoverWidth = 420;
const EditPopoverMargin = 16;
const EditPopoverSidePanelGap = 16;
function getDiagramSidePanelWidth(viewportWidth, sidePanel) {
    if (!sidePanel.open) {
        return 0;
    }
    return Math.min(sidePanel.expanded ? ExpandedSidePanelWidth : NormalSidePanelWidth, Math.max(0, viewportWidth - MinimumVisibleCanvasWidth));
}
/** Right edge of the area the edit popover may occupy. */ function getEditPopoverRightBoundary(viewportWidth, sidePanel) {
    const sidePanelWidth = getDiagramSidePanelWidth(viewportWidth, sidePanel);
    return viewportWidth - sidePanelWidth - (sidePanelWidth > 0 ? EditPopoverSidePanelGap : EditPopoverMargin);
}
function constrainEditPopoverPosition(param) {
    let { anchorPosition, viewportWidth, sidePanel } = param;
    const maximumLeft = getEditPopoverRightBoundary(viewportWidth, sidePanel) - EditPopoverWidth;
    return {
        left: Math.max(EditPopoverMargin, Math.min(anchorPosition.left, maximumLeft)),
        top: anchorPosition.top
    };
}
/** Places the edit popover beside a node, flipping to its left when it would not fit. */ function getEditPopoverPositionForNode(param) {
    let { nodeRect, viewportWidth, sidePanel } = param;
    const rightOfNode = nodeRect.right + EditPopoverMargin;
    const fitsRight = rightOfNode + EditPopoverWidth <= getEditPopoverRightBoundary(viewportWidth, sidePanel);
    return {
        left: fitsRight ? rightOfNode : nodeRect.left - EditPopoverWidth - EditPopoverMargin,
        top: nodeRect.top
    };
}


}),
768: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(437);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(816);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(819);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(827);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(766);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(584);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(802);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(332);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(522);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(535);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(829);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(833);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(810);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(835);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(838);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(840);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(842);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(678);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var uuid__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(311);
/* ESM import */var _diagram_properties_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(691);
/* ESM import */var _diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(769);
/* ESM import */var _forms_script_environment_workspace__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(770);
/* ESM import */var _load_context_provider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(811);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(147);
/* ESM import */var _run_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(812);
/* ESM import */var _use_responsive_edit_popover_position__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(814);











const EmptyInputExample = {
    description: '',
    value: undefined
};
function getInputExampleRequestJson(input) {
    if (typeof input.value === 'string') {
        return input.value;
    }
    return JSON.stringify(input.value, null, 2) || '';
}
function DiagramSidePanel(param) {
    let { runRequestJson, onRunRequestJsonChange, scriptNodeBinding } = param;
    const { state: { open, tab, expanded }, close, showTab } = (0,_diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_3__.useDiagramSidePanel)();
    const [diagramProperties, setDiagramProperties] = (0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_2__.useDiagramProperties)();
    const loadContext = (0,_load_context_provider__WEBPACK_IMPORTED_MODULE_5__.useLoadContext)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"])();
    const drawerWidth = (0,_use_responsive_edit_popover_position__WEBPACK_IMPORTED_MODULE_8__.useDiagramSidePanelWidth)();
    const widthTransition = theme.transitions.create('width', {
        easing: theme.transitions.easing.easeInOut,
        duration: theme.transitions.duration.standard
    });
    const [copyTooltipText, setCopyTooltipText] = react__WEBPACK_IMPORTED_MODULE_1___default().useState('Copy this input example into clipboard');
    const [openAddExampleDialog, setOpenAddExampleDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [newInputExample, setNewInputExample] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(EmptyInputExample);
    const [localExamples, setLocalExamples] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([]);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        const examples = (loadContext === null || loadContext === void 0 ? void 0 : loadContext.diagram.input_examples) ?? [];
        setLocalExamples(examples.map((ex)=>({
                ...ex,
                id: (0,uuid__WEBPACK_IMPORTED_MODULE_10__["default"])()
            })));
        setDiagramProperties({
            description: (loadContext === null || loadContext === void 0 ? void 0 : loadContext.diagram.description) ?? '',
            input_examples: examples,
            script_environments: (loadContext === null || loadContext === void 0 ? void 0 : loadContext.diagram.script_environments) ?? {}
        });
    }, [
        loadContext,
        setDiagramProperties
    ]);
    const inputExampleInvalid = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        return newInputExample.description === '' || newInputExample.value === undefined || newInputExample.value === '';
    }, [
        newInputExample
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                sx: {
                    width: drawerWidth,
                    flexShrink: 0,
                    transition: widthTransition,
                    '& .MuiDrawer-paper': {
                        width: drawerWidth,
                        display: 'flex',
                        flexDirection: 'column',
                        overflowX: 'hidden',
                        transition: widthTransition
                    }
                },
                variant: "persistent",
                anchor: "right",
                open: open,
                "data-testid": "diagram-side-panel-paper",
                "data-expanded": expanded,
                style: {
                    width: drawerWidth,
                    transition: widthTransition
                },
                slotProps: {
                    paper: {
                        style: {
                            width: drawerWidth,
                            transition: widthTransition
                        }
                    }
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                        direction: "row",
                        sx: {
                            alignItems: 'center',
                            px: 2,
                            pt: 1
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                value: tab,
                                onChange: (_, value)=>showTab(value),
                                sx: {
                                    minHeight: 40,
                                    minWidth: 0,
                                    flex: 1,
                                    '& .MuiTab-root': {
                                        minWidth: 0,
                                        minHeight: 40,
                                        px: 1,
                                        fontSize: '0.75rem'
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                        value: "properties",
                                        label: "Properties",
                                        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                            symbol: "info"
                                        }),
                                        iconPosition: "start"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                        value: "run",
                                        label: "Run",
                                        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                            symbol: "play_arrow"
                                        }),
                                        iconPosition: "start"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                        value: "environments",
                                        label: "Environments",
                                        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                            symbol: "code"
                                        }),
                                        iconPosition: "start"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                title: "Hide this panel",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                    onClick: close,
                                    sx: {
                                        ml: 'auto',
                                        flexShrink: 0
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                        symbol: "close"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                        sx: {
                            display: tab === 'run' ? 'flex' : 'none',
                            flexDirection: 'column',
                            flex: 1,
                            minHeight: 0
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_run_button__WEBPACK_IMPORTED_MODULE_7__.RunPanel, {
                            requestJsonString: runRequestJson,
                            onRequestJsonStringChange: onRunRequestJsonChange
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                        sx: {
                            display: tab === 'properties' ? 'flex' : 'none',
                            flexDirection: 'column',
                            flex: 1,
                            minHeight: 0
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                            spacing: 2,
                            sx: {
                                minHeight: 0,
                                overflowY: 'auto',
                                p: 2
                            },
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                    direction: "row",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                        direction: "row",
                                        spacing: 2,
                                        sx: {
                                            alignItems: 'center'
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                                                variant: "h6",
                                                children: "Description"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                title: "General description of what this diagram achieves, as well as any other relevant information that may help a user understand its execution.",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                                    symbol: "info",
                                                    fontSize: "large"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_20__["default"], {
                                    fullWidth: true,
                                    multiline: true,
                                    rows: 10,
                                    variant: "outlined",
                                    value: (diagramProperties === null || diagramProperties === void 0 ? void 0 : diagramProperties.description) ?? '',
                                    slotProps: {
                                        htmlInput: {
                                            sx: {
                                                fontFamily: 'monospace'
                                            }
                                        }
                                    },
                                    onChange: (d)=>setDiagramProperties((prev)=>({
                                                ...prev,
                                                description: d.target.value
                                            })),
                                    sx: {
                                        backgroundColor: theme.palette.background.paper
                                    }
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                    direction: "row",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                            direction: "row",
                                            spacing: 2,
                                            sx: {
                                                alignItems: 'center'
                                            },
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                                                    variant: "h6",
                                                    children: "Input Examples"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                    title: "Input examples that can be executed with this workflow",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                                        symbol: "info",
                                                        fontSize: "large"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                            direction: "row",
                                            sx: {
                                                marginLeft: 'auto'
                                            },
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                title: "Add input example",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                                    onClick: ()=>setOpenAddExampleDialog(true),
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                                        symbol: "add"
                                                    })
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_21__["default"], {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_22__["default"], {
                                        children: localExamples.length > 0 ? localExamples.map((input, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_23__["default"], {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_20__["default"], {
                                                    fullWidth: true,
                                                    multiline: true,
                                                    variant: "outlined",
                                                    value: getInputExampleRequestJson(input),
                                                    rows: "6",
                                                    slotProps: {
                                                        htmlInput: {
                                                            sx: {
                                                                fontFamily: 'monospace'
                                                            }
                                                        },
                                                        input: {
                                                            endAdornment: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                                                position: "end",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                                                    direction: "column",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                                            title: input.description,
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                                                                    symbol: "info",
                                                                                    fontSize: "large"
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                                            title: "Delete input example",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                                                                onClick: ()=>{
                                                                                    setLocalExamples((prev)=>[
                                                                                            ...prev.slice(0, index),
                                                                                            ...prev.slice(index + 1)
                                                                                        ]);
                                                                                    setDiagramProperties((prev)=>{
                                                                                        const prevInputExamples = prev.input_examples ?? [];
                                                                                        if (index >= prevInputExamples.length) {
                                                                                            return prev;
                                                                                        }
                                                                                        return {
                                                                                            ...prev,
                                                                                            input_examples: [
                                                                                                ...prevInputExamples.slice(0, index),
                                                                                                ...prevInputExamples.slice(index + 1)
                                                                                            ]
                                                                                        };
                                                                                    });
                                                                                },
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                                                                    symbol: "delete",
                                                                                    fontSize: "large"
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                                            title: copyTooltipText,
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                                                                onClick: async ()=>{
                                                                                    const content = getInputExampleRequestJson(input);
                                                                                    await navigator.clipboard.writeText(content);
                                                                                    setCopyTooltipText('Copied into clipboard!');
                                                                                    setTimeout(()=>{
                                                                                        setCopyTooltipText('Copy this input example');
                                                                                    }, 3000);
                                                                                },
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                                                                    symbol: "content_copy",
                                                                                    fontSize: "large"
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                                            title: "Run diagram with this input example",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                                                                onClick: ()=>{
                                                                                    onRunRequestJsonChange(getInputExampleRequestJson(input));
                                                                                    showTab('run');
                                                                                },
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                                                                    symbol: "play_arrow",
                                                                                    fontSize: "large"
                                                                                })
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        }
                                                    }
                                                })
                                            }, input.id)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_23__["default"], {
                                            sx: {
                                                textAlign: 'center'
                                            },
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_25__["default"], {
                                                slotProps: {
                                                    primary: {
                                                        color: theme.palette.text.disabled
                                                    }
                                                },
                                                primary: "No input examples available"
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                        sx: {
                            display: tab === 'environments' ? 'flex' : 'none',
                            flexDirection: 'column',
                            flex: 1,
                            minHeight: 0
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_forms_script_environment_workspace__WEBPACK_IMPORTED_MODULE_4__.ScriptEnvironmentWorkspace, {
                            scriptNodeBinding: scriptNodeBinding
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_26__["default"], {
                onClose: ()=>{
                    setOpenAddExampleDialog(false);
                    setNewInputExample(EmptyInputExample);
                },
                open: openAddExampleDialog,
                fullWidth: true,
                maxWidth: "sm",
                keepMounted: false,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_27__["default"], {
                        children: "Add input example"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_28__["default"], {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                                    variant: "body1",
                                    children: "Value"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_20__["default"], {
                                    fullWidth: true,
                                    multiline: true,
                                    rows: 6,
                                    variant: "outlined",
                                    value: newInputExample.value,
                                    onChange: (e)=>setNewInputExample((prev)=>({
                                                ...prev,
                                                value: e.target.value
                                            }))
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                                    variant: "body1",
                                    children: "Description"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_20__["default"], {
                                    fullWidth: true,
                                    multiline: true,
                                    rows: 3,
                                    variant: "outlined",
                                    value: newInputExample.description,
                                    onChange: (e)=>setNewInputExample((prev)=>({
                                                ...prev,
                                                description: e.target.value
                                            }))
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_29__["default"], {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_30__["default"], {
                            variant: "contained",
                            onClick: ()=>{
                                const newLocalExample = {
                                    ...newInputExample,
                                    id: (0,uuid__WEBPACK_IMPORTED_MODULE_10__["default"])()
                                };
                                setLocalExamples((prev)=>[
                                        ...prev,
                                        newLocalExample
                                    ]);
                                setDiagramProperties((prev)=>{
                                    const prevInputExamples = prev.input_examples ?? [];
                                    return {
                                        ...prev,
                                        input_examples: [
                                            ...prevInputExamples,
                                            newInputExample
                                        ]
                                    };
                                });
                                setOpenAddExampleDialog(false);
                                setNewInputExample(EmptyInputExample);
                            },
                            startIcon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                symbol: "add"
                            }),
                            disabled: inputExampleInvalid,
                            children: "Add"
                        })
                    })
                ]
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DiagramSidePanel);


}),
846: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  EMPTY_TRANSIENT_EDITOR_DRAFTS: () => (EMPTY_TRANSIENT_EDITOR_DRAFTS),
  clearDraftWorkspace: () => (clearDraftWorkspace),
  draftStorageKey: () => (draftStorageKey),
  draftWorkspaceFingerprint: () => (draftWorkspaceFingerprint),
  isDraftWorkspaceV1: () => (isDraftWorkspaceV1),
  readDraftWorkspace: () => (readDraftWorkspace),
  writeDraftWorkspace: () => (writeDraftWorkspace)
});
const DRAFT_KEY_PREFIX = 'crossflow-diagram-editor:draft:v1:';
const EMPTY_TRANSIENT_EDITOR_DRAFTS = {
    operationConfigs: {}
};
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function isPersistedGraph(value) {
    return isRecord(value) && Array.isArray(value.nodes) && Array.isArray(value.edges);
}
function isStringRecord(value) {
    return isRecord(value) && Object.values(value).every(isString);
}
function isString(value) {
    return typeof value === 'string';
}
function isScriptEnvironmentEditorDraft(value) {
    return isRecord(value) && isString(value.selectedEnvName) && (value.mode === 'edit' || value.mode === 'create') && isString(value.envName) && isString(value.builder) && isString(value.config) && isString(value.scriptText) && isString(value.selectedCodeField) && isString(value.language) && typeof value.isExpanded === 'boolean';
}
function isTemplateRenameDraft(value) {
    return isRecord(value) && isString(value.target) && isString(value.newId);
}
function isActiveTemplateDraft(value) {
    return isRecord(value) && isString(value.templateId) && isPersistedGraph(value.graph);
}
function isTransientEditorDrafts(value) {
    return isRecord(value) && isStringRecord(value.operationConfigs) && (value.scriptEnvironment === undefined || isScriptEnvironmentEditorDraft(value.scriptEnvironment)) && (value.templateRename === undefined || isTemplateRenameDraft(value.templateRename));
}
function isDraftWorkspaceV1(value) {
    if (!isRecord(value) || value.version !== 1) {
        return false;
    }
    if (typeof value.savedAt !== 'number' || !isPersistedGraph(value.mainGraph)) {
        return false;
    }
    if (!isRecord(value.templates) || !isRecord(value.diagramProperties) || !isTransientEditorDrafts(value.transientEditors)) {
        return false;
    }
    if (value.filename !== null && typeof value.filename !== 'string') {
        return false;
    }
    if (value.activeTemplate !== undefined && !isActiveTemplateDraft(value.activeTemplate) || value.sourceExtensions !== undefined && !isRecord(value.sourceExtensions)) {
        return false;
    }
    return true;
}
function draftStorageKey(pathname) {
    return `${DRAFT_KEY_PREFIX}${pathname}`;
}
function currentPathname() {
    return window.location.pathname;
}
function currentStorage() {
    return window.sessionStorage;
}
function readDraftWorkspace() {
    let storage = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : currentStorage(), pathname = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : currentPathname();
    const serialized = storage.getItem(draftStorageKey(pathname));
    if (serialized === null) {
        return null;
    }
    const parsed = JSON.parse(serialized);
    if (!isDraftWorkspaceV1(parsed)) {
        throw new Error('unsupported or malformed diagram editor draft');
    }
    return parsed;
}
function writeDraftWorkspace(content) {
    let storage = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : currentStorage(), pathname = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : currentPathname();
    const draft = {
        ...content,
        version: 1,
        savedAt: Date.now()
    };
    storage.setItem(draftStorageKey(pathname), JSON.stringify(draft));
    return draft;
}
function clearDraftWorkspace() {
    let storage = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : currentStorage(), pathname = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : currentPathname();
    storage.removeItem(draftStorageKey(pathname));
}
function draftWorkspaceFingerprint(content) {
    return JSON.stringify(content);
}


}),
300: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  BufferEdgeComp: () => (BufferEdgeComp)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



const BufferEdgeComp = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.memo)((props)=>{
    const label = (()=>{
        switch(props.data.input.type){
            case 'bufferKey':
                {
                    return props.data.input.key || 'Select Key';
                }
            case 'bufferSeq':
                {
                    return props.data.input.seq.toString();
                }
            case 'sectionBuffer':
                {
                    return props.data.input.inputId || 'Select Buffer';
                }
        }
    })();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_2__.StepEdge, {
        ...props,
        label: label
    });
});


}),
310: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  createBaseEdge: () => (createBaseEdge),
  createBufferEdge: () => (createBufferEdge),
  createDefaultEdge: () => (createDefaultEdge),
  createForkResultErrEdge: () => (createForkResultErrEdge),
  createForkResultOkEdge: () => (createForkResultOkEdge),
  createSectionEdge: () => (createSectionEdge),
  createSplitKeyEdge: () => (createSplitKeyEdge),
  createSplitRemainingEdge: () => (createSplitRemainingEdge),
  createSplitSeqEdge: () => (createSplitSeqEdge),
  createStreamOutEdge: () => (createStreamOutEdge),
  createUnzipEdge: () => (createUnzipEdge)
});
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(27);
/* ESM import */var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(311);


function createBaseEdge(source, sourceHandle, target, targetHandle, id) {
    return {
        id: id || (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])(),
        source,
        sourceHandle,
        target,
        targetHandle,
        markerEnd: {
            type: _xyflow_react__WEBPACK_IMPORTED_MODULE_1__.MarkerType.ArrowClosed,
            width: 20,
            height: 20
        }
    };
}
function createDefaultEdge(source, sourceHandle, target, targetHandle, inputSlot) {
    return {
        ...createBaseEdge(source, sourceHandle, target, targetHandle),
        type: 'default',
        data: {
            output: {},
            input: inputSlot || {
                type: 'default'
            }
        }
    };
}
function createUnzipEdge(source, sourceHandle, target, targetHandle, data) {
    return {
        ...createBaseEdge(source, sourceHandle, target, targetHandle),
        type: 'unzip',
        data: {
            output: data,
            input: {
                type: 'default'
            }
        }
    };
}
function createForkResultOkEdge(source, sourceHandle, target, targetHandle) {
    return {
        ...createBaseEdge(source, sourceHandle, target, targetHandle),
        type: 'forkResultOk',
        data: {
            output: {},
            input: {
                type: 'default'
            }
        }
    };
}
function createForkResultErrEdge(source, sourceHandle, target, targetHandle) {
    return {
        ...createBaseEdge(source, sourceHandle, target, targetHandle),
        type: 'forkResultErr',
        data: {
            output: {},
            input: {
                type: 'default'
            }
        }
    };
}
function createSplitKeyEdge(source, sourceHandle, target, targetHandle, data) {
    return {
        ...createBaseEdge(source, sourceHandle, target, targetHandle),
        type: 'splitKey',
        data: {
            output: data,
            input: {
                type: 'default'
            }
        }
    };
}
function createSplitSeqEdge(source, sourceHandle, target, targetHandle, data) {
    return {
        ...createBaseEdge(source, sourceHandle, target, targetHandle),
        type: 'splitSeq',
        data: {
            output: data,
            input: {
                type: 'default'
            }
        }
    };
}
function createSplitRemainingEdge(source, sourceHandle, target, targetHandle) {
    return {
        ...createBaseEdge(source, sourceHandle, target, targetHandle),
        type: 'splitRemaining',
        data: {
            output: {},
            input: {
                type: 'default'
            }
        }
    };
}
function createBufferEdge(source, sourceHandle, target, targetHandle, data) {
    return {
        ...createBaseEdge(source, sourceHandle, target, targetHandle),
        type: 'buffer',
        data: {
            output: {},
            input: data
        }
    };
}
function createStreamOutEdge(source, sourceHandle, target, targetHandle, data) {
    return {
        ...createBaseEdge(source, sourceHandle, target, targetHandle),
        type: 'streamOut',
        data: {
            output: data,
            input: {
                type: 'default'
            }
        }
    };
}
function createSectionEdge(source, sourceHandle, target, targetHandle, data) {
    return {
        ...createBaseEdge(source, sourceHandle, target, targetHandle),
        type: 'section',
        data: {
            output: data,
            input: {
                type: 'default'
            }
        }
    };
}


}),
301: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  DefaultEdgeComp: () => (DefaultEdgeComp)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



const DefaultEdgeComp = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.memo)((props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_2__.StepEdge, {
        ...props,
        label: props.data.input.type !== 'default' ? props.data.input.inputId || 'Select Input' : undefined
    });
});


}),
302: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function ForkResultErrEdgeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_2__.StepEdge, {
        ...props,
        label: "error"
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(ForkResultErrEdgeComp));


}),
303: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function ForkResultOkEdgeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_2__.StepEdge, {
        ...props,
        label: "ok"
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(ForkResultOkEdgeComp));


}),
299: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  BufferFetchType: () => (/* reexport safe */ _input_slots__WEBPACK_IMPORTED_MODULE_11__.BufferFetchType),
  EDGE_CATEGORIES: () => (EDGE_CATEGORIES),
  EDGE_TYPES: () => (EDGE_TYPES),
  EdgeCategory: () => (EdgeCategory),
  createBaseEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createBaseEdge),
  createBufferEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createBufferEdge),
  createDefaultEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createDefaultEdge),
  createForkResultErrEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createForkResultErrEdge),
  createForkResultOkEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createForkResultOkEdge),
  createSectionEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createSectionEdge),
  createSplitKeyEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createSplitKeyEdge),
  createSplitRemainingEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createSplitRemainingEdge),
  createSplitSeqEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createSplitSeqEdge),
  createStreamOutEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createStreamOutEdge),
  createUnzipEdge: () => (/* reexport safe */ _create_edge__WEBPACK_IMPORTED_MODULE_10__.createUnzipEdge),
  isDataEdge: () => (isDataEdge)
});
/* ESM import */var _buffer_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(300);
/* ESM import */var _default_edge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(301);
/* ESM import */var _fork_result_err_edge__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(302);
/* ESM import */var _fork_result_ok_edge__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(303);
/* ESM import */var _section_edge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(304);
/* ESM import */var _split_key_edge__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(305);
/* ESM import */var _split_remaining_edge__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(306);
/* ESM import */var _split_seq_edge__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(307);
/* ESM import */var _stream_out_edge__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(308);
/* ESM import */var _unzip_edge__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(309);
/* ESM import */var _create_edge__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(310);
/* ESM import */var _input_slots__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(317);












const EDGE_TYPES = {
    default: _default_edge__WEBPACK_IMPORTED_MODULE_1__.DefaultEdgeComp,
    unzip: _unzip_edge__WEBPACK_IMPORTED_MODULE_9__["default"],
    forkResultOk: _fork_result_ok_edge__WEBPACK_IMPORTED_MODULE_3__["default"],
    forkResultErr: _fork_result_err_edge__WEBPACK_IMPORTED_MODULE_2__["default"],
    splitKey: _split_key_edge__WEBPACK_IMPORTED_MODULE_5__["default"],
    splitSeq: _split_seq_edge__WEBPACK_IMPORTED_MODULE_7__["default"],
    splitRemaining: _split_remaining_edge__WEBPACK_IMPORTED_MODULE_6__["default"],
    buffer: _buffer_edge__WEBPACK_IMPORTED_MODULE_0__.BufferEdgeComp,
    streamOut: _stream_out_edge__WEBPACK_IMPORTED_MODULE_8__["default"],
    section: _section_edge__WEBPACK_IMPORTED_MODULE_4__.SectionOutputEdgeComp
};
var EdgeCategory = /*#__PURE__*/ function(EdgeCategory) {
    EdgeCategory[EdgeCategory["Data"] = 0] = "Data";
    EdgeCategory[EdgeCategory["Buffer"] = 1] = "Buffer";
    return EdgeCategory;
}({});
const EDGE_CATEGORIES = {
    buffer: 1,
    forkResultOk: 0,
    forkResultErr: 0,
    splitKey: 0,
    splitSeq: 0,
    splitRemaining: 0,
    default: 0,
    streamOut: 0,
    unzip: 0,
    section: 0
};
function isDataEdge(edge) {
    return EDGE_CATEGORIES[edge.type] === 0;
}


}),
317: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  BufferFetchType: () => (BufferFetchType)
});
var BufferFetchType = /*#__PURE__*/ function(BufferFetchType) {
    BufferFetchType[BufferFetchType["Pull"] = 0] = "Pull";
    BufferFetchType[BufferFetchType["Clone"] = 1] = "Clone";
    return BufferFetchType;
}({});


}),
304: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  SectionOutputEdgeComp: () => (SectionOutputEdgeComp)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



const SectionOutputEdgeComp = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.memo)((props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_2__.StepEdge, {
        ...props,
        label: props.data.output.output || 'Select Output'
    });
});


}),
305: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function SplitKeyEdgeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_2__.StepEdge, {
        ...props,
        label: props.data.output.key.toString()
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(SplitKeyEdgeComp));


}),
306: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function SplitRemainingEdgeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_2__.StepEdge, {
        ...props,
        label: "*"
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(SplitRemainingEdgeComp));


}),
307: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function SplitSeqEdgeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_2__.StepEdge, {
        ...props,
        label: props.data.output.seq.toString()
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(SplitSeqEdgeComp));


}),
308: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function StreamOutEdgeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_2__.StepEdge, {
        ...props,
        label: `stream: ${props.data.output.streamId}`
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(StreamOutEdgeComp));


}),
309: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function UnzipEdgeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_2__.StepEdge, {
        ...props,
        label: props.data.output.seq.toString()
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(UnzipEdgeComp));


}),
844: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(437);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(835);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(838);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(840);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(522);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(535);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(829);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(810);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(713);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(678);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(766);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(802);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(842);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _editor_mode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(144);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(147);
/* ESM import */var _templates_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(459);
/* ESM import */var _transient_editor_drafts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(845);







function EditTemplatesDialog(param) {
    let { open, onClose } = param;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"])();
    const [templates, setTemplates] = (0,_templates_provider__WEBPACK_IMPORTED_MODULE_4__.useTemplates)();
    const templateKeys = Object.keys(templates);
    const [_editorMode, setEditorMode] = (0,_editor_mode__WEBPACK_IMPORTED_MODULE_2__.useEditorMode)();
    const { drafts, setTemplateRenameDraft } = (0,_transient_editor_drafts__WEBPACK_IMPORTED_MODULE_5__.useTransientEditorDrafts)();
    const [renaming, setRenaming] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const [newId, setNewId] = react__WEBPACK_IMPORTED_MODULE_1___default().useState('');
    const renamingRef = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(null);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (!renamingRef.current || !renaming) {
            return;
        }
        renamingRef.current.focus();
        if (renaming.selectAll) {
            renamingRef.current.select();
        }
        if (renaming.scrollTo) {
            renamingRef.current.scrollTo({
                behavior: 'smooth'
            });
        }
    }, [
        renaming
    ]);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (open && drafts.templateRename) {
            setRenaming({
                target: drafts.templateRename.target
            });
            setNewId(drafts.templateRename.newId);
        }
    }, [
        drafts.templateRename,
        open
    ]);
    const handleSubmitRenaming = ()=>{
        const newTemplates = {};
        // rebuild the templates in a way that keeps ordering
        for (const [id, template] of Object.entries(templates)){
            if (id === (renaming === null || renaming === void 0 ? void 0 : renaming.target)) {
                newTemplates[newId] = template;
            } else {
                newTemplates[id] = template;
            }
        }
        setRenaming(null);
        setNewId('');
        setTemplateRenameDraft(undefined);
        setTemplates(newTemplates);
    };
    const handleDeleteTemplate = (id)=>{
        if ((renaming === null || renaming === void 0 ? void 0 : renaming.target) === id) {
            setRenaming(null);
            setNewId('');
            setTemplateRenameDraft(undefined);
        }
        setTemplates((prev)=>{
            const newTemplates = {
                ...prev
            };
            delete newTemplates[id];
            return newTemplates;
        });
    };
    const requestClose = ()=>{
        if (drafts.templateRename && !window.confirm('Discard the unfinished template rename?')) {
            return;
        }
        setRenaming(null);
        setNewId('');
        setTemplateRenameDraft(undefined);
        onClose();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
        open: open,
        onClose: requestClose,
        fullWidth: true,
        maxWidth: "sm",
        keepMounted: false,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                children: "Templates"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                            disablePadding: true,
                            sx: {
                                maxHeight: '24rem',
                                overflow: 'auto'
                            },
                            children: templateKeys.length > 0 ? templateKeys.map((id)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                    divider: true,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                        direction: "row",
                                        alignItems: "center",
                                        width: "100%",
                                        height: "3em",
                                        children: [
                                            (renaming === null || renaming === void 0 ? void 0 : renaming.target) === id ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("form", {
                                                    onSubmit: handleSubmitRenaming,
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                                        size: "small",
                                                        fullWidth: true,
                                                        value: newId,
                                                        onChange: (ev)=>{
                                                            setNewId(ev.target.value);
                                                            setTemplateRenameDraft({
                                                                target: id,
                                                                newId: ev.target.value
                                                            });
                                                        },
                                                        inputRef: renamingRef,
                                                        onSubmit: handleSubmitRenaming
                                                    })
                                                })
                                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                                children: id
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                                variant: "contained",
                                                children: [
                                                    (renaming === null || renaming === void 0 ? void 0 : renaming.target) === id ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                        onClick: handleSubmitRenaming,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_3__.MaterialSymbol, {
                                                            symbol: "check"
                                                        })
                                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                                        title: "Rename",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                            onClick: ()=>{
                                                                setRenaming({
                                                                    target: id
                                                                });
                                                                setNewId(id);
                                                                setTemplateRenameDraft({
                                                                    target: id,
                                                                    newId: id
                                                                });
                                                            },
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_3__.MaterialSymbol, {
                                                                symbol: "text_select_start"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                                        title: "Edit",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                            onClick: ()=>{
                                                                setTemplateRenameDraft(undefined);
                                                                setEditorMode({
                                                                    mode: _editor_mode__WEBPACK_IMPORTED_MODULE_2__.EditorMode.Template,
                                                                    templateId: id
                                                                });
                                                                onClose();
                                                            },
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_3__.MaterialSymbol, {
                                                                symbol: "edit"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                                        title: "Delete",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                            variant: "outlined",
                                                            color: "error",
                                                            onClick: ()=>handleDeleteTemplate(id),
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_3__.MaterialSymbol, {
                                                                symbol: "delete"
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }, id)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                divider: true,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                                    slotProps: {
                                        primary: {
                                            color: theme.palette.text.disabled
                                        }
                                    },
                                    children: "No templates available"
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {}),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                justifyContent: "center",
                                width: "100%",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                    onClick: ()=>{
                                        const baseId = 'new_template';
                                        let newId = baseId;
                                        let i = 0;
                                        while(newId in templates){
                                            newId = `${baseId}_${++i}`;
                                        }
                                        setNewId(newId);
                                        setTemplates((prev)=>{
                                            return {
                                                ...prev,
                                                [newId]: {
                                                    inputs: {},
                                                    outputs: [],
                                                    buffers: {},
                                                    ops: {}
                                                }
                                            };
                                        });
                                        setRenaming({
                                            target: newId,
                                            selectAll: true,
                                            scrollTo: true
                                        });
                                        setTemplateRenameDraft({
                                            target: newId,
                                            newId
                                        });
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_3__.MaterialSymbol, {
                                        symbol: "add"
                                    })
                                })
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_20__["default"], {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                    onClick: requestClose,
                    children: "Close"
                })
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditTemplatesDialog);


}),
144: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  EditorMode: () => (EditorMode),
  EditorModeProvider: () => (EditorModeProvider),
  useEditorMode: () => (useEditorMode)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var EditorMode = /*#__PURE__*/ function(EditorMode) {
    EditorMode[EditorMode["Normal"] = 0] = "Normal";
    EditorMode[EditorMode["Template"] = 1] = "Template";
    return EditorMode;
}({});
const EditorModeContextComp = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
function EditorModeProvider(param) {
    let { value, children } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(EditorModeContextComp.Provider, {
        value: value,
        children: children
    });
}
function useEditorMode() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(EditorModeContextComp);
    if (!context) {
        throw new Error('useEditorMode must be used within a EditorModeProvider');
    }
    return context;
}


}),
849: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ExportDiagramDialog: () => (ExportDiagramDialog)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(437);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(835);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(838);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(840);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(713);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(678);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(842);
/* ESM import */var fflate__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(142);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _diagram_properties_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(691);
/* ESM import */var _load_context_provider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(811);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(147);
/* ESM import */var _persist_state__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(850);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(321);
/* ESM import */var _templates_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(459);
/* ESM import */var _use_edges__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(813);
/* ESM import */var _utils_export_diagram__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(670);













function ExportDiagramDialogInternal(param) {
    let { open, suggestedFilename, onExportCompleted, onClose, onValidDiagram } = param;
    const nodeManager = (0,_node_manager__WEBPACK_IMPORTED_MODULE_4__.useNodeManager)();
    const edges = (0,_use_edges__WEBPACK_IMPORTED_MODULE_9__.useEdges)();
    const [templates] = (0,_templates_provider__WEBPACK_IMPORTED_MODULE_8__.useTemplates)();
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_7__.useRegistry)();
    const loadContext = (0,_load_context_provider__WEBPACK_IMPORTED_MODULE_3__.useLoadContext)();
    const [diagramProperties] = (0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_2__.useDiagramProperties)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"])();
    const dialogDataPromise = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(async ()=>{
        try {
            const diagram = (0,_utils_export_diagram__WEBPACK_IMPORTED_MODULE_10__.exportDiagram)(registry, nodeManager, edges, templates, diagramProperties ?? {});
            if (loadContext === null || loadContext === void 0 ? void 0 : loadContext.diagram.extensions) {
                diagram.extensions = loadContext.diagram.extensions;
            }
            await (0,_persist_state__WEBPACK_IMPORTED_MODULE_6__.saveState)(diagram, {
                nodes: [
                    ...nodeManager.nodes
                ],
                edges: [
                    ...edges
                ]
            });
            const diagramJsonMin = JSON.stringify(diagram);
            // Compress the JSON string to Uint8Array
            const compressedData = (0,fflate__WEBPACK_IMPORTED_MODULE_12__.deflateSync)((0,fflate__WEBPACK_IMPORTED_MODULE_12__.strToU8)(diagramJsonMin));
            // Convert Uint8Array to a binary string for btoa
            let binaryString = '';
            for(let i = 0; i < compressedData.length; i++){
                binaryString += String.fromCharCode(compressedData[i]);
            }
            const base64Diagram = btoa(binaryString);
            const shareLink = `${window.location.origin}${window.location.pathname}?diagram=${encodeURIComponent(base64Diagram)}`;
            const diagramJsonPretty = JSON.stringify(diagram, null, 2);
            const dialogData = {
                shareLink,
                diagramJson: diagramJsonPretty
            };
            onValidDiagram({
                ok: true
            });
            return dialogData;
        } catch (e) {
            onValidDiagram({
                ok: false,
                errorMessage: `failed to export diagram: ${e}`
            });
            return null;
        }
    }, [
        registry,
        nodeManager,
        edges,
        templates,
        loadContext,
        diagramProperties,
        onValidDiagram
    ]);
    const dialogData = (0,react__WEBPACK_IMPORTED_MODULE_1__.use)(dialogDataPromise);
    const [downloaded, setDownloaded] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const handleDownload = async ()=>{
        if (!dialogData) {
            return;
        }
        const blob = new Blob([
            dialogData.diagramJson
        ], {
            type: 'application/json'
        });
        if ('showSaveFilePicker' in window) {
            try {
                // TODO(aaronchong): add proper types for showSaveFilePicker once it is no longer experimental upstream
                // biome-ignore lint/suspicious/noExplicitAny: showSaveFilePicker is not in standard Window types
                const handle = await window.showSaveFilePicker({
                    suggestedName: suggestedFilename ?? 'diagram.json',
                    types: [
                        {
                            description: 'JSON File',
                            accept: {
                                'application/json': [
                                    '.json'
                                ]
                            }
                        }
                    ]
                });
                const exportedFilename = handle.name;
                const writable = await handle.createWritable();
                await writable.write(blob);
                await writable.close();
                setDownloaded(exportedFilename);
                return;
            } catch (err) {
                if (err.name === 'AbortError') {
                    return;
                }
            }
        }
        // The showSaveFilePicker API might not be supported in some browsers,
        // fallback to the default method of downloading to just diagram.json if it
        // fails.
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'diagram.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setDownloaded('diagram.json');
    };
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (downloaded === null || downloaded.length === 0) {
            return;
        }
        onExportCompleted(downloaded);
        setTimeout(()=>{
            setDownloaded(null);
        }, 5000);
    }, [
        downloaded,
        onExportCompleted
    ]);
    const [copiedShareLink, setCopiedShareLink] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
        onClose: ()=>{
            onClose();
            setCopiedShareLink(false);
        },
        open: open,
        fullWidth: true,
        maxWidth: "md",
        keepMounted: false,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                children: "Export Diagram"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                            variant: "h6",
                            children: "Share"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                                    variant: "outlined",
                                    value: dialogData === null || dialogData === void 0 ? void 0 : dialogData.shareLink,
                                    fullWidth: true,
                                    size: "small"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_20__["default"], {
                                    variant: "contained",
                                    "aria-label": "copy share link",
                                    onClick: ()=>{
                                        if (!dialogData || copiedShareLink) {
                                            return;
                                        }
                                        navigator.clipboard.writeText(dialogData.shareLink);
                                        setCopiedShareLink(true);
                                    },
                                    children: copiedShareLink ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_5__.MaterialSymbol, {
                                        symbol: "check"
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_5__.MaterialSymbol, {
                                        symbol: "content_copy"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                            direction: "row",
                            justifyContent: "space-between",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                    variant: "h6",
                                    children: "Export JSON"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_20__["default"], {
                                    variant: "contained",
                                    onClick: handleDownload,
                                    startIcon: downloaded ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_5__.MaterialSymbol, {
                                        symbol: "check_circle"
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_5__.MaterialSymbol, {
                                        symbol: "download"
                                    }),
                                    sx: {
                                        backgroundColor: downloaded ? theme.palette.success.main : null
                                    },
                                    children: downloaded ? typeof downloaded === 'string' ? `Saved ${downloaded}` : 'Downloaded' : 'Download'
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                            multiline: true,
                            maxRows: 20,
                            variant: "outlined",
                            value: dialogData === null || dialogData === void 0 ? void 0 : dialogData.diagramJson,
                            slotProps: {
                                htmlInput: {
                                    sx: {
                                        fontFamily: 'monospace'
                                    }
                                }
                            }
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_21__["default"], {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_20__["default"], {
                    onClick: onClose,
                    children: "Close"
                })
            })
        ]
    });
}
const ExportDiagramDialog = (props)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react__WEBPACK_IMPORTED_MODULE_1__.Suspense, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ExportDiagramDialogInternal, {
            ...props
        })
    });


}),
655: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(656);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(658);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(584);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(660);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(575);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);



function BaseEditOperationForm(param) {
    let { node, onChange, onDelete, children } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
                title: "Edit Operation",
                action: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
                    color: "error",
                    onClick: ()=>onDelete === null || onDelete === void 0 ? void 0 : onDelete({
                            type: 'remove',
                            id: node.id
                        }),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_1__.MaterialSymbol, {
                        symbol: "delete"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                            required: true,
                            label: "id",
                            fullWidth: true,
                            value: node.data.opId,
                            onChange: (ev)=>{
                                const updatedNode = {
                                    ...node
                                };
                                updatedNode.data.opId = ev.target.value;
                                onChange === null || onChange === void 0 ? void 0 : onChange({
                                    type: 'replace',
                                    id: node.id,
                                    item: updatedNode
                                });
                            }
                        }),
                        children
                    ]
                })
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BaseEditOperationForm);


}),
320: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  BufferEdgeInputForm: () => (BufferEdgeInputForm)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(460);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(466);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(472);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(559);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(579);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _edges__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(299);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(145);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(321);
/* ESM import */var _templates_provider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(459);
/* ESM import */var _utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(319);








function getTemplateBuffers(template) {
    if (!template.buffers) {
        return [];
    }
    if (Array.isArray(template.buffers)) {
        return template.buffers;
    } else {
        return Object.keys(template.buffers);
    }
}
function defaultInputData(inputType) {
    switch(inputType){
        case 'bufferKey':
            {
                return {
                    type: 'bufferKey',
                    key: ''
                };
            }
        case 'bufferSeq':
            {
                return {
                    type: 'bufferSeq',
                    seq: 0
                };
            }
        case 'sectionBuffer':
            {
                return {
                    type: 'sectionBuffer',
                    inputId: ''
                };
            }
        default:
            (0,_utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_6__.exhaustiveCheck)(inputType);
            throw new Error('unknown buffer edge input type');
    }
}
function BufferEdgeInputForm(param) {
    let { edge, onChange } = param;
    const labelId = (0,react__WEBPACK_IMPORTED_MODULE_1__.useId)();
    const nodeManager = (0,_node_manager__WEBPACK_IMPORTED_MODULE_3__.useNodeManager)();
    const sourceNode = nodeManager.tryGetNode(edge.source);
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_4__.useRegistry)();
    const [templates, _setTemplates] = (0,_templates_provider__WEBPACK_IMPORTED_MODULE_5__.useTemplates)();
    const sectionBuffers = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!sourceNode || sourceNode.type !== 'section') {
            return [];
        }
        if (typeof sourceNode.data.op.builder === 'string') {
            const sectionRegistration = registry.sections[sourceNode.data.op.builder];
            return sectionRegistration ? Object.keys(sectionRegistration.interface.buffers) : [];
        } else if (typeof sourceNode.data.op.template === 'string') {
            const template = templates[sourceNode.data.op.template];
            return template ? getTemplateBuffers(template) : [];
        } else {
            return [];
        }
    }, [
        sourceNode,
        registry,
        templates
    ]);
    const handleDataChange = (event)=>{
        switch(edge.data.input.type){
            case 'bufferKey':
                {
                    const newKey = event.target.value;
                    onChange === null || onChange === void 0 ? void 0 : onChange({
                        type: 'replace',
                        id: edge.id,
                        item: {
                            ...edge,
                            data: {
                                ...edge.data,
                                input: {
                                    ...edge.data.input,
                                    key: newKey
                                }
                            }
                        }
                    });
                    break;
                }
            case 'bufferSeq':
                {
                    const newSeq = Number.parseInt(event.target.value, 10);
                    if (!Number.isNaN(newSeq)) {
                        onChange === null || onChange === void 0 ? void 0 : onChange({
                            type: 'replace',
                            id: edge.id,
                            item: {
                                ...edge,
                                data: {
                                    ...edge.data,
                                    input: {
                                        ...edge.data.input,
                                        seq: newSeq
                                    }
                                }
                            }
                        });
                    }
                    break;
                }
            case 'sectionBuffer':
                {
                    const newBufferId = event.target.value;
                    onChange === null || onChange === void 0 ? void 0 : onChange({
                        type: 'replace',
                        id: edge.id,
                        item: {
                            ...edge,
                            data: {
                                ...edge.data,
                                input: {
                                    type: 'sectionBuffer',
                                    inputId: newBufferId
                                }
                            }
                        }
                    });
                    break;
                }
            default:
                {
                    (0,_utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_6__.exhaustiveCheck)(edge.data.input);
                    throw new Error('unknown edge input');
                }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        id: labelId,
                        children: "Slot"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                        labelId: labelId,
                        label: "Slot",
                        value: edge.data.input.type,
                        onChange: (ev)=>{
                            onChange === null || onChange === void 0 ? void 0 : onChange({
                                type: 'replace',
                                id: edge.id,
                                item: {
                                    ...edge,
                                    data: {
                                        ...edge.data,
                                        input: defaultInputData(ev.target.value)
                                    }
                                }
                            });
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                value: "bufferSeq",
                                children: "Index"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                value: "bufferKey",
                                children: "Key"
                            })
                        ]
                    })
                ]
            }),
            edge.data.input === undefined || edge.data.input.type === 'bufferSeq' && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                label: "Index",
                type: "number",
                value: edge.data.input.seq,
                onChange: handleDataChange,
                fullWidth: true
            }),
            edge.data.input.type === 'bufferKey' && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                label: "Key",
                value: edge.data.input.key,
                onChange: handleDataChange,
                fullWidth: true
            }),
            (sourceNode === null || sourceNode === void 0 ? void 0 : sourceNode.type) === 'section' && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                freeSolo: true,
                autoSelect: true,
                options: sectionBuffers,
                value: edge.data.output.bufferId || '',
                onChange: (_, value)=>{
                    onChange === null || onChange === void 0 ? void 0 : onChange({
                        type: 'replace',
                        id: edge.id,
                        item: {
                            ...edge,
                            data: {
                                output: {
                                    bufferId: value || ''
                                },
                                input: edge.data.input
                            }
                        }
                    });
                },
                renderInput: (params)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                        ...params,
                        required: true,
                        label: "Section Buffer"
                    })
            }),
            nodeManager.getNode(edge.target).type === 'join' && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        id: `${labelId}-fetch-type`,
                        children: "Fetch Type"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                        labelId: labelId,
                        label: "Fetch Type",
                        value: edge.data.input.fetchType || _edges__WEBPACK_IMPORTED_MODULE_2__.BufferFetchType.Pull,
                        onChange: (ev)=>{
                            onChange === null || onChange === void 0 ? void 0 : onChange({
                                type: 'replace',
                                id: edge.id,
                                item: {
                                    ...edge,
                                    data: {
                                        ...edge.data,
                                        input: {
                                            ...edge.data.input,
                                            fetchType: ev.target.value
                                        }
                                    }
                                }
                            });
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                value: _edges__WEBPACK_IMPORTED_MODULE_2__.BufferFetchType.Pull,
                                children: "Pull"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                value: _edges__WEBPACK_IMPORTED_MODULE_2__.BufferFetchType.Clone,
                                children: "Clone"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


}),
853: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(460);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(466);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(472);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(559);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(710);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(855);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _utils_buffer_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(854);
/* ESM import */var _base_edit_operation_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(655);





function BufferForm(props) {
    var _op_settings;
    const { node, onChange } = props;
    const { op } = node.data;
    const retentionLabelId = react__WEBPACK_IMPORTED_MODULE_1___default().useId();
    const retention = ((_op_settings = op.settings) === null || _op_settings === void 0 ? void 0 : _op_settings.retention) ?? {
        keep_last: 1
    };
    const retentionMode = (0,_utils_buffer_settings__WEBPACK_IMPORTED_MODULE_2__.getRetentionMode)(retention);
    const retentionValue = retention === 'keep_all' ? 1 : Object.values(retention)[0];
    const handleRetentionModeChange = (e)=>{
        const mode = e.target.value;
        let newRetention;
        if (mode === 'keep_all') {
            newRetention = 'keep_all';
        } else if (mode === 'keep_first') {
            newRetention = {
                keep_first: retentionValue
            };
        } else if (mode === 'keep_last') {
            newRetention = {
                keep_last: retentionValue
            };
        } else {
            throw new Error(`Invalid retention mode: ${mode}`);
        }
        const updatedNode = {
            ...node
        };
        updatedNode.data.op = {
            ...op,
            settings: {
                ...op.settings,
                retention: newRetention
            }
        };
        onChange === null || onChange === void 0 ? void 0 : onChange({
            type: 'replace',
            id: node.id,
            item: updatedNode
        });
    };
    const handleRetentionValueChange = (e)=>{
        const value = parseInt(e.target.value, 10);
        if (value < 1 || !Number.isInteger(value)) return;
        let newRetention;
        if (retentionMode === 'keep_first') {
            newRetention = {
                keep_first: value
            };
        } else if (retentionMode === 'keep_last') {
            newRetention = {
                keep_last: value
            };
        } else {
            throw new Error(`Invalid retention mode for value change: ${retentionMode}`);
        }
        const updatedNode = {
            ...node
        };
        updatedNode.data.op = {
            ...op,
            settings: {
                ...op.settings,
                retention: newRetention
            }
        };
        onChange === null || onChange === void 0 ? void 0 : onChange({
            type: 'replace',
            id: node.id,
            item: updatedNode
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_base_edit_operation_form__WEBPACK_IMPORTED_MODULE_3__["default"], {
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
                label: "Display Text",
                value: op.display_text || '',
                helperText: "Changes the label only; the operation ID stays the same.",
                onChange: (ev)=>{
                    onChange === null || onChange === void 0 ? void 0 : onChange({
                        type: 'replace',
                        id: node.id,
                        item: {
                            ...node,
                            data: {
                                ...node.data,
                                op: {
                                    ...op,
                                    display_text: ev.target.value || undefined
                                }
                            }
                        }
                    });
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
                direction: "row",
                spacing: 2,
                minWidth: 300,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
                        fullWidth: true,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                                id: retentionLabelId,
                                children: "Retention Policy"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                                labelId: retentionLabelId,
                                value: retentionMode,
                                label: "Retention Policy",
                                onChange: handleRetentionModeChange,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                                        value: "keep_last",
                                        children: "Keep Last"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                                        value: "keep_first",
                                        children: "Keep First"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                                        value: "keep_all",
                                        children: "Keep All"
                                    })
                                ]
                            })
                        ]
                    }),
                    (retentionMode === 'keep_first' || retentionMode === 'keep_last') && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
                        type: "number",
                        label: "Amount",
                        value: retentionValue,
                        onChange: handleRetentionValueChange,
                        slotProps: {
                            htmlInput: {
                                min: 1,
                                step: 1
                            }
                        }
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                control: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                    checked: op.serialize ?? false,
                    onChange: (_, checked)=>{
                        const updatedNode = {
                            ...node
                        };
                        updatedNode.data.op = {
                            ...op,
                            serialize: checked
                        };
                        onChange === null || onChange === void 0 ? void 0 : onChange({
                            type: 'replace',
                            id: node.id,
                            item: updatedNode
                        });
                    }
                }),
                label: "Serialize"
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BufferForm);


}),
860: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (ConfigExamples)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(861);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(866);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(868);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(802);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(332);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(766);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(584);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);



/**
 * The configurations a builder ships as examples. Collapsed by default: they
 * are reference material, and they matter most for the builders whose schema
 * the form can only edit as JSON, where the shape is the thing being learnt.
 */ function ConfigExamples(param) {
    let { examples, onApply } = param;
    if (examples.length === 0) {
        return null;
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
        disableGutters: true,
        elevation: 0,
        square: true,
        slotProps: {
            transition: {
                unmountOnExit: true
            }
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
                expandIcon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_1__.MaterialSymbol, {
                    symbol: "expand_more"
                }),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
                    variant: "body2",
                    children: [
                        "Examples (",
                        examples.length,
                        ")"
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
                    spacing: 2,
                    divider: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        flexItem: true
                    }),
                    children: examples.map((example)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
                            spacing: 1,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                    color: "text.secondary",
                                    variant: "body2",
                                    children: example.description
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                    direction: "row",
                                    alignItems: "center",
                                    spacing: 1,
                                    sx: {
                                        border: 1,
                                        borderColor: 'divider',
                                        borderRadius: 1,
                                        bgcolor: 'action.hover',
                                        pl: 1.5,
                                        pr: 0.5,
                                        py: 0.5
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                                            component: "pre",
                                            sx: {
                                                flex: 1,
                                                m: 0,
                                                fontFamily: 'monospace',
                                                fontSize: '0.8125rem',
                                                whiteSpace: 'pre-wrap',
                                                wordBreak: 'break-word'
                                            },
                                            children: JSON.stringify(example.config)
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                                            title: "Use this config",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                                size: "small",
                                                "aria-label": "Use this config",
                                                onClick: ()=>onApply(example.config),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_1__.MaterialSymbol, {
                                                    symbol: "arrow_forward"
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        }, example.description))
                })
            })
        ]
    });
}


}),
653: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  DataInputForm: () => (DataInputForm)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(575);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _edges__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(299);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(147);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(321);
/* ESM import */var _templates_provider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(459);








function slotNames(slots) {
    return Array.isArray(slots) ? slots : Object.keys(slots || {});
}
function DataInputForm(param) {
    let { edge, onChange } = param;
    var _nodeManager_tryGetNode;
    const nodeManager = (0,_node_manager__WEBPACK_IMPORTED_MODULE_3__.useNodeManager)();
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_5__.useRegistry)();
    const [templates, _setTemplates] = (0,_templates_provider__WEBPACK_IMPORTED_MODULE_6__.useTemplates)();
    const targetNode = nodeManager.tryGetNode(edge.target);
    const bufferAlias = ((_nodeManager_tryGetNode = nodeManager.tryGetNode(edge.source)) === null || _nodeManager_tryGetNode === void 0 ? void 0 : _nodeManager_tryGetNode.type) === 'sectionBuffer';
    const { inputs, buffers } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!targetNode || !(0,_nodes__WEBPACK_IMPORTED_MODULE_4__.isSectionNode)(targetNode)) {
            return {
                inputs: [],
                buffers: []
            };
        }
        if (typeof targetNode.data.op.builder === 'string') {
            const sectionBuilder = registry.sections[targetNode.data.op.builder];
            return {
                inputs: Object.keys((sectionBuilder === null || sectionBuilder === void 0 ? void 0 : sectionBuilder.interface.inputs) || {}),
                buffers: Object.keys((sectionBuilder === null || sectionBuilder === void 0 ? void 0 : sectionBuilder.interface.buffers) || {})
            };
        } else if (typeof targetNode.data.op.template === 'string') {
            const template = templates[targetNode.data.op.template];
            return {
                inputs: slotNames(template === null || template === void 0 ? void 0 : template.inputs),
                buffers: slotNames(template === null || template === void 0 ? void 0 : template.buffers)
            };
        } else {
            return {
                inputs: [],
                buffers: []
            };
        }
    }, [
        targetNode,
        registry,
        templates
    ]);
    if (!(0,_edges__WEBPACK_IMPORTED_MODULE_2__.isDataEdge)(edge)) {
        return null;
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: (targetNode === null || targetNode === void 0 ? void 0 : targetNode.type) === 'section' && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
            freeSolo: true,
            autoSelect: true,
            options: bufferAlias ? buffers : [
                ...inputs,
                ...buffers
            ],
            value: edge.data.input.type === 'sectionInput' || edge.data.input.type === 'sectionBuffer' ? edge.data.input.inputId : '',
            onChange: (_, value)=>{
                onChange === null || onChange === void 0 ? void 0 : onChange({
                    type: 'replace',
                    id: edge.id,
                    item: {
                        ...edge,
                        data: {
                            output: edge.data.output,
                            input: {
                                type: bufferAlias || buffers.includes(value || '') ? 'sectionBuffer' : 'sectionInput',
                                inputId: value || ''
                            }
                        }
                    }
                });
            },
            renderInput: (params)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                    ...params,
                    required: true,
                    label: "Section Input"
                })
        })
    });
}


}),
318: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__),
  defaultEdgeData: () => (defaultEdgeData)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(656);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(658);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(584);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(660);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(460);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(466);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(472);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(559);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(147);
/* ESM import */var _utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(319);
/* ESM import */var _buffer_edge_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(320);
/* ESM import */var _data_input_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(653);
/* ESM import */var _section_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(654);
/* ESM import */var _split_edge_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(667);
/* ESM import */var _stream_out_edge_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(668);
/* ESM import */var _unzip_edge_form__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(669);











const EDGE_TYPES_NAME = {
    buffer: 'Buffer',
    default: 'Default',
    forkResultErr: 'Error',
    forkResultOk: 'Ok',
    splitKey: 'Key',
    splitRemaining: 'Remaining',
    splitSeq: 'Sequence',
    streamOut: 'Stream Out',
    unzip: 'Unzip',
    section: 'Section'
};
const EDGE_DEFAULT_OUTPUT_DATA = {
    default: {
        output: {},
        input: {
            type: 'default'
        }
    },
    buffer: {
        output: {},
        input: {
            type: 'bufferSeq',
            seq: 0
        }
    },
    forkResultOk: {
        output: {},
        input: {
            type: 'default'
        }
    },
    forkResultErr: {
        output: {},
        input: {
            type: 'default'
        }
    },
    splitKey: {
        output: {
            key: 'unnamed_key'
        },
        input: {
            type: 'default'
        }
    },
    splitSeq: {
        output: {
            seq: 0
        },
        input: {
            type: 'default'
        }
    },
    splitRemaining: {
        output: {},
        input: {
            type: 'default'
        }
    },
    streamOut: {
        output: {
            streamId: ''
        },
        input: {
            type: 'default'
        }
    },
    unzip: {
        output: {
            seq: 0
        },
        input: {
            type: 'default'
        }
    },
    section: {
        output: {
            output: ''
        },
        input: {
            type: 'default'
        }
    }
};
function defaultEdgeData(type) {
    return {
        ...EDGE_DEFAULT_OUTPUT_DATA[type]
    };
}
function EditEdgeForm(param) {
    let { edge, allowedEdgeTypes, nodeManager, onChange, onDelete } = param;
    const subForm = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>{
        switch(edge.type){
            case 'buffer':
                {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_buffer_edge_form__WEBPACK_IMPORTED_MODULE_4__.BufferEdgeInputForm, {
                        edge: edge,
                        onChange: onChange
                    });
                }
            case 'streamOut':
                {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_stream_out_edge_form__WEBPACK_IMPORTED_MODULE_8__.StreamOutEdgeForm, {
                        edge: edge,
                        nodeManager: nodeManager,
                        onChange: onChange
                    });
                }
            case 'default':
            case 'forkResultOk':
            case 'forkResultErr':
                {
                    // these edges have no extra options
                    return null;
                }
            case 'splitKey':
            case 'splitRemaining':
            case 'splitSeq':
                {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_split_edge_form__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        edge: edge,
                        onChange: onChange
                    });
                }
            case 'unzip':
                {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_unzip_edge_form__WEBPACK_IMPORTED_MODULE_9__["default"], {
                        edge: edge,
                        onChange: onChange
                    });
                }
            case 'section':
                {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_section_form__WEBPACK_IMPORTED_MODULE_6__.SectionEdgeForm, {
                        edge: edge,
                        onChange: onChange
                    });
                }
            default:
                {
                    (0,_utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_3__.exhaustiveCheck)(edge);
                    throw new Error('unknown edge type');
                }
        }
    }, [
        edge,
        nodeManager,
        onChange
    ]);
    const typeLabelId = react__WEBPACK_IMPORTED_MODULE_1___default().useId();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
        sx: {
            minWidth: 250
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                title: "Edit Connection",
                action: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                    color: "error",
                    onClick: ()=>onDelete({
                            type: 'remove',
                            id: edge.id
                        }),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_2__.MaterialSymbol, {
                        symbol: "delete"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                    id: typeLabelId,
                                    children: "Type"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                    labelId: typeLabelId,
                                    label: "Type",
                                    value: edge.type,
                                    onChange: (ev)=>{
                                        const newEdge = {
                                            ...edge
                                        };
                                        newEdge.type = ev.target.value;
                                        newEdge.data = defaultEdgeData(newEdge.type);
                                        onChange({
                                            type: 'replace',
                                            id: edge.id,
                                            item: newEdge
                                        });
                                    },
                                    children: allowedEdgeTypes.map((t)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                            value: t,
                                            children: EDGE_TYPES_NAME[t]
                                        }, t))
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_data_input_form__WEBPACK_IMPORTED_MODULE_5__.DataInputForm, {
                            edge: edge,
                            onChange: onChange
                        }),
                        subForm
                    ]
                })
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditEdgeForm);


}),
852: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);
/* ESM import */var _utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(319);
/* ESM import */var _base_edit_operation_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(655);
/* ESM import */var _buffer_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(853);
/* ESM import */var _edit_scope_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(857);
/* ESM import */var _join_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(858);
/* ESM import */var _node_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(859);
/* ESM import */var _script_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(870);
/* ESM import */var _section_form__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(654);
/* ESM import */var _stream_out_form__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(872);
/* ESM import */var _transform_form__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(873);












function EditOperationNodeForm(props) {
    switch(props.node.data.op.type){
        case 'node':
            {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_node_form__WEBPACK_IMPORTED_MODULE_7__["default"], {
                    ...props
                });
            }
        case 'buffer':
            {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_buffer_form__WEBPACK_IMPORTED_MODULE_4__["default"], {
                    ...props
                });
            }
        case 'join':
            {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_join_form__WEBPACK_IMPORTED_MODULE_6__["default"], {
                    ...props
                });
            }
        case 'scope':
            {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_edit_scope_form__WEBPACK_IMPORTED_MODULE_5__["default"], {
                    ...props
                });
            }
        case 'section':
            {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_section_form__WEBPACK_IMPORTED_MODULE_9__.SectionForm, {
                    ...props
                });
            }
        case 'transform':
            {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_transform_form__WEBPACK_IMPORTED_MODULE_11__["default"], {
                    ...props
                });
            }
        case 'script':
            {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_script_form__WEBPACK_IMPORTED_MODULE_8__["default"], {
                    ...props
                });
            }
        case 'stream_out':
            {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_stream_out_form__WEBPACK_IMPORTED_MODULE_10__.StreamOutForm, {
                    ...props
                });
            }
        default:
            {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_edit_operation_form__WEBPACK_IMPORTED_MODULE_3__["default"], {
                    ...props
                });
            }
    }
}
function EditNodeForm(props) {
    if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isOperationNode)(props.node)) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(EditOperationNodeForm, {
            ...props,
            node: props.node
        });
    } else if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isSectionInterfaceNode)(props.node)) {
        switch(props.node.type){
            case 'sectionInput':
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_section_form__WEBPACK_IMPORTED_MODULE_9__.SectionInputForm, {
                    ...props,
                    node: props.node
                });
            case 'sectionOutput':
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_section_form__WEBPACK_IMPORTED_MODULE_9__.SectionOutputForm, {
                    ...props,
                    node: props.node
                });
            case 'sectionBuffer':
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_section_form__WEBPACK_IMPORTED_MODULE_9__.SectionBufferForm, {
                    ...props,
                    node: props.node
                });
            default:
                (0,_utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_2__.exhaustiveCheck)(props.node);
                throw new Error('unknown node type');
        }
    } else {
        return null;
    }
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditNodeForm);


}),
857: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(678);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);
/* ESM import */var _base_edit_operation_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(655);




function EditScopeForm(param) {
    let { onAddOperationClick, ...otherProps } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_edit_operation_form__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...otherProps,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
            variant: "contained",
            startIcon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_1__.MaterialSymbol, {
                symbol: "add"
            }),
            onClick: onAddOperationClick,
            children: "Add Operation"
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditScopeForm);


}),
851: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  EditEdgeForm: () => (/* reexport safe */ _edit_edge_form__WEBPACK_IMPORTED_MODULE_0__["default"]),
  EditNodeForm: () => (/* reexport safe */ _edit_node_form__WEBPACK_IMPORTED_MODULE_1__["default"]),
  defaultEdgeData: () => (/* reexport safe */ _edit_edge_form__WEBPACK_IMPORTED_MODULE_0__.defaultEdgeData)
});
/* ESM import */var _edit_edge_form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(318);
/* ESM import */var _edit_node_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(852);
/* ESM import */var _edit_scope_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(857);







}),
858: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(710);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(703);
/* ESM import */var _base_edit_operation_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(655);



function JoinForm(props) {
    const op = props.node.data.op;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_edit_operation_form__WEBPACK_IMPORTED_MODULE_1__["default"], {
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
            label: "Serialize",
            control: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
                checked: !!op.serialize
            }),
            onChange: (_, checked)=>{
                var _props_onChange;
                const updatedNode = {
                    ...props.node
                };
                updatedNode.data.op = {
                    ...updatedNode.data.op,
                    serialize: checked
                };
                (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
                    type: 'replace',
                    id: props.node.id,
                    item: updatedNode
                });
            }
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (JoinForm);


}),
859: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(579);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(829);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(766);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(435);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(321);
/* ESM import */var _transient_editor_drafts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(845);
/* ESM import */var _base_edit_operation_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(655);
/* ESM import */var _config_examples__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(860);
/* ESM import */var _schema_config_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(702);








function NodeForm(props) {
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_2__.useRegistry)();
    const { drafts, setOperationConfigDraft } = (0,_transient_editor_drafts__WEBPACK_IMPORTED_MODULE_3__.useTransientEditorDrafts)();
    const nodes = Object.keys(registry.nodes).sort();
    const configDraftKey = `node:${props.node.id}:config`;
    const op = props.node.data.op;
    const existingConfig = op.config;
    const builderMetadata = registry.nodes[op.builder];
    const replaceOp = (updatedOp)=>{
        var _props_onChange;
        (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
            type: 'replace',
            id: props.node.id,
            item: {
                ...props.node,
                data: {
                    ...props.node.data,
                    op: updatedOp
                }
            }
        });
    };
    const updateConfig = (config)=>{
        const { config: _config, ...rest } = op;
        replaceOp(config === undefined ? rest : {
            ...rest,
            config
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_base_edit_operation_form__WEBPACK_IMPORTED_MODULE_4__["default"], {
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                label: "Display Text",
                value: op.display_text || '',
                onChange: (ev)=>{
                    replaceOp({
                        ...op,
                        display_text: ev.target.value || undefined
                    });
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                freeSolo: true,
                autoSelect: true,
                options: nodes,
                getOptionLabel: (option)=>option,
                value: op.builder,
                onChange: (_, value)=>{
                    var _registry_nodes_builder;
                    const builder = value ?? '';
                    // Only a node that has no config yet gets the new builder's defaults;
                    // an existing config is the user's, so it is left alone.
                    const defaults = existingConfig === undefined ? (0,_schema_config_form__WEBPACK_IMPORTED_MODULE_6__.getSchemaConfigDefaults)((_registry_nodes_builder = registry.nodes[builder]) === null || _registry_nodes_builder === void 0 ? void 0 : _registry_nodes_builder.config_schema, registry.schemas) : undefined;
                    replaceOp({
                        ...op,
                        builder,
                        ...defaults !== undefined && {
                            config: defaults
                        }
                    });
                },
                renderInput: (params)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        ...params,
                        required: true,
                        label: "Builder"
                    }),
                renderOption: (param, value)=>{
                    let { key, ...otherProps } = param;
                    const nodeMetadata = registry.nodes[value];
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                        ...otherProps,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                            direction: "row",
                            justifyContent: "space-between",
                            width: "100%",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                    children: value
                                }),
                                (nodeMetadata === null || nodeMetadata === void 0 ? void 0 : nodeMetadata.description) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                                    title: nodeMetadata.description,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_1__.MaterialSymbol, {
                                        symbol: "info"
                                    })
                                })
                            ]
                        })
                    }, key);
                }
            }),
            (builderMetadata === null || builderMetadata === void 0 ? void 0 : builderMetadata.description) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                color: "text.secondary",
                variant: "body2",
                children: builderMetadata.description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_schema_config_form__WEBPACK_IMPORTED_MODULE_6__["default"], {
                schema: builderMetadata === null || builderMetadata === void 0 ? void 0 : builderMetadata.config_schema,
                definitions: registry.schemas,
                value: existingConfig,
                onChange: updateConfig,
                rawDraft: drafts.operationConfigs[configDraftKey],
                onRawDraftChange: (value)=>setOperationConfigDraft(configDraftKey, value)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_config_examples__WEBPACK_IMPORTED_MODULE_5__["default"], {
                examples: (builderMetadata === null || builderMetadata === void 0 ? void 0 : builderMetadata.config_examples) ?? [],
                onApply: updateConfig
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NodeForm);


}),
702: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (SchemaConfigForm),
  getSchemaConfigDefaults: () => (getSchemaConfigDefaults)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(559);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(332);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(703);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(710);
/* ESM import */var fast_deep_equal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(174);
/* ESM import */var fast_deep_equal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fast_deep_equal__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




function schemaObject(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value) ? value : null;
}
// `Object.hasOwn` needs a newer lib target than this package compiles against,
// and biome rewrites a `hasOwnProperty` call into it.
function hasOwn(object, key) {
    return Object.getOwnPropertyDescriptor(object, key) !== undefined;
}
function resolveRef(ref, definitions) {
    var _ref_split_at;
    if (!ref.startsWith('#/')) {
        return null;
    }
    const name = (_ref_split_at = ref.split('/').at(-1)) === null || _ref_split_at === void 0 ? void 0 : _ref_split_at.replace(/~1/g, '/').replace(/~0/g, '~');
    return name ? schemaObject(definitions[name]) : null;
}
function isNullSchema(option) {
    var _schemaObject;
    const type = (_schemaObject = schemaObject(option)) === null || _schemaObject === void 0 ? void 0 : _schemaObject.type;
    return Array.isArray(type) ? type.includes('null') : type === 'null';
}
function schemaType(schema) {
    if (typeof schema.type === 'string') {
        return schema.type;
    }
    if (Array.isArray(schema.type)) {
        const nonNullTypes = schema.type.filter((type)=>type !== 'null');
        return schema.type.includes('null') && nonNullTypes.length === 1 && typeof nonNullTypes[0] === 'string' ? nonNullTypes[0] : null;
    }
    if (Array.isArray(schema.enum) && schema.enum.length > 0) {
        return schema.enum.every((value)=>typeof value === 'string') ? 'string' : null;
    }
    return null;
}
const unsupportedKeywords = [
    'allOf',
    'oneOf',
    'not',
    'if',
    'then',
    'else',
    'patternProperties',
    'dependentSchemas',
    'dependencies'
];
/**
 * Resolves the parts of a schema this form has a typed control for, returning
 * `null` for anything it cannot type. Callers go through {@link resolveSchema},
 * which turns that `null` into a raw JSON field.
 */ function resolveTypedSchema(schema, definitions, resolvingRefs) {
    if (typeof schema.$ref === 'string') {
        // A cycle resolves to a raw field at the point it closes, leaving the rest
        // of the schema typed.
        if (resolvingRefs.has(schema.$ref)) {
            return null;
        }
        const referenced = resolveRef(schema.$ref, definitions);
        if (!referenced) {
            return null;
        }
        const { $ref: _ref, ...overrides } = schema;
        return resolveTypedSchema({
            ...referenced,
            ...overrides
        }, definitions, new Set(resolvingRefs).add(schema.$ref));
    }
    // `Option<T>` serializes as a two-branch `anyOf`; unwrap it to edit the `T`.
    if (Array.isArray(schema.anyOf)) {
        const nonNull = schema.anyOf.filter((option)=>!isNullSchema(option));
        const unwrapped = schemaObject(nonNull[0]);
        if (nonNull.length !== schema.anyOf.length - 1 || !unwrapped) {
            return null;
        }
        const { anyOf: _anyOf, ...overrides } = schema;
        const resolved = resolveTypedSchema({
            ...unwrapped,
            ...overrides
        }, definitions, resolvingRefs);
        return resolved && {
            ...resolved,
            nullable: true
        };
    }
    if (unsupportedKeywords.some((key)=>key in schema)) {
        return null;
    }
    const type = schemaType(schema);
    const base = {
        description: typeof schema.description === 'string' ? schema.description : undefined,
        defaultValue: schema.default,
        // The other spelling of `Option<T>`: `"type": ["number", "null"]`.
        nullable: Array.isArray(schema.type) && schema.type.includes('null')
    };
    if (type === 'boolean') {
        return schema.enum === undefined ? {
            ...base,
            type,
            enumValues: [
                true,
                false
            ]
        } : null;
    }
    if (type === 'string' || type === 'number' || type === 'integer') {
        let enumValues;
        if (schema.enum !== undefined) {
            if (!Array.isArray(schema.enum) || schema.enum.length === 0 || !schema.enum.every((value)=>typeof value === 'string' || typeof value === 'number')) {
                return null;
            }
            enumValues = schema.enum;
        }
        if (type === 'string') {
            return {
                ...base,
                type,
                enumValues
            };
        }
        return {
            ...base,
            type,
            enumValues,
            minimum: typeof schema.minimum === 'number' ? schema.minimum : undefined,
            maximum: typeof schema.maximum === 'number' ? schema.maximum : undefined
        };
    }
    if (type === 'object') {
        // A map type has no fixed set of fields to lay out, so edit it as raw JSON.
        if (schema.additionalProperties !== undefined && schema.additionalProperties !== false) {
            return null;
        }
        const rawProperties = schemaObject(schema.properties ?? {});
        const requiredValues = schema.required ?? [];
        if (!rawProperties || !Array.isArray(requiredValues) || !requiredValues.every((value)=>typeof value === 'string')) {
            return null;
        }
        const properties = {};
        for (const [name, propertySchema] of Object.entries(rawProperties)){
            properties[name] = resolveSchema(propertySchema, definitions, resolvingRefs);
        }
        return {
            ...base,
            type,
            properties,
            required: new Set(requiredValues)
        };
    }
    return null;
}
function resolveSchema(rawSchema, definitions) {
    let resolvingRefs = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : new Set();
    const schema = schemaObject(rawSchema);
    const typed = schema && resolveTypedSchema(schema, definitions, resolvingRefs);
    return typed ?? {
        type: 'raw',
        description: typeof (schema === null || schema === void 0 ? void 0 : schema.description) === 'string' ? schema.description : undefined,
        defaultValue: schema === null || schema === void 0 ? void 0 : schema.default
    };
}
function schemaDefault(schema) {
    if (schema.defaultValue !== undefined) {
        // Config values are JSON, so a round trip is enough to detach the default
        // from the registry.
        return JSON.parse(JSON.stringify(schema.defaultValue));
    }
    if (schema.type !== 'object') {
        return undefined;
    }
    const value = {};
    for (const [name, property] of Object.entries(schema.properties)){
        const propertyDefault = schemaDefault(property);
        if (propertyDefault !== undefined) {
            value[name] = propertyDefault;
        }
    }
    return Object.keys(value).length > 0 ? value : undefined;
}
/**
 * The config a newly created node starts with: schema defaults, plus the
 * required keys that have none, so the node is already the shape the form would
 * give it.
 */ function getSchemaConfigDefaults(schema, definitions) {
    const resolvedSchema = resolveSchema(schema, definitions);
    return completeRequired(resolvedSchema, schemaDefault(resolvedSchema));
}
/**
 * Whether the field carries its own "is this set" checkbox. Objects and raw
 * JSON fields are left out: an object is a group rather than a single control,
 * and `null` can simply be typed into a JSON box.
 */ function hasNullToggle(schema) {
    return schema.nullable === true && schema.type !== 'object' && schema.type !== 'raw';
}
/** The value a nullable field takes when its checkbox is ticked. */ function enabledValue(schema) {
    return schema.defaultValue === undefined || schema.defaultValue === null ? presentValue(schema) : JSON.parse(JSON.stringify(schema.defaultValue));
}
/** The value written when an optional property is switched on. */ function initialValue(schema) {
    if (schema.defaultValue !== undefined) {
        return JSON.parse(JSON.stringify(schema.defaultValue));
    }
    if (schema.nullable) {
        // An `Option<T>` with no default starts out as `None`.
        return null;
    }
    return presentValue(schema);
}
/** The empty-but-present value for a schema, ignoring whether it is nullable. */ function presentValue(schema) {
    switch(schema.type){
        case 'raw':
            return null;
        case 'string':
            var _schema_enumValues;
            return ((_schema_enumValues = schema.enumValues) === null || _schema_enumValues === void 0 ? void 0 : _schema_enumValues[0]) ?? '';
        case 'number':
        case 'integer':
            var _schema_enumValues1;
            return ((_schema_enumValues1 = schema.enumValues) === null || _schema_enumValues1 === void 0 ? void 0 : _schema_enumValues1[0]) ?? 0;
        case 'boolean':
            return false;
        case 'object':
            {
                // Seed required children too, otherwise switching on an object writes a
                // `{}` the schema rejects.
                const value = {};
                for (const [name, property] of Object.entries(schema.properties)){
                    if (schema.required.has(name)) {
                        value[name] = initialValue(property);
                    } else {
                        const propertyDefault = schemaDefault(property);
                        if (propertyDefault !== undefined) {
                            value[name] = propertyDefault;
                        }
                    }
                }
                return value;
            }
    }
}
/**
 * Fills in every required key the config is missing, so that a field the form
 * renders always corresponds to a key that exists. Returns `value` itself when
 * there was nothing to add, which is what stops {@link SchemaConfigForm} from
 * reporting a change on every render.
 *
 * Only absent keys are filled: a key that is present but holds the wrong shape
 * is the user's data and is left for them to see and correct.
 */ function completeRequired(schema, value) {
    if (schema.type !== 'object') {
        return value;
    }
    const object = schemaObject(value);
    if (!object) {
        // Nothing to complete unless the schema insists on keys; a config-less node
        // whose fields are all optional stays config-less.
        return schema.required.size > 0 ? initialValue(schema) : value;
    }
    let completed = object;
    const fill = (name, propertyValue)=>{
        if (completed === object) {
            completed = {
                ...object
            };
        }
        completed[name] = propertyValue;
    };
    for (const [name, property] of Object.entries(schema.properties)){
        if (!hasOwn(object, name)) {
            if (schema.required.has(name)) {
                fill(name, initialValue(property));
            }
            continue;
        }
        const child = completeRequired(property, object[name]);
        if (child !== object[name]) {
            fill(name, child);
        }
    }
    return completed;
}
function formatJson(value) {
    return value === undefined ? '' : JSON.stringify(value);
}
function parseJson(draft) {
    if (draft.trim() === '') {
        return {
            value: undefined
        };
    }
    try {
        return {
            value: JSON.parse(draft)
        };
    } catch  {
        return null;
    }
}
function formatNumber(value) {
    return typeof value === 'number' ? String(value) : '';
}
function parseNumber(draft, type) {
    if (draft.trim() === '') {
        return undefined;
    }
    const parsed = Number(draft);
    if (!Number.isFinite(parsed) || type === 'integer' && !Number.isInteger(parsed)) {
        return undefined;
    }
    return parsed;
}
function RawField(param) {
    let { label, schema, value, required, disabled, onChange, draftValue, onDraftChange } = param;
    const [draft, setDraft] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(()=>draftValue ?? formatJson(value));
    // Only adopt an incoming value that the box does not already say. Re-encoding
    // on every keystroke would strip the user's whitespace and move the cursor.
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setDraft((current)=>{
            if (draftValue !== undefined) {
                return draftValue;
            }
            const parsed = parseJson(current);
            return parsed && fast_deep_equal__WEBPACK_IMPORTED_MODULE_1___default()(parsed.value, value) ? current : formatJson(value);
        });
    }, [
        draftValue,
        value
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
        multiline: true,
        rows: 4,
        label: label,
        required: required,
        disabled: disabled,
        value: draft,
        error: parseJson(draft) === null,
        helperText: schema.description,
        onChange: (event)=>{
            setDraft(event.target.value);
            const parsed = parseJson(event.target.value);
            if (parsed) {
                onChange(parsed.value);
                onDraftChange === null || onDraftChange === void 0 ? void 0 : onDraftChange(undefined);
            } else {
                onDraftChange === null || onDraftChange === void 0 ? void 0 : onDraftChange(event.target.value);
            }
        },
        slotProps: {
            htmlInput: {
                sx: {
                    fontFamily: 'monospace',
                    whiteSpace: 'nowrap'
                }
            }
        }
    });
}
function NumberField(param) {
    let { label, schema, value, required, disabled, onChange } = param;
    const [draft, setDraft] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(()=>formatNumber(value));
    // As in RawField: keep a draft that already means `value`, so a trailing `.`
    // or `0` survives the round trip through the config.
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setDraft((current)=>parseNumber(current, schema.type) === (value ?? undefined) ? current : formatNumber(value));
    }, [
        value,
        schema.type
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
        type: "number",
        label: label,
        required: required,
        disabled: disabled,
        value: draft,
        // Anything the draft says that the config does not hold: unparseable
        // input, or a field cleared without a value to replace it. An `Option<T>`
        // unwraps to `T`, so a `null` here is an absent value, not a wrong one.
        error: parseNumber(draft, schema.type) !== (value ?? undefined),
        helperText: schema.description,
        slotProps: {
            htmlInput: {
                min: schema.minimum,
                max: schema.maximum,
                step: schema.type === 'integer' ? 1 : 'any'
            }
        },
        onChange: (event)=>{
            setDraft(event.target.value);
            const parsed = parseNumber(event.target.value, schema.type);
            if (parsed !== undefined) {
                onChange(parsed);
            }
        }
    });
}
function EnumField(param) {
    let { label, schema, value, required, disabled, onChange, enumValues } = param;
    // Selected by index so that string, number and boolean options round trip
    // alike - `String(option)` would flatten `1` and `"1"` onto each other.
    const selectedIndex = enumValues.findIndex((option)=>option === value);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
        select: true,
        label: label,
        required: required,
        disabled: disabled,
        value: selectedIndex < 0 ? '' : String(selectedIndex),
        helperText: schema.description,
        onChange: (event)=>onChange(enumValues[Number(event.target.value)]),
        children: enumValues.map((option, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
                value: String(index),
                children: String(option)
            }, JSON.stringify(option)))
    });
}
function SchemaField(props) {
    const { label, schema, value, required, disabled, onChange } = props;
    // An `Option<T>` opts out through a checkbox beside its control, so every
    // nullable field says "no value" the same way. Rendering the control again
    // without `nullable` is what stops this from recursing.
    if (hasNullToggle(schema)) {
        const enabled = value !== null;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
            direction: "row",
            spacing: 1,
            alignItems: "flex-start",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
                    sx: {
                        display: 'flex',
                        alignItems: 'center',
                        minHeight: 56
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        checked: enabled,
                        disabled: disabled,
                        inputProps: {
                            'aria-label': `Set ${label}`
                        },
                        onChange: (event)=>onChange(event.target.checked ? enabledValue(schema) : null)
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
                    sx: {
                        flex: 1,
                        minWidth: 0
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SchemaField, {
                        ...props,
                        schema: {
                            ...schema,
                            nullable: false
                        },
                        disabled: disabled || !enabled
                    })
                })
            ]
        });
    }
    if (schema.type === 'raw') {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(RawField, {
            ...props
        });
    }
    if (schema.type === 'object') {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
            component: "fieldset",
            disabled: disabled,
            sx: {
                m: 0,
                p: 2,
                border: 1,
                borderColor: 'divider',
                borderRadius: 1
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                    component: "legend",
                    variant: "subtitle2",
                    children: label
                }),
                schema.description && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                    color: "text.secondary",
                    variant: "body2",
                    sx: {
                        mb: 1
                    },
                    children: schema.description
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ObjectFields, {
                    schema: schema,
                    value: schemaObject(value) ?? {},
                    onChange: onChange
                })
            ]
        });
    }
    // Booleans are checked by type rather than by having `enumValues`, because
    // that is what narrows them out of the union for the branches below.
    if (schema.type === 'boolean') {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(EnumField, {
            ...props,
            enumValues: schema.enumValues
        });
    }
    if (schema.enumValues) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(EnumField, {
            ...props,
            enumValues: schema.enumValues
        });
    }
    if (schema.type === 'string') {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
            label: label,
            required: required,
            disabled: disabled,
            value: typeof value === 'string' ? value : '',
            helperText: schema.description,
            onChange: (event)=>onChange(event.target.value)
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(NumberField, {
        ...props,
        schema: schema
    });
}
function ObjectFields(param) {
    let { schema, value, onChange } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
        spacing: 2,
        children: Object.entries(schema.properties).map((param)=>{
            let [name, propertySchema] = param;
            const required = schema.required.has(name);
            const present = hasOwn(value, name);
            const setProperty = (propertyValue)=>{
                const nextValue = {
                    ...value
                };
                if (propertyValue === undefined) {
                    delete nextValue[name];
                } else {
                    nextValue[name] = propertyValue;
                }
                onChange(nextValue);
            };
            // A nullable field brings its own checkbox, and `#[serde(default)]` on
            // an `Option<T>` makes a property both optional and nullable - so
            // deferring to that one checkbox is what keeps them from stacking up.
            const optOut = !required && !hasNullToggle(propertySchema);
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
                spacing: 0.5,
                children: [
                    optOut && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                        control: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                            checked: present,
                            onChange: (event)=>setProperty(event.target.checked ? initialValue(propertySchema) : undefined)
                        }),
                        label: `Set ${name}`
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SchemaField, {
                        label: name,
                        schema: propertySchema,
                        value: value[name],
                        required: required,
                        disabled: optOut && !present,
                        onChange: setProperty
                    })
                ]
            }, name);
        })
    });
}
function SchemaConfigForm(param) {
    let { schema, definitions, value, onChange, rawDraft, onRawDraftChange } = param;
    const resolvedSchema = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>resolveSchema(schema, definitions), [
        schema,
        definitions
    ]);
    // The form defines the shape of the config, so every field it renders has a
    // key behind it whether or not the user has touched that field. Editing is
    // done against the completed config, and the parent is told about the keys
    // that were filled in.
    const completed = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>completeRequired(resolvedSchema, value), [
        resolvedSchema,
        value
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (completed !== value) {
            onChange(completed);
        }
    }, [
        completed,
        value,
        onChange
    ]);
    // The top level is the form itself, so its fields go straight into the
    // surrounding layout rather than into a labelled group.
    if (resolvedSchema.type === 'object') {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ObjectFields, {
            schema: resolvedSchema,
            value: schemaObject(completed) ?? {},
            onChange: onChange
        });
    }
    if (resolvedSchema.type === 'raw') {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(RawField, {
            label: "Config",
            schema: resolvedSchema,
            value: completed,
            required: false,
            disabled: false,
            onChange: onChange,
            draftValue: rawDraft,
            onDraftChange: onRawDraftChange
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SchemaField, {
        label: "Config",
        schema: resolvedSchema,
        value: completed,
        required: false,
        disabled: false,
        onChange: onChange
    });
}


}),
801: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ScriptEnvironmentPanel: () => (ScriptEnvironmentPanel)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(332);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(802);


function ConfigPreview(param) {
    let { value } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
        component: "pre",
        sx: {
            m: 0,
            p: 1.5,
            maxHeight: 220,
            overflow: 'auto',
            bgcolor: 'action.hover',
            border: '1px solid',
            borderColor: 'divider',
            borderRadius: 1,
            fontFamily: 'monospace',
            fontSize: '0.75rem',
            lineHeight: 1.5,
            whiteSpace: 'pre-wrap',
            overflowWrap: 'anywhere'
        },
        children: typeof value === 'string' ? value : JSON.stringify(value, null, 2)
    });
}
function ScriptEnvironmentPanel(param) {
    let { environmentName, environment, metadata } = param;
    if (!environmentName || !environment) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
            component: "aside",
            sx: {
                minWidth: 0
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    variant: "h6",
                    children: "Environment"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    color: "text.secondary",
                    sx: {
                        mt: 1
                    },
                    children: "Select an environment to inspect its runtime and configuration."
                })
            ]
        });
    }
    const config = typeof environment.config === 'object' && environment.config !== null ? environment.config : {};
    const script = typeof config.script === 'string' ? config.script : '';
    const configWithoutScript = Object.fromEntries(Object.entries(config).filter((param)=>{
        let [key] = param;
        return key !== 'script';
    }));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
        component: "aside",
        "aria-label": "Script environment details",
        sx: {
            minWidth: 0
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
            spacing: 2,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
                    direction: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
                        sx: {
                            minWidth: 0
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                variant: "overline",
                                color: "text.secondary",
                                children: "Environment"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                variant: "h6",
                                noWrap: true,
                                title: environmentName,
                                children: environmentName
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
                    spacing: 1,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            variant: "subtitle2",
                            children: "Runtime"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    variant: "caption",
                                    color: "text.secondary",
                                    children: "Builder"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    variant: "body2",
                                    children: environment.builder
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    variant: "caption",
                                    color: "text.secondary",
                                    children: "Language"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    variant: "body2",
                                    children: (metadata === null || metadata === void 0 ? void 0 : metadata.language) ?? 'Unknown'
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    variant: "caption",
                                    color: "text.secondary",
                                    children: "Interpreter version"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    variant: "body2",
                                    sx: {
                                        fontFamily: 'monospace',
                                        overflowWrap: 'anywhere'
                                    },
                                    children: (metadata === null || metadata === void 0 ? void 0 : metadata.interpreter) ?? 'Unavailable'
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
                    spacing: 1,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            variant: "subtitle2",
                            children: "Configuration"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ConfigPreview, {
                            value: configWithoutScript
                        })
                    ]
                }),
                script && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
                    spacing: 1,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            variant: "subtitle2",
                            children: "Environment script"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ConfigPreview, {
                            value: script
                        })
                    ]
                })
            ]
        })
    });
}


}),
770: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ScriptEnvironmentWorkspace: () => (ScriptEnvironmentWorkspace)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _codemirror_commands__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(771);
/* ESM import */var _codemirror_language__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(778);
/* ESM import */var _codemirror_view__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(774);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(766);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(584);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(795);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(678);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(559);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(522);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(332);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(802);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(535);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(808);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(810);
/* ESM import */var _uiw_react_codemirror__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(781);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* ESM import */var _diagram_properties_provider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(691);
/* ESM import */var _diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(769);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(147);
/* ESM import */var _notification_provider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(794);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(321);
/* ESM import */var _script_environment_panel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(801);
/* ESM import */var _script_environments_registry__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(803);















const CREATE_ENVIRONMENT_VALUE = '__create_script_environment__';
function objectConfig(value) {
    return typeof value === 'object' && value !== null ? value : {};
}
function ScriptEnvironmentWorkspace(param) {
    let { scriptNodeBinding } = param;
    var _registry_scripting, _plugin_codeExtensions;
    const [diagramProperties, setDiagramProperties] = (0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_3__.useDiagramProperties)();
    const nodeManager = (0,_node_manager__WEBPACK_IMPORTED_MODULE_5__.useNodeManager)();
    const showNotification = (0,_notification_provider__WEBPACK_IMPORTED_MODULE_7__.useNotification)();
    const rawRegistry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_8__.useRegistry)();
    const registry = rawRegistry;
    const environments = diagramProperties.script_environments || {};
    const { state: { selectedEnvironmentName, mode, expanded }, selectEnvironment, startEnvironmentCreate, startEnvironmentEdit, finishEnvironmentEdit, setExpanded } = (0,_diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_4__.useDiagramSidePanel)();
    const nodeControlsSelection = !!scriptNodeBinding && scriptNodeBinding.nodeControlsSelection !== false;
    const activeEnvironmentName = nodeControlsSelection ? scriptNodeBinding.environmentName : selectedEnvironmentName;
    const registeredBuilders = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>registry.scripting ? Object.keys(registry.scripting) : [], [
        registry
    ]);
    const defaultBuilder = registeredBuilders.includes('process-bound-python') ? 'process-bound-python' : registeredBuilders[0] || '';
    const [envName, setEnvName] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [builder, setBuilder] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [config, setConfig] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('{}');
    const [scriptText, setScriptText] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [selectedCodeField, setSelectedCodeField] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [language, setLanguage] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const [configError, setConfigError] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const [nameError, setNameError] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const previousMode = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(mode);
    const plugin = _script_environments_registry__WEBPACK_IMPORTED_MODULE_10__.scriptEnvironmentPlugins[builder];
    const activeCodeField = (plugin === null || plugin === void 0 ? void 0 : plugin.defaultCodeField) || selectedCodeField;
    const applyBuilder = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((selectedBuilder, bootstrap)=>{
        var _registry_scripting, _metadata_config_examples_, _metadata_config_examples;
        setBuilder(selectedBuilder);
        const metadata = (_registry_scripting = registry.scripting) === null || _registry_scripting === void 0 ? void 0 : _registry_scripting[selectedBuilder];
        const selectedPlugin = _script_environments_registry__WEBPACK_IMPORTED_MODULE_10__.scriptEnvironmentPlugins[selectedBuilder];
        setLanguage((metadata === null || metadata === void 0 ? void 0 : metadata.language) || 'python');
        setSelectedCodeField((selectedPlugin === null || selectedPlugin === void 0 ? void 0 : selectedPlugin.defaultCodeField) || '');
        if (!bootstrap) {
            return;
        }
        const example = metadata === null || metadata === void 0 ? void 0 : (_metadata_config_examples = metadata.config_examples) === null || _metadata_config_examples === void 0 ? void 0 : (_metadata_config_examples_ = _metadata_config_examples[0]) === null || _metadata_config_examples_ === void 0 ? void 0 : _metadata_config_examples_.config;
        const bootstrapConfig = example && typeof example === 'object' ? example : (selectedPlugin === null || selectedPlugin === void 0 ? void 0 : selectedPlugin.bootstrapConfig) ? JSON.parse(selectedPlugin.bootstrapConfig()) : {};
        const configObject = objectConfig(bootstrapConfig);
        const codeField = (selectedPlugin === null || selectedPlugin === void 0 ? void 0 : selectedPlugin.defaultCodeField) || '';
        const code = codeField && typeof configObject[codeField] === 'string' ? configObject[codeField] : '';
        setConfig(JSON.stringify(configObject, null, 2));
        setScriptText(code);
        setConfigError(null);
    }, [
        registry.scripting
    ]);
    const loadEnvironmentDraft = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((name)=>{
        var _registry_scripting_environment_builder, _registry_scripting;
        const environment = environments[name];
        if (!environment) {
            return;
        }
        const configObject = objectConfig(environment.config);
        const environmentPlugin = _script_environments_registry__WEBPACK_IMPORTED_MODULE_10__.scriptEnvironmentPlugins[environment.builder];
        const codeField = (environmentPlugin === null || environmentPlugin === void 0 ? void 0 : environmentPlugin.defaultCodeField) || '';
        setEnvName(name);
        setBuilder(environment.builder);
        setLanguage(((_registry_scripting = registry.scripting) === null || _registry_scripting === void 0 ? void 0 : (_registry_scripting_environment_builder = _registry_scripting[environment.builder]) === null || _registry_scripting_environment_builder === void 0 ? void 0 : _registry_scripting_environment_builder.language) || 'python');
        setConfig(JSON.stringify(configObject, null, 2));
        setSelectedCodeField(codeField);
        setScriptText(codeField && typeof configObject[codeField] === 'string' ? configObject[codeField] : '');
        setConfigError(null);
        setNameError(null);
    }, [
        environments,
        registry.scripting
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (mode === 'create' && previousMode.current !== 'create') {
            setEnvName('');
            setNameError(null);
            setConfigError(null);
            applyBuilder(defaultBuilder, true);
        } else if (mode !== 'create' && activeEnvironmentName && environments[activeEnvironmentName]) {
            loadEnvironmentDraft(activeEnvironmentName);
        }
        previousMode.current = mode;
    }, [
        applyBuilder,
        defaultBuilder,
        environments,
        loadEnvironmentDraft,
        mode,
        activeEnvironmentName
    ]);
    const startFreshEnvironment = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        setEnvName('');
        setNameError(null);
        setConfigError(null);
        applyBuilder(defaultBuilder, true);
        startEnvironmentCreate();
    }, [
        applyBuilder,
        defaultBuilder,
        startEnvironmentCreate
    ]);
    const getEnvUsageCount = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((name)=>nodeManager.nodes.filter((node)=>node.type === 'script' && node.data.op.environment === name).length, [
        nodeManager.nodes
    ]);
    const configKeys = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        try {
            const parsed = JSON.parse(config);
            if (parsed && typeof parsed === 'object') {
                return Object.keys(parsed).filter((key)=>typeof parsed[key] === 'string');
            }
        } catch  {
            return [];
        }
        return [];
    }, [
        config
    ]);
    const handleConfigChange = (newValue)=>{
        setConfig(newValue);
        try {
            const parsed = JSON.parse(newValue);
            setConfigError(null);
            if (selectedCodeField && parsed && typeof parsed === 'object' && typeof parsed[selectedCodeField] === 'string') {
                setScriptText(parsed[selectedCodeField]);
            }
        } catch (error) {
            setConfigError(error instanceof Error ? error.message : 'Invalid JSON');
        }
    };
    const handleScriptTextChange = (newValue)=>{
        setScriptText(newValue);
        if (!activeCodeField) {
            return;
        }
        try {
            const parsed = JSON.parse(config);
            if (parsed && typeof parsed === 'object') {
                parsed[activeCodeField] = newValue;
                setConfig(JSON.stringify(parsed, null, 2));
            }
        } catch  {
            return;
        }
    };
    const handleCodeFieldChange = (newField)=>{
        setSelectedCodeField(newField);
        if (!newField) {
            setScriptText('');
            return;
        }
        try {
            const parsed = JSON.parse(config);
            const value = parsed === null || parsed === void 0 ? void 0 : parsed[newField];
            setScriptText(typeof value === 'string' ? value : '');
        } catch  {
            setScriptText('');
        }
    };
    const handleSave = ()=>{
        try {
            const parsedConfig = JSON.parse(config);
            setDiagramProperties((prev)=>({
                    ...prev,
                    script_environments: {
                        ...prev.script_environments,
                        [envName]: {
                            builder,
                            config: parsedConfig
                        }
                    }
                }));
            selectEnvironment(envName);
            if (mode === 'create') {
                scriptNodeBinding === null || scriptNodeBinding === void 0 ? void 0 : scriptNodeBinding.assignEnvironment(envName);
            }
            showNotification(mode === 'create' ? `Environment '${envName}' created successfully` : `Environment '${envName}' saved successfully`, 'success');
            finishEnvironmentEdit();
        } catch  {
            setConfigError('Invalid JSON');
        }
    };
    const handleCancel = ()=>{
        if (activeEnvironmentName && environments[activeEnvironmentName]) {
            loadEnvironmentDraft(activeEnvironmentName);
        }
        finishEnvironmentEdit();
    };
    const handleDelete = ()=>{
        if (!activeEnvironmentName || getEnvUsageCount(activeEnvironmentName) > 0) {
            return;
        }
        setDiagramProperties((prev)=>{
            const { [activeEnvironmentName]: _, ...rest } = prev.script_environments || {};
            return {
                ...prev,
                script_environments: rest,
                highlightedEnvironment: prev.highlightedEnvironment === activeEnvironmentName ? undefined : prev.highlightedEnvironment
            };
        });
        showNotification(`Environment '${activeEnvironmentName}' deleted successfully`, 'success');
        selectEnvironment(undefined);
    };
    const isSaveDisabled = !!configError || !!nameError || !envName || !builder || !registeredBuilders.includes(builder);
    const selectedEnvironment = activeEnvironmentName ? environments[activeEnvironmentName] : undefined;
    const selectedMetadata = selectedEnvironment ? (_registry_scripting = registry.scripting) === null || _registry_scripting === void 0 ? void 0 : _registry_scripting[selectedEnvironment.builder] : undefined;
    const boundNodeHasNoEnvironments = nodeControlsSelection && Object.keys(environments).length === 0;
    const renderEnvironmentActions = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
            direction: "row",
            spacing: 0.5,
            alignItems: "center",
            children: activeEnvironmentName && selectedEnvironment && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                        title: diagramProperties.highlightedEnvironment === activeEnvironmentName ? 'Hide nodes' : 'Show nodes',
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                            "aria-label": diagramProperties.highlightedEnvironment === activeEnvironmentName ? 'Hide nodes' : 'Show nodes',
                            onClick: ()=>{
                                setDiagramProperties((prev)=>({
                                        ...prev,
                                        highlightedEnvironment: prev.highlightedEnvironment === activeEnvironmentName ? undefined : activeEnvironmentName
                                    }));
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                symbol: diagramProperties.highlightedEnvironment === activeEnvironmentName ? 'visibility_off' : 'visibility'
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                        title: "Edit environment",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                            "aria-label": "Edit environment",
                            onClick: startEnvironmentEdit,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                symbol: "edit"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                        title: getEnvUsageCount(activeEnvironmentName) > 0 ? `Cannot delete: used by ${getEnvUsageCount(activeEnvironmentName)} nodes` : 'Delete environment',
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                "aria-label": "Delete environment",
                                disabled: getEnvUsageCount(activeEnvironmentName) > 0,
                                onClick: handleDelete,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                    symbol: "delete"
                                })
                            })
                        })
                    })
                ]
            })
        });
    if (mode === 'view' && activeEnvironmentName && !selectedEnvironment) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
            spacing: 2,
            sx: {
                p: 2
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                severity: "warning",
                action: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                    onClick: startFreshEnvironment,
                    children: "Create environment"
                }),
                children: [
                    "Environment \u201C",
                    activeEnvironmentName,
                    "\u201D is not defined."
                ]
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
        spacing: 2,
        sx: {
            p: 2,
            minWidth: 0,
            overflowY: 'auto'
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                direction: "row",
                spacing: 1,
                alignItems: "center",
                children: [
                    mode === 'view' && !nodeControlsSelection ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                        select: true,
                        label: "Select Environment",
                        value: selectedEnvironmentName || '',
                        onChange: (event)=>{
                            if (event.target.value === CREATE_ENVIRONMENT_VALUE) {
                                startFreshEnvironment();
                                return;
                            }
                            selectEnvironment(event.target.value || undefined);
                        },
                        fullWidth: true,
                        children: [
                            Object.keys(environments).length === 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                disabled: true,
                                value: "",
                                children: "No environments available"
                            }) : Object.keys(environments).map((name)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                    value: name,
                                    children: name
                                }, name)),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                value: CREATE_ENVIRONMENT_VALUE,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                                    direction: "row",
                                    spacing: 1,
                                    alignItems: "center",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                            symbol: "add"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                            children: "Create new environment"
                                        })
                                    ]
                                })
                            })
                        ]
                    }) : mode !== 'view' ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                        variant: "h6",
                        sx: {
                            flex: 1
                        },
                        children: mode === 'create' ? 'Create Environment' : 'Edit Environment'
                    }) : null,
                    mode === 'view' ? !boundNodeHasNoEnvironments && activeEnvironmentName && selectedEnvironment && renderEnvironmentActions() : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                title: expanded ? 'Collapse environment editor' : 'Expand environment editor',
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                    "aria-label": expanded ? 'Collapse environment editor' : 'Expand environment editor',
                                    onClick: ()=>setExpanded(!expanded),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                        symbol: expanded ? 'fullscreen_exit' : 'fullscreen'
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                variant: "contained",
                                disabled: isSaveDisabled,
                                onClick: handleSave,
                                children: "Save"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                onClick: handleCancel,
                                children: "Cancel"
                            })
                        ]
                    })
                ]
            }),
            mode === 'view' ? activeEnvironmentName && selectedEnvironment ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_script_environment_panel__WEBPACK_IMPORTED_MODULE_9__.ScriptEnvironmentPanel, {
                environmentName: activeEnvironmentName,
                environment: selectedEnvironment,
                metadata: selectedMetadata
            }) : boundNodeHasNoEnvironments ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                variant: "outlined",
                sx: {
                    p: 3,
                    textAlign: 'center',
                    borderStyle: 'dashed'
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                    spacing: 2,
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                            color: "text.secondary",
                            children: "No environments are available for this script node."
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                            variant: "contained",
                            onClick: startFreshEnvironment,
                            disabled: registeredBuilders.length === 0,
                            children: "Create environment"
                        })
                    ]
                })
            }) : nodeControlsSelection ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                variant: "outlined",
                sx: {
                    p: 3,
                    textAlign: 'center',
                    borderStyle: 'dashed'
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                    color: "text.secondary",
                    children: "Select an environment in the script node editor."
                })
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                variant: "outlined",
                sx: {
                    p: 3,
                    textAlign: 'center',
                    borderStyle: 'dashed'
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                    color: "text.secondary",
                    children: "Select an environment to inspect its runtime and configuration."
                })
            }) : registeredBuilders.length === 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                severity: "warning",
                children: "No script environment builders are available."
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_20__["default"], {
                sx: {
                    display: 'grid',
                    gridTemplateColumns: expanded ? {
                        xs: 'minmax(0, 1fr)',
                        md: '260px minmax(0, 1fr)'
                    } : 'minmax(0, 1fr)',
                    gap: 2,
                    minWidth: 0
                },
                children: [
                    expanded && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                        variant: "outlined",
                        sx: {
                            minWidth: 0
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                                sx: {
                                    p: 1
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                                    startIcon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                        symbol: "add"
                                    }),
                                    onClick: startFreshEnvironment,
                                    children: "New environment"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_21__["default"], {}),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_22__["default"], {
                                dense: true,
                                children: Object.keys(environments).map((name)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_23__["default"], {
                                        selected: name === selectedEnvironmentName,
                                        onClick: ()=>{
                                            selectEnvironment(name);
                                            startEnvironmentEdit();
                                            loadEnvironmentDraft(name);
                                        },
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_24__["default"], {
                                            primary: name
                                        })
                                    }, name))
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                        spacing: 2,
                        minWidth: 0,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                label: "Environment Name",
                                value: envName,
                                onChange: (event)=>{
                                    const nextName = event.target.value;
                                    setEnvName(nextName);
                                    setNameError(mode === 'create' && environments[nextName] ? 'Duplicated name' : null);
                                },
                                disabled: mode === 'edit',
                                error: !!nameError,
                                helperText: nameError,
                                fullWidth: true
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                                direction: {
                                    xs: 'column',
                                    md: 'row'
                                },
                                spacing: 2,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                        select: true,
                                        label: "Builder",
                                        value: builder,
                                        onChange: (event)=>applyBuilder(event.target.value, true),
                                        fullWidth: true,
                                        children: registeredBuilders.map((registeredBuilder)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                value: registeredBuilder,
                                                children: registeredBuilder
                                            }, registeredBuilder))
                                    }),
                                    !(plugin === null || plugin === void 0 ? void 0 : plugin.defaultCodeField) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                        select: true,
                                        label: "Code Field",
                                        value: selectedCodeField,
                                        onChange: (event)=>handleCodeFieldChange(event.target.value),
                                        fullWidth: true,
                                        children: configKeys.length === 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                            disabled: true,
                                            value: "",
                                            children: "No string fields defined"
                                        }) : configKeys.map((key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                                                value: key,
                                                children: key
                                            }, key))
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                        label: "Scripting Language",
                                        value: language || 'python',
                                        disabled: true,
                                        fullWidth: true
                                    })
                                ]
                            }),
                            plugin ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(plugin.PropertiesForm, {
                                config: config,
                                onChange: setConfig,
                                onValidationError: setConfigError,
                                mode: mode,
                                registry: registry,
                                scriptText: scriptText
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                                label: "Builder Config (JSON)",
                                multiline: true,
                                rows: 4,
                                value: config,
                                onChange: (event)=>handleConfigChange(event.target.value),
                                error: !!configError,
                                helperText: configError,
                                fullWidth: true,
                                slotProps: {
                                    htmlInput: {
                                        sx: {
                                            fontFamily: 'monospace'
                                        }
                                    }
                                }
                            }),
                            activeCodeField && (plugin || configKeys.includes(activeCodeField)) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                        variant: "caption",
                                        color: "text.secondary",
                                        children: [
                                            "Script (",
                                            activeCodeField,
                                            ")"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_uiw_react_codemirror__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                        value: scriptText,
                                        height: expanded ? '50vh' : '300px',
                                        extensions: [
                                            ...(plugin === null || plugin === void 0 ? void 0 : (_plugin_codeExtensions = plugin.codeExtensions) === null || _plugin_codeExtensions === void 0 ? void 0 : _plugin_codeExtensions.call(plugin)) || [],
                                            _codemirror_language__WEBPACK_IMPORTED_MODULE_25__.indentUnit.of('    '),
                                            _codemirror_view__WEBPACK_IMPORTED_MODULE_26__.keymap.of([
                                                _codemirror_commands__WEBPACK_IMPORTED_MODULE_27__.indentWithTab
                                            ])
                                        ],
                                        onChange: handleScriptTextChange,
                                        theme: "dark"
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                                variant: "outlined",
                                sx: {
                                    p: 3,
                                    textAlign: 'center',
                                    backgroundColor: 'action.hover',
                                    borderStyle: 'dashed'
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {
                                    color: "text.secondary",
                                    children: "Define and select a string config field to edit its script."
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


}),
807: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  PythonPropertiesForm: () => (PythonPropertiesForm)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(559);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function schemaObject(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value) ? value : null;
}
function PythonPropertiesForm(param) {
    let { config, onChange, onValidationError, mode, registry, scriptText } = param;
    const ownershipOptions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        var _registry_scripting_processboundpython, _registry_scripting, _schema_properties, _ownershipProp_anyOf_, _ownershipProp_anyOf;
        const schema = schemaObject(registry === null || registry === void 0 ? void 0 : (_registry_scripting = registry.scripting) === null || _registry_scripting === void 0 ? void 0 : (_registry_scripting_processboundpython = _registry_scripting['process-bound-python']) === null || _registry_scripting_processboundpython === void 0 ? void 0 : _registry_scripting_processboundpython.config_schema);
        const ownershipProp = schema === null || schema === void 0 ? void 0 : (_schema_properties = schema.properties) === null || _schema_properties === void 0 ? void 0 : _schema_properties.ownership;
        const ref = (ownershipProp === null || ownershipProp === void 0 ? void 0 : ownershipProp.$ref) || (ownershipProp === null || ownershipProp === void 0 ? void 0 : (_ownershipProp_anyOf = ownershipProp.anyOf) === null || _ownershipProp_anyOf === void 0 ? void 0 : (_ownershipProp_anyOf_ = _ownershipProp_anyOf[0]) === null || _ownershipProp_anyOf_ === void 0 ? void 0 : _ownershipProp_anyOf_.$ref);
        let enumValues = [
            'shared',
            'persistent',
            'isolated'
        ];
        if (ref) {
            var _schema_definitions, _registry_schemas;
            const defName = ref.split('/').pop();
            const def = defName ? schemaObject(schema === null || schema === void 0 ? void 0 : (_schema_definitions = schema.definitions) === null || _schema_definitions === void 0 ? void 0 : _schema_definitions[defName]) || schemaObject(registry === null || registry === void 0 ? void 0 : (_registry_schemas = registry.schemas) === null || _registry_schemas === void 0 ? void 0 : _registry_schemas[defName]) : null;
            if (def === null || def === void 0 ? void 0 : def.enum) {
                enumValues = def.enum;
            }
        } else if (ownershipProp === null || ownershipProp === void 0 ? void 0 : ownershipProp.enum) {
            enumValues = ownershipProp.enum;
        }
        return enumValues;
    }, [
        registry
    ]);
    const getOwnershipValue = ()=>{
        try {
            const obj = JSON.parse(config);
            return obj.ownership || 'persistent';
        } catch  {
            return 'persistent';
        }
    };
    // Validate config is valid JSON
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        try {
            JSON.parse(config);
            onValidationError(null);
        } catch (err) {
            onValidationError(err instanceof Error ? err.message : 'Invalid JSON');
        }
    }, [
        config,
        onValidationError
    ]);
    const handleOwnershipChange = (newVal)=>{
        try {
            const obj = JSON.parse(config) || {};
            obj.ownership = newVal;
            onChange(JSON.stringify(obj, null, 2));
        } catch  {
            const obj = {
                ownership: newVal,
                script: scriptText
            };
            onChange(JSON.stringify(obj, null, 2));
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
        select: mode !== 'view',
        label: "Environment Ownership",
        value: getOwnershipValue(),
        onChange: (e)=>handleOwnershipChange(e.target.value),
        fullWidth: true,
        disabled: mode === 'view',
        sx: {
            flex: 1
        },
        children: ownershipOptions.map((opt)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
                value: opt,
                children: opt.charAt(0).toUpperCase() + opt.slice(1)
            }, opt))
    });
}


}),
803: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  scriptEnvironmentPlugins: () => (scriptEnvironmentPlugins)
});
/* ESM import */var _codemirror_lang_python__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(804);
/* ESM import */var _python_form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(807);


const scriptEnvironmentPlugins = {
    'process-bound-python': {
        PropertiesForm: _python_form__WEBPACK_IMPORTED_MODULE_0__.PythonPropertiesForm,
        defaultCodeField: 'script',
        bootstrapConfig: ()=>JSON.stringify({
                ownership: 'persistent',
                script: ''
            }, null, 2),
        codeExtensions: ()=>[
                (0,_codemirror_lang_python__WEBPACK_IMPORTED_MODULE_1__.python)()
            ]
    }
};


}),
870: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(559);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(766);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(584);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(579);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _diagram_properties_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(691);
/* ESM import */var _diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(769);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(147);
/* ESM import */var _transient_editor_drafts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(845);
/* ESM import */var _base_edit_operation_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(655);
/* ESM import */var _use_script_environment_navigation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(871);









const CREATE_ENVIRONMENT_VALUE = '__create_script_environment__';
function ScriptForm(props) {
    const [diagramProperties] = (0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_2__.useDiagramProperties)();
    const { drafts, setOperationConfigDraft } = (0,_transient_editor_drafts__WEBPACK_IMPORTED_MODULE_5__.useTransientEditorDrafts)();
    const environments = diagramProperties.script_environments || {};
    const openScriptEnvironment = (0,_use_script_environment_navigation__WEBPACK_IMPORTED_MODULE_7__.useScriptEnvironmentNavigation)();
    const { state: { open: panelOpen, tab: panelTab }, close: closePanel, startEnvironmentCreate } = (0,_diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_3__.useDiagramSidePanel)();
    // Track raw string of node config to support JSON editing
    const configDraftKey = `script:${props.node.id}:config`;
    const [configValue, setConfigValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(()=>drafts.operationConfigs[configDraftKey] ?? (props.node.data.op.config ? JSON.stringify(props.node.data.op.config, null, 2) : ''));
    const configError = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (configValue === '') return false;
        try {
            JSON.parse(configValue);
            return false;
        } catch  {
            return true;
        }
    }, [
        configValue
    ]);
    const handleEnvChange = (envName)=>{
        var _props_onChange;
        const updatedNode = {
            ...props.node,
            data: {
                ...props.node.data,
                op: {
                    ...props.node.data.op,
                    environment: envName
                }
            }
        };
        (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
            type: 'replace',
            id: props.node.id,
            item: updatedNode
        });
        openScriptEnvironment(envName, false);
    };
    // Real-time parse python entrypoint functions from selected environment
    const selectedEnvName = props.node.data.op.environment;
    const selectedEnv = selectedEnvName ? environments[selectedEnvName] : undefined;
    const scriptText = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!selectedEnv) return '';
        if (selectedEnv.builder === 'process-bound-python') {
            const pbConfig = selectedEnv.config;
            return (pbConfig === null || pbConfig === void 0 ? void 0 : pbConfig.script) || '';
        }
        const envRecord = selectedEnv;
        return envRecord.script || '';
    }, [
        selectedEnv
    ]);
    const availableFunctions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!scriptText) return [];
        const regex = /^[ \t]*(?:async\s+)?def\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(/gm;
        const functions = [];
        regex.lastIndex = 0;
        while(true){
            const match = regex.exec(scriptText);
            if (match === null) {
                break;
            }
            functions.push(match[1]);
        }
        return functions;
    }, [
        scriptText
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_base_edit_operation_form__WEBPACK_IMPORTED_MODULE_6__["default"], {
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                label: "Display Text",
                value: props.node.data.op.display_text || '',
                onChange: (ev)=>{
                    var _props_onChange;
                    const updatedNode = {
                        ...props.node
                    };
                    updatedNode.data.op.display_text = ev.target.value || undefined;
                    (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
                        type: 'replace',
                        id: props.node.id,
                        item: updatedNode
                    });
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                direction: "row",
                spacing: 1,
                alignItems: "center",
                minWidth: 0,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        select: true,
                        label: "Script Environment",
                        value: props.node.data.op.environment || '',
                        onChange: (e)=>{
                            if (e.target.value === CREATE_ENVIRONMENT_VALUE) {
                                startEnvironmentCreate();
                                return;
                            }
                            handleEnvChange(e.target.value);
                        },
                        fullWidth: true,
                        children: [
                            selectedEnvName && !selectedEnv && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                disabled: true,
                                value: selectedEnvName,
                                children: [
                                    selectedEnvName,
                                    " (missing)"
                                ]
                            }),
                            Object.keys(environments).length === 0 && !selectedEnvName ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                disabled: true,
                                value: "",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
                                    variant: "caption",
                                    color: "text.disabled",
                                    children: "No environments available, please create one"
                                })
                            }) : Object.keys(environments).map((envName)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                    value: envName,
                                    children: envName
                                }, envName)),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                                value: CREATE_ENVIRONMENT_VALUE,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                                    direction: "row",
                                    spacing: 1,
                                    alignItems: "center",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_4__.MaterialSymbol, {
                                            symbol: "add"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                            children: "Create new environment"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                        title: "Toggle script environment panel",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                            "aria-label": "Toggle script environment panel",
                            onClick: ()=>{
                                if (panelOpen && panelTab === 'environments') {
                                    closePanel();
                                    return;
                                }
                                openScriptEnvironment(props.node.data.op.environment || undefined, false);
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_4__.MaterialSymbol, {
                                symbol: "settings"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                freeSolo: true,
                autoSelect: true,
                options: availableFunctions,
                value: props.node.data.op.run || '',
                onChange: (_, val)=>{
                    var _props_onChange;
                    const updatedNode = {
                        ...props.node
                    };
                    updatedNode.data.op.run = val ?? '';
                    (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
                        type: 'replace',
                        id: props.node.id,
                        item: updatedNode
                    });
                },
                onInputChange: (_, val)=>{
                    var _props_onChange;
                    const updatedNode = {
                        ...props.node
                    };
                    updatedNode.data.op.run = val;
                    (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
                        type: 'replace',
                        id: props.node.id,
                        item: updatedNode
                    });
                },
                renderInput: (params)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        ...params,
                        required: true,
                        label: "Entrypoint Function (run)",
                        placeholder: "Select or type the script function"
                    })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                multiline: true,
                rows: 4,
                label: "Node Config (JSON)",
                value: configValue,
                onChange: (ev)=>{
                    setConfigValue(ev.target.value);
                    try {
                        var _props_onChange;
                        const updatedNode = {
                            ...props.node
                        };
                        updatedNode.data.op.config = ev.target.value === '' ? undefined : JSON.parse(ev.target.value);
                        (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
                            type: 'replace',
                            id: props.node.id,
                            item: updatedNode
                        });
                        setOperationConfigDraft(configDraftKey, undefined);
                    } catch  {
                        setOperationConfigDraft(configDraftKey, ev.target.value);
                    }
                },
                error: configError,
                slotProps: {
                    htmlInput: {
                        sx: {
                            fontFamily: 'monospace',
                            whiteSpace: 'nowrap'
                        }
                    }
                }
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ScriptForm);


}),
654: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  SectionBufferForm: () => (SectionBufferForm),
  SectionEdgeForm: () => (SectionEdgeForm),
  SectionForm: () => (SectionForm),
  SectionInputForm: () => (SectionInputForm),
  SectionOutputForm: () => (SectionOutputForm)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(656);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(658);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(584);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(660);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(579);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(147);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(321);
/* ESM import */var _templates_provider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(459);
/* ESM import */var _base_edit_operation_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(655);








function BaseSectionInterfaceForm(param) {
    let { node, onDelete, children } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                title: "Edit",
                action: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    color: "error",
                    onClick: ()=>onDelete === null || onDelete === void 0 ? void 0 : onDelete({
                            type: 'remove',
                            id: node.id
                        }),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_3__.MaterialSymbol, {
                        symbol: "delete"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], {
                children: children
            })
        ]
    });
}
function SectionInputForm(param) {
    let { node, onChange, onDelete } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(BaseSectionInterfaceForm, {
        node: node,
        onDelete: onDelete,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
            spacing: 2,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                required: true,
                label: "Remapped Id",
                value: node.data.remappedId,
                onChange: (ev)=>{
                    const updatedNode = {
                        ...node
                    };
                    updatedNode.data.remappedId = ev.target.value;
                    onChange === null || onChange === void 0 ? void 0 : onChange({
                        type: 'replace',
                        id: node.id,
                        item: updatedNode
                    });
                }
            })
        })
    });
}
function SectionBufferForm(param) {
    let { node, onChange, onDelete } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(BaseSectionInterfaceForm, {
        node: node,
        onDelete: onDelete,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
            spacing: 2,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                required: true,
                label: "Remapped Id",
                value: node.data.remappedId,
                onChange: (ev)=>{
                    const updatedNode = {
                        ...node
                    };
                    updatedNode.data.remappedId = ev.target.value;
                    onChange === null || onChange === void 0 ? void 0 : onChange({
                        type: 'replace',
                        id: node.id,
                        item: updatedNode
                    });
                }
            })
        })
    });
}
function SectionOutputForm(param) {
    let { node, onChange, onDelete } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(BaseSectionInterfaceForm, {
        node: node,
        onDelete: onDelete,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"], {
            spacing: 2,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                required: true,
                label: "Output Id",
                value: node.data.outputId,
                onChange: (ev)=>{
                    const updatedNode = {
                        ...node
                    };
                    updatedNode.data.outputId = ev.target.value;
                    onChange === null || onChange === void 0 ? void 0 : onChange({
                        type: 'replace',
                        id: node.id,
                        item: updatedNode
                    });
                }
            })
        })
    });
}
function SectionForm(props) {
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_4__.useRegistry)();
    const [templates, _setTemplates] = (0,_templates_provider__WEBPACK_IMPORTED_MODULE_5__.useTemplates)();
    const sectionBuilders = Object.keys(registry.sections);
    const sectionTemplates = Object.keys(templates);
    const sections = [
        ...sectionBuilders,
        ...sectionTemplates
    ].sort();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_base_edit_operation_form__WEBPACK_IMPORTED_MODULE_6__["default"], {
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                label: "Display Text",
                value: props.node.data.op.display_text || '',
                onChange: (ev)=>{
                    try {
                        var _props_onChange;
                        const updatedNode = {
                            ...props.node
                        };
                        updatedNode.data.op.display_text = ev.target.value || undefined;
                        (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
                            type: 'replace',
                            id: props.node.id,
                            item: updatedNode
                        });
                    } catch  {}
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                freeSolo: true,
                autoSelect: true,
                options: sections,
                getOptionLabel: (option)=>option,
                value: props.node.data.op.builder || props.node.data.op.template || '',
                onChange: (_, value)=>{
                    var _props_onChange;
                    if (value === null) {
                        return;
                    }
                    const updatedNode = {
                        ...props.node
                    };
                    if (sectionBuilders.includes(value)) {
                        updatedNode.data.op.builder = value;
                        delete updatedNode.data.op.template;
                    } else if (sectionTemplates.includes(value)) {
                        updatedNode.data.op.template = value;
                        delete updatedNode.data.op.builder;
                    } else {
                        // unable to determine if selected option is a builder or template, assume template.
                        updatedNode.data.op.template = value;
                        delete updatedNode.data.op.builder;
                    }
                    (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
                        type: 'replace',
                        id: props.node.id,
                        item: updatedNode
                    });
                },
                renderInput: (params)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                        ...params,
                        required: true,
                        label: "builder/template"
                    })
            })
        ]
    });
}
function SectionEdgeForm(param) {
    let { edge, onChange } = param;
    const nodeManager = (0,_node_manager__WEBPACK_IMPORTED_MODULE_2__.useNodeManager)();
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_4__.useRegistry)();
    const [templates, _setTemplates] = (0,_templates_provider__WEBPACK_IMPORTED_MODULE_5__.useTemplates)();
    const sourceNode = nodeManager.tryGetNode(edge.source);
    const outputs = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (sourceNode && (0,_nodes__WEBPACK_IMPORTED_MODULE_3__.isSectionNode)(sourceNode)) {
            if (typeof sourceNode.data.op.builder === 'string') {
                const sectionBuilder = registry.sections[sourceNode.data.op.builder];
                return Object.keys((sectionBuilder === null || sectionBuilder === void 0 ? void 0 : sectionBuilder.interface.outputs) || {});
            } else if (typeof sourceNode.data.op.template === 'string') {
                const template = templates[sourceNode.data.op.template];
                return (template === null || template === void 0 ? void 0 : template.outputs) || [];
            } else {
                return [];
            }
        } else {
            console.error('source node of a section edge is not a section node');
            return [];
        }
    }, [
        sourceNode,
        registry,
        templates
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
        freeSolo: true,
        autoSelect: true,
        options: outputs,
        getOptionLabel: (option)=>option,
        value: edge.data.output.output,
        onChange: (_, value)=>{
            onChange === null || onChange === void 0 ? void 0 : onChange({
                type: 'replace',
                id: edge.id,
                item: {
                    ...edge,
                    data: {
                        ...edge.data,
                        output: {
                            output: value || ''
                        }
                    }
                }
            });
        },
        renderInput: (params)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                ...params,
                required: true,
                label: "Section Output"
            })
    });
}


}),
667: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(575);


function SplitEdgeForm(param) {
    let { edge, onChange } = param;
    const handleDataChange = (event)=>{
        if (edge.type === 'splitKey') {
            const newKey = event.target.value;
            onChange === null || onChange === void 0 ? void 0 : onChange({
                type: 'replace',
                id: edge.id,
                item: {
                    ...edge,
                    data: {
                        ...edge.data,
                        output: {
                            key: newKey
                        }
                    }
                }
            });
        } else if (edge.type === 'splitSeq') {
            const newSeq = Number.parseInt(event.target.value, 10);
            if (!Number.isNaN(newSeq)) {
                onChange === null || onChange === void 0 ? void 0 : onChange({
                    type: 'replace',
                    id: edge.id,
                    item: {
                        ...edge,
                        data: {
                            ...edge.data,
                            output: {
                                seq: newSeq
                            }
                        }
                    }
                });
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            edge.type === 'splitKey' && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
                label: "Key",
                value: edge.data.output.key ?? 'unnamed_key',
                onChange: handleDataChange,
                fullWidth: true
            }),
            edge.type === 'splitSeq' && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
                label: "Sequence",
                type: "number",
                value: edge.data.output.seq ?? 0,
                onChange: handleDataChange,
                fullWidth: true
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SplitEdgeForm);


}),
668: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  StreamOutEdgeForm: () => (StreamOutEdgeForm)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(579);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(575);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(321);




function StreamOutEdgeForm(param) {
    let { edge, nodeManager, onChange } = param;
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_2__.useRegistry)();
    const sourceNode = nodeManager.getNode(edge.source);
    const builderMetadata = (0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isOperationNode)(sourceNode) && sourceNode.data.op.type === 'node' ? registry.nodes[sourceNode.data.op.builder] : null;
    const streams = builderMetadata ? Object.keys(builderMetadata.streams) : [];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
            freeSolo: true,
            autoSelect: true,
            fullWidth: true,
            options: streams,
            getOptionLabel: (option)=>option,
            value: edge.data.output.streamId,
            onChange: (_, value)=>{
                const newStreamId = value || '';
                onChange === null || onChange === void 0 ? void 0 : onChange({
                    type: 'replace',
                    id: edge.id,
                    item: {
                        ...edge,
                        data: {
                            ...edge.data,
                            output: {
                                streamId: newStreamId
                            }
                        }
                    }
                });
            },
            renderInput: (params)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
                    ...params,
                    required: true,
                    label: "Stream"
                })
        })
    });
}


}),
872: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  StreamOutForm: () => (StreamOutForm)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(575);
/* ESM import */var _base_edit_operation_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(655);



function StreamOutForm(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_edit_operation_form__WEBPACK_IMPORTED_MODULE_1__["default"], {
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
            required: true,
            label: "Stream",
            fullWidth: true,
            value: props.node.data.op.name,
            onChange: (ev)=>{
                var _props_onChange;
                const updatedNode = {
                    ...props.node
                };
                updatedNode.data.op.name = ev.target.value;
                (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
                    type: 'replace',
                    id: props.node.id,
                    item: updatedNode
                });
            }
        })
    });
}


}),
873: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(575);
/* ESM import */var cel_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* ESM import */var _base_edit_operation_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(655);





function TransformForm(props) {
    const celError = react__WEBPACK_IMPORTED_MODULE_2___default().useMemo(()=>(0,cel_js__WEBPACK_IMPORTED_MODULE_1__.parse)(props.node.data.op.cel).isSuccess, [
        props.node.data.op.cel
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_edit_operation_form__WEBPACK_IMPORTED_MODULE_3__["default"], {
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
            label: "CEL",
            multiline: true,
            fullWidth: true,
            sx: {
                width: 300
            },
            value: props.node.data.op.cel,
            slotProps: {
                htmlInput: {
                    style: {
                        fontFamily: 'monospace',
                        whiteSpace: 'pre'
                    }
                }
            },
            error: !celError,
            onChange: (ev)=>{
                var _props_onChange;
                const updatedNode = {
                    ...props.node,
                    data: {
                        ...props.node.data,
                        op: {
                            ...props.node.data.op,
                            cel: ev.target.value
                        }
                    }
                };
                (_props_onChange = props.onChange) === null || _props_onChange === void 0 ? void 0 : _props_onChange.call(props, {
                    type: 'replace',
                    id: props.node.id,
                    item: updatedNode
                });
            }
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransformForm);


}),
669: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(575);


function UnzipEdgeForm(param) {
    let { edge, onChange } = param;
    var _edge_data;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
            label: "index",
            type: "number",
            value: ((_edge_data = edge.data) === null || _edge_data === void 0 ? void 0 : _edge_data.seq) ?? 0,
            onChange: (ev)=>{
                const value = Number.parseInt(ev.target.value, 10);
                if (!Number.isNaN(value) && edge.data) {
                    edge.data.seq = value;
                    onChange === null || onChange === void 0 ? void 0 : onChange({
                        type: 'replace',
                        id: edge.id,
                        item: edge
                    });
                }
            }
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UnzipEdgeForm);


}),
871: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  useScriptEnvironmentNavigation: () => (useScriptEnvironmentNavigation)
});
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* ESM import */var _diagram_properties_provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(691);
/* ESM import */var _diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(769);



function useScriptEnvironmentNavigation() {
    const [diagramProperties] = (0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_1__.useDiagramProperties)();
    const { openEnvironments } = (0,_diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_2__.useDiagramSidePanel)();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function(environmentName) {
        let isNew = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
        const hasEnvironments = Object.keys(diagramProperties.script_environments || {}).length > 0;
        openEnvironments({
            environmentName,
            create: isNew && !hasEnvironments
        });
    }, [
        diagramProperties.script_environments,
        openEnvironments
    ]);
}


}),
149: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  Handle: () => (Handle),
  HandleId: () => (HandleId),
  HandleType: () => (HandleType)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(25);
/* ESM import */var _connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(150);
/* ESM import */var _utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(319);




var HandleId = /*#__PURE__*/ function(HandleId) {
    HandleId["DataStream"] = "dataStream";
    HandleId["ForkResultOk"] = "forkResultOk";
    HandleId["ForkResultErr"] = "forkResultErr";
    return HandleId;
}({});
var HandleType = /*#__PURE__*/ function(HandleType) {
    HandleType[HandleType["Data"] = 0] = "Data";
    HandleType[HandleType["Buffer"] = 1] = "Buffer";
    HandleType[HandleType["DataStream"] = 2] = "DataStream";
    HandleType[HandleType["DataBuffer"] = 3] = "DataBuffer";
    return HandleType;
}({});
function variantClassName(handleType) {
    if (handleType === undefined) {
        return undefined;
    }
    switch(handleType){
        case 0:
            {
                // use the default style
                return undefined;
            }
        case 1:
            {
                return 'handle-buffer';
            }
        case 3:
            {
                return 'handle-data-buffer';
            }
        case 2:
            {
                return 'handle-data-stream';
            }
        default:
            {
                (0,_utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_2__.exhaustiveCheck)(handleType);
                throw new Error('unknown edge category');
            }
    }
}
function Handle(param) {
    let { id, variant, className, ...baseProps } = param;
    const nodeId = (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_3__.useNodeId)();
    const connection = (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_3__.useConnection)();
    const handleType = baseProps.type || 'source';
    const compatibility = (0,_connection_compatibility_provider__WEBPACK_IMPORTED_MODULE_1__.useDraggedConnectionCompatibility)({
        otherNodeId: nodeId,
        otherHandleId: id,
        otherHandleType: handleType
    });
    const classNames = [];
    const variantClass = variantClassName(variant);
    if (variantClass) {
        classNames.push(variantClass);
    }
    if (className) {
        classNames.push(className);
    }
    if (compatibility && compatibility.status !== 'unknown' && connection.inProgress) {
        classNames.push(compatibility.status === 'compatible' ? 'handle-compatible' : 'handle-incompatible');
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_xyflow_react__WEBPACK_IMPORTED_MODULE_3__.Handle, {
        ...baseProps,
        id: id,
        className: classNames.length > 0 ? classNames.join(' ') : undefined
    });
}


}),
0: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _material_symbols_font_400__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* ESM import */var react_dom_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8);
/* ESM import */var _app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17);





const rootEl = document.getElementById('root');
if (rootEl) {
    const root = react_dom_client__WEBPACK_IMPORTED_MODULE_3__.createRoot(rootEl);
    root.render(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react__WEBPACK_IMPORTED_MODULE_2___default().StrictMode), {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_app__WEBPACK_IMPORTED_MODULE_4__["default"], {})
    }));
}


}),
676: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  InteractionVisualizationProvider: () => (InteractionVisualizationProvider),
  useInteractionVisualization: () => (useInteractionVisualization)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const DefaultInteractionVisualizationContext = {
    isWorkflowRunning: false,
    setWorkflowRunning: ()=>{},
    activeNodeIds: new Set(),
    visitedNodeIds: new Set(),
    clearInteractionVisualization: ()=>{},
    markInteractionFinished: ()=>{},
    markInteractionOperationFinished: ()=>{},
    markInteractionOperationStarted: ()=>{}
};
const InteractionVisualizationContextComp = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(DefaultInteractionVisualizationContext);
function InteractionVisualizationProvider(param) {
    let { value, children } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(InteractionVisualizationContextComp.Provider, {
        value: value,
        children: children
    });
}
function useInteractionVisualization() {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(InteractionVisualizationContextComp);
}


}),
811: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  LoadContextProvider: () => (LoadContextProvider),
  useLoadContext: () => (useLoadContext)
});
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const LoadContextComp = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
const LoadContextProvider = LoadContextComp.Provider;
const useLoadContext = ()=>{
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(LoadContextComp);
};


}),
1184: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  NewDiagramDialog: () => (NewDiagramDialog),
  useNewDiagramAfterExport: () => (useNewDiagramAfterExport)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(835);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(838);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(840);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1185);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(795);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(842);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(678);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function useNewDiagramAfterExport(onExportCompleted, onStartNew) {
    const pending = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(false);
    const begin = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        pending.current = true;
    }, []);
    const cancel = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        pending.current = false;
    }, []);
    const complete = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((filename)=>{
        onExportCompleted(filename);
        if (pending.current) {
            pending.current = false;
            onStartNew();
        }
    }, [
        onExportCompleted,
        onStartNew
    ]);
    return {
        begin,
        cancel,
        complete
    };
}
function NewDiagramDialog(param) {
    let { open, canSave, onCancel, onDiscard, onSave } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__["default"], {
        open: open,
        onClose: onCancel,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
                children: "Start a new diagram?"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
                        children: "Your current diagram has changes. Save it to a file before starting a new diagram?"
                    }),
                    !canSave && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
                        severity: "warning",
                        sx: {
                            mt: 2
                        },
                        children: "Some editor changes cannot be exported yet. Fix or discard them before saving to a file."
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        onClick: onCancel,
                        children: "Cancel"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        color: "error",
                        onClick: onDiscard,
                        children: "Discard"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        variant: "contained",
                        disabled: !canSave,
                        onClick: onSave,
                        children: "Save & New"
                    })
                ]
            })
        ]
    });
}


}),
145: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  NodeManager: () => (NodeManager),
  NodeManagerProvider: () => (NodeManagerProvider),
  useNodeManager: () => (useNodeManager)
});
/* ESM import */var _swc_helpers_define_property__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(146);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);
/* ESM import */var _utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(319);
/* ESM import */var _utils_namespace__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(671);
/* ESM import */var _utils_operation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(672);






class NodeManager {
    tryGetNode(nodeId) {
        return this.nodeIdMap.get(nodeId) || null;
    }
    getNode(nodeId) {
        const node = this.tryGetNode(nodeId);
        if (!node) {
            throw new Error(`cannot find node "${nodeId}"`);
        }
        return node;
    }
    iterNodes() {
        return this.nodeIdMap.values();
    }
    hasNode(nodeId) {
        try {
            this.getNode(nodeId);
            return true;
        } catch  {
            return false;
        }
    }
    getNodeFromNamespaceOpId(namespace, opId) {
        const namespacedOpId = (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_3__.joinNamespaces)(namespace, opId);
        const node = this.namespacedOpIdMap.get(namespacedOpId);
        if (!node) {
            throw new Error(`cannot find node for operation "${namespacedOpId}"`);
        }
        return node;
    }
    getNodeFromRootOpId(opId) {
        return this.getNodeFromNamespaceOpId(_utils_namespace__WEBPACK_IMPORTED_MODULE_3__.ROOT_NAMESPACE, opId);
    }
    /**
   * @returns returns `null` if the next operation points to a builtin node not rendered in the editor (e.g. `dispose`, `cancel`).
   */ getNodeFromNextOp(namespace, nextOp) {
        if ((0,_utils_operation__WEBPACK_IMPORTED_MODULE_4__.isBuiltin)(nextOp)) {
            switch(nextOp.builtin){
                case 'dispose':
                case 'cancel':
                    return null;
                case 'terminate':
                    return this.getNode((0,_utils_namespace__WEBPACK_IMPORTED_MODULE_3__.joinNamespaces)(namespace, _nodes__WEBPACK_IMPORTED_MODULE_1__.TERMINATE_ID));
            }
        }
        const opId = (()=>{
            if (typeof nextOp === 'object') {
                return Object.keys(nextOp)[0];
            }
            return nextOp;
        })();
        const namespacedOpId = (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_3__.joinNamespaces)(namespace, opId);
        const node = this.namespacedOpIdMap.get(namespacedOpId);
        if (!node) {
            throw new Error(`cannot find operation ${(0,_utils_namespace__WEBPACK_IMPORTED_MODULE_3__.joinNamespaces)(namespace, opId)}`);
        }
        return node;
    }
    getTargetNextOp(edge) {
        // TODO: Validate that the edge does not traverse namespaces
        switch(edge.data.input.type){
            case 'bufferKey':
            case 'bufferSeq':
            case 'default':
                {
                    const target = this.getNode(edge.target);
                    if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isBuiltinNode)(target)) {
                        return {
                            builtin: target.type
                        };
                    }
                    if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isOperationNode)(target)) {
                        return target.data.opId;
                    }
                    if (target.type === 'sectionOutput') {
                        return target.data.outputId;
                    }
                    throw new Error('unknown node type');
                }
            case 'sectionBuffer':
            case 'sectionInput':
                {
                    const target = this.getNode(edge.target);
                    if (target.type !== 'section') {
                        throw new Error('edge is connecting to a section input slot but target is not a section');
                    }
                    return {
                        [target.data.opId]: edge.data.input.inputId
                    };
                }
            default:
                {
                    (0,_utils_exhaustive_check__WEBPACK_IMPORTED_MODULE_2__.exhaustiveCheck)(edge.data.input);
                    throw new Error('unknown edge input');
                }
        }
    }
    constructor(nodes){
        (0,_swc_helpers_define_property__WEBPACK_IMPORTED_MODULE_5__._)(this, "nodes", void 0);
        (0,_swc_helpers_define_property__WEBPACK_IMPORTED_MODULE_5__._)(this, "nodeIdMap", void 0);
        (0,_swc_helpers_define_property__WEBPACK_IMPORTED_MODULE_5__._)(this, "namespacedOpIdMap", void 0);
        this.nodes = nodes;
        this.nodeIdMap = new Map();
        this.namespacedOpIdMap = new Map();
        for (const node of nodes){
            this.nodeIdMap.set(node.id, node);
            if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isOperationNode)(node)) {
                const namespacedOpId = (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_3__.joinNamespaces)(node.data.namespace, node.data.opId);
                this.namespacedOpIdMap.set(namespacedOpId, node);
            } else if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isBuiltinNode)(node)) {
                this.namespacedOpIdMap.set(node.id, node);
            } else if (node.type === 'sectionOutput') {
                // This will conflict if there is an op in a template with the same id as an output.
                // However, this conflict exist in crossflow as well, so we assume that it will not happen.
                this.namespacedOpIdMap.set((0,_utils_namespace__WEBPACK_IMPORTED_MODULE_3__.joinNamespaces)(_utils_namespace__WEBPACK_IMPORTED_MODULE_3__.ROOT_NAMESPACE, node.data.outputId), node);
            }
        }
    }
}
const NodeManagerContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(new NodeManager([]));
const NodeManagerProvider = NodeManagerContext.Provider;
function useNodeManager() {
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(NodeManagerContext);
}


}),
675: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(522);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(358);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(678);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(332);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(435);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _interaction_visualization_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(676);
/* ESM import */var _utils_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(677);





const CompactNodeSize = 42;
function BaseNode(param) {
    let { color, icon: materialIconOrSymbol, label, caption, handles, selected, id, highlight, compact, cylinder } = param;
    const { activeNodeIds, visitedNodeIds } = (0,_interaction_visualization_provider__WEBPACK_IMPORTED_MODULE_2__.useInteractionVisualization)();
    const interactionActive = activeNodeIds.has(id);
    const interactionVisited = visitedNodeIds.has(id) && !interactionActive;
    const icon = typeof materialIconOrSymbol === 'string' ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
        className: `material-symbols-${materialIconOrSymbol}`
    }) : materialIconOrSymbol;
    const borderRadius = compact ? '50%' : cylinder ? '50% / 8px' : undefined;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
        sx: (theme)=>({
                borderRadius,
                outline: interactionActive ? `2px solid ${theme.palette.success.main}` : interactionVisited ? `2px solid ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.alpha)(theme.palette.info.main, 0.35)}` : highlight ? `2px solid ${theme.palette.warning.main}` : undefined,
                boxShadow: interactionActive ? [
                    `0 0 0 4px ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.alpha)(theme.palette.success.main, 0.28)}`,
                    `0 0 18px 6px ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.alpha)(theme.palette.success.main, 0.35)}`
                ].join(', ') : interactionVisited ? [
                    `0 0 0 2px ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.alpha)(theme.palette.info.main, 0.28)}`,
                    `0 0 8px 3px ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.alpha)(theme.palette.info.main, 0.35)}`
                ].join(', ') : undefined,
                transition: theme.transitions.create([
                    'box-shadow',
                    'outline-color'
                ], {
                    duration: theme.transitions.duration.shortest
                })
            }),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
                title: label,
                "aria-label": compact ? label : undefined,
                color: color,
                fullWidth: !compact,
                startIcon: compact ? undefined : icon,
                variant: selected ? 'contained' : 'outlined',
                sx: {
                    textTransform: 'none',
                    ...cylinder && {
                        borderRadius,
                        paddingTop: '16px',
                        '&::before': {
                            content: '""',
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            right: 0,
                            height: '14px',
                            borderBottom: '1px solid currentColor',
                            borderRadius: '50%',
                            pointerEvents: 'none'
                        }
                    },
                    ...compact ? {
                        width: CompactNodeSize,
                        minWidth: CompactNodeSize,
                        height: CompactNodeSize,
                        borderRadius: '50%',
                        padding: 0
                    } : {
                        width: cylinder ? 150 : _utils_layout__WEBPACK_IMPORTED_MODULE_3__.LAYOUT_OPTIONS.nodeWidth,
                        height: cylinder ? 44 : _utils_layout__WEBPACK_IMPORTED_MODULE_3__.LAYOUT_OPTIONS.nodeHeight
                    }
                },
                children: compact ? icon : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {
                    sx: {
                        minWidth: 0
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_8__["default"], {
                            component: "span",
                            sx: {
                                minWidth: 0,
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap'
                            },
                            children: label
                        }),
                        caption && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_9__["default"], {
                            variant: "caption",
                            fontSize: 8,
                            sx: {
                                minWidth: 0,
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap'
                            },
                            children: caption
                        })
                    ]
                })
            }),
            handles
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(BaseNode));


}),
148: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(682);





function BufferAccessNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...props,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_3__.BufferAccessIcon, {}),
        label: "Buffer Access",
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.DataBuffer
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BufferAccessNodeComp);


}),
683: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(682);





function BufferNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...props,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_3__.BufferIcon, {}),
        label: props.data.op.display_text || props.data.opId || '',
        cylinder: true,
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Buffer
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BufferNodeComp);


}),
699: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  createOperationNode: () => (createOperationNode),
  createScopeNode: () => (createScopeNode),
  createSectionBufferNode: () => (createSectionBufferNode),
  createSectionInputNode: () => (createSectionInputNode),
  createSectionOutputNode: () => (createSectionOutputNode),
  createStartNode: () => (createStartNode),
  createTerminateNode: () => (createTerminateNode)
});
/* ESM import */var uuid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(311);
/* ESM import */var _utils_layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(677);
/* ESM import */var _utils_namespace__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(671);
/* ESM import */var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(147);




function createStartNode(namespace, position) {
    return {
        // NOTE: atm `NodeManager` relies on how the id of builtin nodes is computed to locate them.
        id: (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_1__.joinNamespaces)(namespace, ___WEBPACK_IMPORTED_MODULE_2__.START_ID),
        type: 'start',
        position,
        selectable: false,
        data: {
            namespace
        }
    };
}
function createTerminateNode(namespace, position) {
    return {
        // NOTE: atm `NodeManager` relies on how the id of builtin nodes is computed to locate them.
        id: (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_1__.joinNamespaces)(namespace, ___WEBPACK_IMPORTED_MODULE_2__.TERMINATE_ID),
        type: 'terminate',
        position,
        selectable: false,
        data: {
            namespace
        }
    };
}
/**
 * Create a section input node. For simplicity, remapping the input is not supported, `targetId`
 * must point to the id of an operation in the template.
 */ function createSectionInputNode(remappedId, targetId, position) {
    return {
        id: (0,uuid__WEBPACK_IMPORTED_MODULE_3__["default"])(),
        type: 'sectionInput',
        data: {
            remappedId,
            targetId
        },
        position
    };
}
function createSectionOutputNode(outputId, position) {
    return {
        id: (0,uuid__WEBPACK_IMPORTED_MODULE_3__["default"])(),
        type: 'sectionOutput',
        data: {
            outputId
        },
        position
    };
}
/**
 * Create a section input node. For simplicity, remapping the input is not supported, `targetId`
 * must point to the id of a `buffer` operation in the template.
 */ function createSectionBufferNode(remappedId, targetId, position) {
    return {
        id: (0,uuid__WEBPACK_IMPORTED_MODULE_3__["default"])(),
        type: 'sectionBuffer',
        data: {
            remappedId,
            targetId
        },
        position
    };
}
function createOperationNode(namespace, parentId, position, op, opId) {
    return {
        id: (0,uuid__WEBPACK_IMPORTED_MODULE_3__["default"])(),
        type: op.type,
        position,
        data: {
            namespace,
            opId,
            op
        },
        ...parentId && {
            parentId
        }
    };
}
function createScopeNode(namespace, parentId, position, op, opId) {
    const scopeId = (0,uuid__WEBPACK_IMPORTED_MODULE_3__["default"])();
    const children = [
        {
            id: (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_1__.joinNamespaces)(namespace, opId, ___WEBPACK_IMPORTED_MODULE_2__.START_ID),
            type: 'start',
            position: {
                x: _utils_layout__WEBPACK_IMPORTED_MODULE_0__.LAYOUT_OPTIONS.scopePadding.leftRight,
                y: _utils_layout__WEBPACK_IMPORTED_MODULE_0__.LAYOUT_OPTIONS.scopePadding.topBottom
            },
            data: {
                namespace: (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_1__.joinNamespaces)(namespace, opId)
            },
            parentId: scopeId
        },
        {
            id: (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_1__.joinNamespaces)(namespace, opId, ___WEBPACK_IMPORTED_MODULE_2__.TERMINATE_ID),
            type: 'terminate',
            position: {
                x: _utils_layout__WEBPACK_IMPORTED_MODULE_0__.LAYOUT_OPTIONS.scopePadding.leftRight,
                y: _utils_layout__WEBPACK_IMPORTED_MODULE_0__.LAYOUT_OPTIONS.scopePadding.topBottom * 5
            },
            data: {
                namespace: (0,_utils_namespace__WEBPACK_IMPORTED_MODULE_1__.joinNamespaces)(namespace, opId)
            },
            parentId: scopeId
        }
    ];
    const scopeBounds = (0,_utils_layout__WEBPACK_IMPORTED_MODULE_0__.calculateScopeBounds)(children.map((child)=>child.position));
    return [
        {
            id: scopeId,
            type: 'scope',
            position: {
                x: position.x + scopeBounds.x,
                y: position.y + scopeBounds.y
            },
            data: {
                namespace,
                opId,
                op
            },
            width: scopeBounds.width,
            height: scopeBounds.height,
            zIndex: -1,
            ...parentId && {
                parentId
            }
        },
        ...children
    ];
}


}),
684: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(682);





function ForkCloneNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...props,
        compact: true,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_3__.ForkCloneIcon, {}),
        label: "Fork Clone",
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ForkCloneNodeComp);


}),
685: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(439);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(682);






const ForkResultOkHandle = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"])(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle)((param)=>{
    let { theme } = param;
    return {
        left: '25%',
        backgroundColor: theme.palette.success.main
    };
});
const ForkResultErrHandle = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"])(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle)((param)=>{
    let { theme } = param;
    return {
        left: '75%',
        backgroundColor: theme.palette.error.main
    };
});
function ForkResultNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...props,
        compact: true,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_3__.ForkResultIcon, {}),
        label: "Fork Result",
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_5__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ForkResultOkHandle, {
                    id: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleId.ForkResultOk,
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_5__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ForkResultErrHandle, {
                    id: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleId.ForkResultErr,
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_5__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ForkResultNodeComp);


}),
682: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  BufferAccessIcon: () => (BufferAccessIcon),
  BufferIcon: () => (BufferIcon),
  ForkCloneIcon: () => (ForkCloneIcon),
  ForkResultIcon: () => (ForkResultIcon),
  JoinIcon: () => (JoinIcon),
  ListenIcon: () => (ListenIcon),
  MaterialSymbol: () => (MaterialSymbol),
  NodeIcon: () => (NodeIcon),
  OPERATION_ICONS: () => (OPERATION_ICONS),
  ScopeIcon: () => (ScopeIcon),
  ScriptIcon: () => (ScriptIcon),
  SectionBufferIcon: () => (SectionBufferIcon),
  SectionIcon: () => (SectionIcon),
  SectionInputIcon: () => (SectionInputIcon),
  SectionOutputIcon: () => (SectionOutputIcon),
  SplitIcon: () => (SplitIcon),
  StreamOutIcon: () => (StreamOutIcon),
  TransformIcon: () => (TransformIcon),
  UnzipIcon: () => (UnzipIcon),
  getAddOperationIcon: () => (getAddOperationIcon)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(332);


function MaterialSymbol(param) {
    let { symbol, className, ...otherProps } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_1__["default"], {
        component: "span",
        className: `material-symbols-outlined ${className}`,
        ...otherProps,
        children: symbol
    });
}
function NodeIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "line_start_circle"
    });
}
function ForkCloneIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "content_copy"
    });
}
function ForkResultIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "question_mark"
    });
}
function TransformIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "change_circle"
    });
}
function ScriptIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "code"
    });
}
function BufferIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "database"
    });
}
function BufferAccessIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "database_upload"
    });
}
function SplitIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "call_split",
        sx: {
            transform: 'scaleY(-1)'
        }
    });
}
function ListenIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "hearing"
    });
}
function JoinIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "call_merge",
        sx: {
            transform: 'scaleY(-1)'
        }
    });
}
function StreamOutIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "notes"
    });
}
function ScopeIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "rectangle"
    });
}
function SectionIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "select_all"
    });
}
function SectionInputIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "input"
    });
}
function SectionOutputIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "output"
    });
}
function SectionBufferIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "database"
    });
}
function UnzipIcon() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MaterialSymbol, {
        symbol: "format_list_numbered"
    });
}
const OPERATION_ICONS = {
    sectionInput: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SectionInputIcon, {}),
    sectionOutput: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SectionOutputIcon, {}),
    sectionBuffer: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SectionBufferIcon, {}),
    node: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(NodeIcon, {}),
    fork_clone: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ForkCloneIcon, {}),
    unzip: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(UnzipIcon, {}),
    fork_result: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ForkResultIcon, {}),
    split: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SplitIcon, {}),
    join: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(JoinIcon, {}),
    transform: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TransformIcon, {}),
    buffer: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(BufferIcon, {}),
    buffer_access: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(BufferAccessIcon, {}),
    listen: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ListenIcon, {}),
    stream_out: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(StreamOutIcon, {}),
    scope: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ScopeIcon, {}),
    section: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SectionIcon, {}),
    script: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ScriptIcon, {})
};
const VALID_OPERATION_KEYS = new Set(Object.keys(OPERATION_ICONS));
function getAddOperationIcon(key) {
    if (typeof key === 'string' && key.startsWith('node:')) {
        return OPERATION_ICONS.node;
    }
    if (typeof key === 'string' && VALID_OPERATION_KEYS.has(key)) {
        return OPERATION_ICONS[key];
    }
    return OPERATION_ICONS.node;
}


}),
147: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  BufferAccessIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.BufferAccessIcon),
  BufferIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.BufferIcon),
  ForkCloneIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.ForkCloneIcon),
  ForkResultIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.ForkResultIcon),
  JoinIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.JoinIcon),
  ListenIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.ListenIcon),
  MaterialSymbol: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.MaterialSymbol),
  NODE_TYPES: () => (NODE_TYPES),
  NodeIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.NodeIcon),
  OPERATION_ICONS: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.OPERATION_ICONS),
  START_ID: () => (START_ID),
  ScopeIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.ScopeIcon),
  ScriptIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.ScriptIcon),
  SectionBufferIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.SectionBufferIcon),
  SectionIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.SectionIcon),
  SectionInputIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.SectionInputIcon),
  SectionOutputIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.SectionOutputIcon),
  SplitIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.SplitIcon),
  StreamOutIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.StreamOutIcon),
  TERMINATE_ID: () => (TERMINATE_ID),
  TransformIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.TransformIcon),
  UnzipIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.UnzipIcon),
  createOperationNode: () => (/* reexport safe */ _create_node__WEBPACK_IMPORTED_MODULE_16__.createOperationNode),
  createScopeNode: () => (/* reexport safe */ _create_node__WEBPACK_IMPORTED_MODULE_16__.createScopeNode),
  createSectionBufferNode: () => (/* reexport safe */ _create_node__WEBPACK_IMPORTED_MODULE_16__.createSectionBufferNode),
  createSectionInputNode: () => (/* reexport safe */ _create_node__WEBPACK_IMPORTED_MODULE_16__.createSectionInputNode),
  createSectionOutputNode: () => (/* reexport safe */ _create_node__WEBPACK_IMPORTED_MODULE_16__.createSectionOutputNode),
  createStartNode: () => (/* reexport safe */ _create_node__WEBPACK_IMPORTED_MODULE_16__.createStartNode),
  createTerminateNode: () => (/* reexport safe */ _create_node__WEBPACK_IMPORTED_MODULE_16__.createTerminateNode),
  getAddOperationIcon: () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_17__.getAddOperationIcon),
  isBuiltinNode: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_18__.isBuiltinNode),
  isOperationData: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_18__.isOperationData),
  isOperationNode: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_18__.isOperationNode),
  isScopeNode: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_18__.isScopeNode),
  isSectionBufferNode: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_18__.isSectionBufferNode),
  isSectionInputNode: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_18__.isSectionInputNode),
  isSectionInterfaceNode: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_18__.isSectionInterfaceNode),
  isSectionNode: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_18__.isSectionNode),
  isSectionOutputNode: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_18__.isSectionOutputNode)
});
/* ESM import */var _buffer_access_node__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(148);
/* ESM import */var _buffer_node__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(683);
/* ESM import */var _fork_clone_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(684);
/* ESM import */var _fork_result_node__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(685);
/* ESM import */var _join_node__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(686);
/* ESM import */var _listen_node__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(687);
/* ESM import */var _node_node__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(688);
/* ESM import */var _scope_node__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(689);
/* ESM import */var _script_node__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(690);
/* ESM import */var _section_node__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(692);
/* ESM import */var _split_node__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(693);
/* ESM import */var _start_node__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(694);
/* ESM import */var _stream_out_node__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(695);
/* ESM import */var _terminate_node__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(696);
/* ESM import */var _transform_node__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(697);
/* ESM import */var _unzip_node__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(698);
/* ESM import */var _create_node__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(699);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(682);
/* ESM import */var _utils__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(700);



















const START_ID = '__builtin_start__';
const TERMINATE_ID = '__builtin_terminate__';
const NODE_TYPES = {
    start: _start_node__WEBPACK_IMPORTED_MODULE_11__["default"],
    terminate: _terminate_node__WEBPACK_IMPORTED_MODULE_13__["default"],
    node: _node_node__WEBPACK_IMPORTED_MODULE_6__["default"],
    section: _section_node__WEBPACK_IMPORTED_MODULE_9__["default"],
    sectionInput: _section_node__WEBPACK_IMPORTED_MODULE_9__.SectionInputNodeComp,
    sectionOutput: _section_node__WEBPACK_IMPORTED_MODULE_9__.SectionOutputNodeComp,
    sectionBuffer: _section_node__WEBPACK_IMPORTED_MODULE_9__.SectionBufferNodeComp,
    fork_clone: _fork_clone_node__WEBPACK_IMPORTED_MODULE_2__["default"],
    unzip: _unzip_node__WEBPACK_IMPORTED_MODULE_15__["default"],
    fork_result: _fork_result_node__WEBPACK_IMPORTED_MODULE_3__["default"],
    split: _split_node__WEBPACK_IMPORTED_MODULE_10__["default"],
    join: _join_node__WEBPACK_IMPORTED_MODULE_4__["default"],
    transform: _transform_node__WEBPACK_IMPORTED_MODULE_14__["default"],
    script: _script_node__WEBPACK_IMPORTED_MODULE_8__["default"],
    buffer: _buffer_node__WEBPACK_IMPORTED_MODULE_1__["default"],
    buffer_access: _buffer_access_node__WEBPACK_IMPORTED_MODULE_0__["default"],
    listen: _listen_node__WEBPACK_IMPORTED_MODULE_5__["default"],
    scope: _scope_node__WEBPACK_IMPORTED_MODULE_7__["default"],
    stream_out: _stream_out_node__WEBPACK_IMPORTED_MODULE_12__["default"]
};


}),
686: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(682);





function JoinNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...props,
        compact: true,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_3__.JoinIcon, {}),
        label: "Join",
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Buffer
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (JoinNodeComp);


}),
687: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(682);





function ListenNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...props,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_3__.ListenIcon, {}),
        label: "Listen",
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Buffer
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListenNodeComp);


}),
688: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(27);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(149);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(321);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(682);







function NodeNodeComp(props) {
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_3__.useRegistry)();
    const builderMetadata = registry.nodes[props.data.op.builder];
    const label = props.data.op.display_text ? props.data.op.display_text : builderMetadata ? builderMetadata.default_display_text : 'Select Builder';
    const hasStreams = !!((builderMetadata === null || builderMetadata === void 0 ? void 0 : builderMetadata.streams) && Object.keys(builderMetadata.streams).length > 0);
    const prevHasStreams = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(hasStreams);
    const updateNodeInternals = (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_6__.useUpdateNodeInternals)();
    if (hasStreams !== prevHasStreams.current) {
        prevHasStreams.current = hasStreams;
        updateNodeInternals(props.id);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_4__["default"], {
        ...props,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_5__.NodeIcon, {}),
        label: label || 'Select Builder',
        caption: props.data.op.builder,
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_2__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_7__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_2__.HandleType.Data
                }, "data-target"),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_2__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_7__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_2__.HandleType.Data
                }, "data-source"),
                hasStreams && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_2__.Handle, {
                    id: _handles__WEBPACK_IMPORTED_MODULE_2__.HandleId.DataStream,
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_7__.Position.Right,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_2__.HandleType.DataStream
                }, "stream-source")
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NodeNodeComp);


}),
689: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(437);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(332);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);




function ScopeNodeComp(param) {
    let { isConnectable, sourcePosition = _xyflow_react__WEBPACK_IMPORTED_MODULE_2__.Position.Bottom, targetPosition = _xyflow_react__WEBPACK_IMPORTED_MODULE_2__.Position.Top, width, height } = param;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"])();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                type: "target",
                position: targetPosition,
                isConnectable: isConnectable,
                variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
                sx: {
                    opacity: 0.2,
                    backgroundColor: theme.palette.secondary.main,
                    borderRadius: 4,
                    width,
                    height,
                    cursor: 'pointer'
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                type: "source",
                position: sourcePosition,
                isConnectable: isConnectable,
                variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                id: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleId.DataStream,
                type: "source",
                position: _xyflow_react__WEBPACK_IMPORTED_MODULE_2__.Position.Right,
                variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.DataStream
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ScopeNodeComp);


}),
690: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(27);
/* ESM import */var _diagram_properties_provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(691);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(682);






function ScriptNodeComp(props) {
    const [diagramProperties] = (0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_1__.useDiagramProperties)();
    const isHighlighted = props.data.op.environment === diagramProperties.highlightedEnvironment;
    const label = props.data.op.display_text || props.data.op.run || 'Script';
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_3__["default"], {
        ...props,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_4__.ScriptIcon, {}),
        label: label,
        caption: props.data.op.environment,
        highlight: isHighlighted,
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_2__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_5__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_2__.HandleType.Data
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_2__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_5__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_2__.HandleType.Data
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_2__.Handle, {
                    id: _handles__WEBPACK_IMPORTED_MODULE_2__.HandleId.DataStream,
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_5__.Position.Right,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_2__.HandleType.DataStream
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ScriptNodeComp);


}),
692: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  SectionBufferNodeComp: () => (SectionBufferNodeComp),
  SectionInputNodeComp: () => (SectionInputNodeComp),
  SectionNodeComp: () => (SectionNodeComp),
  SectionOutputNodeComp: () => (SectionOutputNodeComp),
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(321);
/* ESM import */var _utils_operation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(672);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(682);







function SectionNodeComp(props) {
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_2__.useRegistry)();
    const label = (()=>{
        if (props.data.op.display_text) {
            return props.data.op.display_text;
        }
        if ((0,_utils_operation__WEBPACK_IMPORTED_MODULE_3__.isSectionBuilder)(props.data.op)) {
            const builderMetadata = registry.sections[props.data.op.builder];
            if (builderMetadata) {
                return builderMetadata.default_display_text;
            }
        } else {
            if (props.data.op.template) {
                return 'Template';
            }
        }
        return 'Select Section';
    })();
    const caption = (0,_utils_operation__WEBPACK_IMPORTED_MODULE_3__.isSectionBuilder)(props.data.op) ? props.data.op.builder : props.data.op.template;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_4__["default"], {
        ...props,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_5__.SectionIcon, {}),
        label: label,
        caption: caption,
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_6__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.DataBuffer
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_6__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.DataBuffer
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionNodeComp);
function SectionInputNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_4__["default"], {
        ...props,
        color: "secondary",
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_5__.SectionInputIcon, {}),
        label: "Section Input",
        caption: props.data.remappedId,
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
            type: "source",
            position: _xyflow_react__WEBPACK_IMPORTED_MODULE_6__.Position.Bottom,
            isConnectable: props.isConnectable,
            variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
        })
    });
}
function SectionOutputNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_4__["default"], {
        ...props,
        color: "secondary",
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_5__.SectionOutputIcon, {}),
        label: "Section Output",
        caption: props.data.outputId,
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
            type: "target",
            position: _xyflow_react__WEBPACK_IMPORTED_MODULE_6__.Position.Top,
            isConnectable: props.isConnectable,
            variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
        })
    });
}
function SectionBufferNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_4__["default"], {
        ...props,
        color: "secondary",
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_5__.SectionBufferIcon, {}),
        label: "Section Buffer",
        caption: props.data.remappedId,
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
            type: "source",
            position: _xyflow_react__WEBPACK_IMPORTED_MODULE_6__.Position.Bottom,
            isConnectable: props.isConnectable,
            variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Buffer
        })
    });
}


}),
693: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(682);





function SplitNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...props,
        compact: true,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_3__.SplitIcon, {}),
        label: "Split",
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SplitNodeComp);


}),
694: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(522);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(678);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _utils_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(677);





function StartNodeComp(param) {
    let { isConnectable, sourcePosition = _xyflow_react__WEBPACK_IMPORTED_MODULE_3__.Position.Bottom } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
        sx: {
            minWidth: 100
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
                fullWidth: true,
                variant: "outlined",
                disabled: true,
                sx: {
                    width: _utils_layout__WEBPACK_IMPORTED_MODULE_2__.LAYOUT_OPTIONS.nodeWidth,
                    height: _utils_layout__WEBPACK_IMPORTED_MODULE_2__.LAYOUT_OPTIONS.nodeHeight
                },
                children: "Start"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                type: "source",
                position: sourcePosition,
                isConnectable: isConnectable,
                variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StartNodeComp);


}),
695: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(682);





function StreamOutNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...props,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_3__.StreamOutIcon, {}),
        label: "StreamOut",
        caption: props.data.op.name,
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
            id: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleId.DataStream,
            type: "target",
            position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Top,
            isConnectable: props.isConnectable,
            variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.DataStream
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StreamOutNodeComp);


}),
696: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(522);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(678);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _utils_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(677);





function TerminateNodeComp(param) {
    let { isConnectable, targetPosition = _xyflow_react__WEBPACK_IMPORTED_MODULE_3__.Position.Top } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                type: "target",
                position: targetPosition,
                isConnectable: isConnectable,
                variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
                fullWidth: true,
                variant: "outlined",
                disabled: true,
                sx: {
                    width: _utils_layout__WEBPACK_IMPORTED_MODULE_2__.LAYOUT_OPTIONS.nodeWidth,
                    height: _utils_layout__WEBPACK_IMPORTED_MODULE_2__.LAYOUT_OPTIONS.nodeHeight
                },
                children: "Terminate"
            })
        ]
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TerminateNodeComp);


}),
697: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(682);





function TransformNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...props,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_3__.TransformIcon, {}),
        label: "Transform",
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransformNodeComp);


}),
698: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _base_node__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* ESM import */var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(682);





function UnzipNodeComp(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_base_node__WEBPACK_IMPORTED_MODULE_2__["default"], {
        ...props,
        compact: true,
        icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_icons__WEBPACK_IMPORTED_MODULE_3__.UnzipIcon, {}),
        label: "Unzip",
        handles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "target",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Top,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_handles__WEBPACK_IMPORTED_MODULE_1__.Handle, {
                    type: "source",
                    position: _xyflow_react__WEBPACK_IMPORTED_MODULE_4__.Position.Bottom,
                    isConnectable: props.isConnectable,
                    variant: _handles__WEBPACK_IMPORTED_MODULE_1__.HandleType.Data
                })
            ]
        })
    });
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UnzipNodeComp);


}),
700: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  isBuiltinNode: () => (isBuiltinNode),
  isOperationData: () => (isOperationData),
  isOperationNode: () => (isOperationNode),
  isScopeNode: () => (isScopeNode),
  isSectionBufferNode: () => (isSectionBufferNode),
  isSectionInputNode: () => (isSectionInputNode),
  isSectionInterfaceNode: () => (isSectionInterfaceNode),
  isSectionNode: () => (isSectionNode),
  isSectionOutputNode: () => (isSectionOutputNode)
});
function isOperationData(data) {
    return 'type' in data;
}
const OPERATION_NODE_TYPES = Object.keys({
    buffer: null,
    buffer_access: null,
    fork_clone: null,
    fork_result: null,
    join: null,
    listen: null,
    node: null,
    scope: null,
    script: null,
    section: null,
    split: null,
    stream_out: null,
    transform: null,
    unzip: null
});
function isOperationNode(node) {
    return OPERATION_NODE_TYPES.includes(node.type);
}
const BUILTIN_NODE_TYPES = Object.keys({
    start: null,
    terminate: null
});
function isBuiltinNode(node) {
    return BUILTIN_NODE_TYPES.includes(node.type);
}
function isScopeNode(node) {
    return node.type === 'scope';
}
function isSectionInterfaceNode(node) {
    return node.type === 'sectionInput' || node.type === 'sectionOutput' || node.type === 'sectionBuffer';
}
function isSectionNode(node) {
    return node.type === 'section';
}
function isSectionInputNode(node) {
    return node.type === 'sectionInput';
}
function isSectionOutputNode(node) {
    return node.type === 'sectionOutput';
}
function isSectionBufferNode(node) {
    return node.type === 'sectionBuffer';
}


}),
794: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  NotificationProvider: () => (NotificationProvider),
  useNotification: () => (useNotification)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(795);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _diagram_properties_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(691);




const NotificationContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
function NotificationProvider(param) {
    let { children } = param;
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        active: [],
        queue: []
    });
    const [diagramProperties, setDiagramProperties] = (0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_2__.useDiagramProperties)();
    const showNotification = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function(message) {
        let severity = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'info', autoHide = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : true;
        const id = Math.random().toString(36).substring(2, 9);
        setState((prev)=>{
            const newQueue = [
                ...prev.queue,
                {
                    id,
                    message,
                    severity,
                    autoHide
                }
            ];
            if (prev.active.length < 5) {
                const numToAdd = 5 - prev.active.length;
                const itemsToAdd = newQueue.slice(0, numToAdd);
                return {
                    active: [
                        ...prev.active,
                        ...itemsToAdd
                    ],
                    queue: newQueue.slice(numToAdd)
                };
            }
            return {
                ...prev,
                queue: newQueue
            };
        });
    }, []);
    const dismissNotification = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((id)=>{
        setState((prev)=>{
            const newActive = prev.active.filter((n)=>n.id !== id);
            if (prev.queue.length > 0 && newActive.length < 5) {
                const numToAdd = 5 - newActive.length;
                const itemsToAdd = prev.queue.slice(0, numToAdd);
                return {
                    active: [
                        ...newActive,
                        ...itemsToAdd
                    ],
                    queue: prev.queue.slice(numToAdd)
                };
            }
            return {
                ...prev,
                active: newActive
            };
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(NotificationContext.Provider, {
        value: showNotification,
        children: [
            children,
            (state.active.length > 0 || !!diagramProperties.highlightedEnvironment) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__["default"], {
                spacing: 1,
                sx: {
                    position: 'fixed',
                    bottom: 24,
                    left: '50%',
                    transform: 'translateX(-50%)',
                    zIndex: 3000,
                    width: 'auto',
                    maxWidth: '80vw',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center'
                },
                children: [
                    diagramProperties.highlightedEnvironment && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
                        onClose: ()=>setDiagramProperties((prev)=>({
                                    ...prev,
                                    highlightedEnvironment: undefined
                                })),
                        severity: "info",
                        sx: {
                            width: '100%',
                            boxShadow: 3
                        },
                        children: `Highlighting nodes for environment: ${diagramProperties.highlightedEnvironment}`
                    }),
                    state.active.map((notification)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(NotificationItem, {
                            notification: notification,
                            onDismiss: dismissNotification
                        }, notification.id))
                ]
            })
        ]
    });
}
function NotificationItem(param) {
    let { notification, onDismiss } = param;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (notification.autoHide !== false) {
            const timer = setTimeout(()=>{
                onDismiss(notification.id);
            }, 5000);
            return ()=>clearTimeout(timer);
        }
    }, [
        notification.id,
        notification.autoHide,
        onDismiss
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"], {
        onClose: ()=>onDismiss(notification.id),
        severity: notification.severity,
        sx: {
            width: '100%',
            boxShadow: 3
        },
        children: notification.message
    });
}
const useNotification = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(NotificationContext);
    if (!context) {
        throw new Error('useNotification must be used within a NotificationProvider');
    }
    return context;
};


}),
850: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  loadState: () => (loadState),
  saveState: () => (saveState)
});
const EXTENSION_KEY = 'crossflow-diagram-editor-v1';
async function hashDiagram(diagram) {
    // do not hash the extensions
    const { extensions: _, ...strippedExt } = diagram;
    const payload = JSON.stringify(strippedExt);
    const textEncoder = new TextEncoder();
    const data = textEncoder.encode(payload);
    const hashBuffer = await crypto.subtle.digest('SHA-1', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map((b)=>b.toString(16).padStart(2, '0')).join('');
    return hashHex;
}
/**
 * Save the render state into the diagram using the diagram's "extensions" field.
 */ async function saveState(diagram, state) {
    if (!diagram.extensions) {
        diagram.extensions = {};
    }
    diagram.extensions[EXTENSION_KEY] = {
        hash: await hashDiagram(diagram),
        state
    };
}
/**
 * Attempt to load a render state from a diagram's "extensions" field.
 * Returns `null` if no state is saved or if the saved state is stale.
 */ async function loadState(diagram) {
    var _diagram_extensions;
    const extData = (_diagram_extensions = diagram.extensions) === null || _diagram_extensions === void 0 ? void 0 : _diagram_extensions[EXTENSION_KEY];
    if (!extData) {
        return null;
    }
    const hash = await hashDiagram(diagram);
    if (hash !== extData.hash) {
        return null;
    }
    return extData.state;
}


}),
321: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  RegistryProvider: () => (RegistryProvider),
  useRegistry: () => (useRegistry)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(332);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(456);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(322);
/* ESM import */var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(331);
/* ESM import */var _api_client_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(151);






const RegistryContextComp = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
const RegistryProvider = (param)=>{
    let { children } = param;
    const [registry, setRegistry] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [showLoading, setShowLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const apiClient = (0,_api_client_provider__WEBPACK_IMPORTED_MODULE_2__.useApiClient)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const registry$ = apiClient.getRegistry();
        const timer$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.timer)(1000);
        const timerSubscription = timer$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.takeUntil)(registry$)).subscribe(()=>{
            setShowLoading(true);
        });
        const fetchSubscription = registry$.subscribe({
            next: setRegistry,
            error: (err)=>{
                console.error(err);
                setError(err);
            }
        });
        return ()=>{
            timerSubscription.unsubscribe();
            fetchSubscription.unsubscribe();
        };
    }, [
        apiClient
    ]);
    if (error) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
            sx: {
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                height: '100vh'
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_6__["default"], {
                children: "Failed to fetch registry"
            })
        });
    }
    if (!registry) {
        if (showLoading) {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
                sx: {
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: '100vh'
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_7__["default"], {})
            });
        }
        return null;
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(RegistryContextComp.Provider, {
        value: registry,
        children: children
    });
};
const useRegistry = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(RegistryContextComp);
    if (!context) {
        throw new Error('useRegistry must be used within a RegistryProvider');
    }
    return context;
};


}),
1187: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ResponsiveEditPopover: () => (ResponsiveEditPopover)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(437);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(487);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _diagram_side_panel_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(815);
/* ESM import */var _use_responsive_edit_popover_position__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(814);





function ResponsiveEditPopover(param) {
    let { anchorPosition, ...props } = param;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__["default"])();
    const responsiveAnchorPosition = (0,_use_responsive_edit_popover_position__WEBPACK_IMPORTED_MODULE_3__.useResponsiveEditPopoverPosition)(anchorPosition ?? undefined);
    const positionTransition = theme.transitions.create('left', {
        easing: theme.transitions.easing.easeInOut,
        duration: theme.transitions.duration.standard
    });
    const preservePositionTransition = (node)=>{
        if (!node.style.transition.includes('left')) {
            node.style.transition = [
                positionTransition,
                node.style.transition
            ].filter(Boolean).join(',');
        }
    };
    // A popover only fits itself to the viewport as it opens, so content that
    // grows afterwards - expanding a section, switching on an optional field -
    // runs off the bottom of the screen. Re-run the fit whenever it resizes.
    const actions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [paper, setPaper] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!paper) {
            return;
        }
        const observer = new ResizeObserver(()=>{
            var _actions_current;
            return (_actions_current = actions.current) === null || _actions_current === void 0 ? void 0 : _actions_current.updatePosition();
        });
        observer.observe(paper);
        return ()=>observer.disconnect();
    }, [
        paper
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_5__["default"], {
        ...props,
        action: actions,
        disableEnforceFocus: true,
        anchorPosition: responsiveAnchorPosition,
        anchorOrigin: {
            vertical: 'bottom',
            horizontal: 'left'
        },
        slotProps: {
            transition: {
                onEnter: preservePositionTransition,
                onExit: preservePositionTransition
            },
            paper: {
                ref: setPaper,
                style: {
                    width: `min(${_diagram_side_panel_layout__WEBPACK_IMPORTED_MODULE_2__.EditPopoverWidth}px, calc(100vw - 32px))`
                }
            }
        }
    });
}


}),
812: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  RunPanel: () => (RunPanel)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(437);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(662);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(435);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(575);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(678);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(710);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(703);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(802);
/* ESM import */var _mui_material__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(332);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _api_client_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(151);
/* ESM import */var _diagram_properties_provider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(691);
/* ESM import */var _interaction_visualization_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(676);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(147);
/* ESM import */var _registry_provider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(321);
/* ESM import */var _templates_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(459);
/* ESM import */var _use_edges__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(813);
/* ESM import */var _utils_export_diagram__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(670);












const DefaultResponseContent = {
    raw: ''
};
const MaxExecutionTimelineEntries = 200;
function enableInteractionTraceForOps(ops) {
    for (const op of Object.values(ops)){
        op.trace = 'on';
        if (op.type === 'scope') {
            enableInteractionTraceForOps(op.ops);
        }
    }
}
function enableInteractionTrace(diagram) {
    const interactionDiagram = JSON.parse(JSON.stringify(diagram));
    interactionDiagram.default_trace = 'on';
    enableInteractionTraceForOps(interactionDiagram.ops);
    return interactionDiagram;
}
function RunPanel(param) {
    let { requestJsonString, onRequestJsonStringChange } = param;
    const nodeManager = (0,_node_manager__WEBPACK_IMPORTED_MODULE_5__.useNodeManager)();
    const edges = (0,_use_edges__WEBPACK_IMPORTED_MODULE_9__.useEdges)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_11__["default"])();
    const [responseContent, setResponseContent] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(DefaultResponseContent);
    const apiClient = (0,_api_client_provider__WEBPACK_IMPORTED_MODULE_2__.useApiClient)();
    const { clearInteractionVisualization, markInteractionFinished, markInteractionOperationFinished, markInteractionOperationStarted, setWorkflowRunning } = (0,_interaction_visualization_provider__WEBPACK_IMPORTED_MODULE_4__.useInteractionVisualization)();
    const [templates] = (0,_templates_provider__WEBPACK_IMPORTED_MODULE_8__.useTemplates)();
    const registry = (0,_registry_provider__WEBPACK_IMPORTED_MODULE_7__.useRegistry)();
    const [runningMode, setRunningMode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [showProgress, setShowProgress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const showProgressRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(showProgress);
    const [executionTimeline, setExecutionTimeline] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const interactionEventCounter = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0);
    const interactionSessionRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const interactionSubscriptionRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [diagramProperties] = (0,_diagram_properties_provider__WEBPACK_IMPORTED_MODULE_3__.useDiagramProperties)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setWorkflowRunning(runningMode !== null);
        return ()=>setWorkflowRunning(false);
    }, [
        runningMode,
        setWorkflowRunning
    ]);
    const closeInteractionSession = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        var _interactionSubscriptionRef_current, _interactionSessionRef_current;
        (_interactionSubscriptionRef_current = interactionSubscriptionRef.current) === null || _interactionSubscriptionRef_current === void 0 ? void 0 : _interactionSubscriptionRef_current.unsubscribe();
        interactionSubscriptionRef.current = null;
        (_interactionSessionRef_current = interactionSessionRef.current) === null || _interactionSessionRef_current === void 0 ? void 0 : _interactionSessionRef_current.close();
        interactionSessionRef.current = null;
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        return closeInteractionSession;
    }, [
        closeInteractionSession
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        showProgressRef.current = showProgress;
        if (!showProgress) {
            clearInteractionVisualization();
            setExecutionTimeline([]);
        }
    }, [
        clearInteractionVisualization,
        showProgress
    ]);
    const requestError = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        try {
            JSON.parse(requestJsonString);
            return false;
        } catch  {
            return true;
        }
    }, [
        requestJsonString
    ]);
    const responseError = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return 'err' in responseContent;
    }, [
        responseContent
    ]);
    const responseValue = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if ('err' in responseContent) {
            return `Error: ${responseContent.err}`;
        }
        return responseContent.raw;
    }, [
        responseContent
    ]);
    const handleRequestJsonChange = (value)=>{
        onRequestJsonStringChange(value);
    };
    const runWithPost = (diagram, request)=>{
        apiClient.postRunWorkflow(diagram, request).subscribe({
            next: (response)=>{
                setResponseContent({
                    raw: JSON.stringify(response, null, 2)
                });
                setRunningMode(null);
            },
            error: (err)=>{
                setResponseContent({
                    err: err.message
                });
                setRunningMode(null);
            }
        });
    };
    const handleRunClick = async ()=>{
        closeInteractionSession();
        clearInteractionVisualization();
        setExecutionTimeline([]);
        interactionEventCounter.current = 0;
        try {
            const request = JSON.parse(requestJsonString);
            const diagram = (0,_utils_export_diagram__WEBPACK_IMPORTED_MODULE_10__.exportDiagram)(registry, nodeManager, edges, templates, diagramProperties);
            setResponseContent(DefaultResponseContent);
            setRunningMode('run');
            if (!showProgress || !apiClient.wsInteractWithWorkflow) {
                runWithPost(diagram, request);
                return;
            }
            const interactionSession = await apiClient.wsInteractWithWorkflow(enableInteractionTrace(diagram), request);
            interactionSessionRef.current = interactionSession;
            interactionSubscriptionRef.current = interactionSession.interactionMessages$.subscribe({
                next: (msg)=>{
                    if (msg.type === 'feedback' && 'operationStarted' in msg && typeof msg.operationStarted === 'string') {
                        if (!showProgressRef.current) {
                            return;
                        }
                        const operationId = msg.operationStarted;
                        markInteractionOperationStarted(operationId);
                        const entry = {
                            seq: ++interactionEventCounter.current,
                            operationId
                        };
                        setExecutionTimeline((prev)=>[
                                ...prev,
                                entry
                            ].slice(-MaxExecutionTimelineEntries));
                        return;
                    }
                    if (msg.type === 'feedback' && 'operationFinished' in msg && typeof msg.operationFinished === 'string') {
                        if (!showProgressRef.current) {
                            return;
                        }
                        markInteractionOperationFinished(msg.operationFinished);
                        return;
                    }
                    if (msg.type === 'finish') {
                        markInteractionFinished();
                        if ('ok' in msg) {
                            setResponseContent({
                                raw: JSON.stringify(msg.ok, null, 2)
                            });
                        } else {
                            setResponseContent({
                                err: msg.err
                            });
                        }
                        setRunningMode(null);
                        closeInteractionSession();
                    }
                },
                error: (err)=>{
                    markInteractionFinished();
                    setResponseContent({
                        err: err.message
                    });
                    setRunningMode(null);
                    closeInteractionSession();
                },
                complete: ()=>{
                    setRunningMode(null);
                }
            });
        } catch (e) {
            setResponseContent({
                err: e.message
            });
            setRunningMode(null);
            closeInteractionSession();
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
        spacing: 2,
        sx: {
            minHeight: 0,
            overflowY: 'auto',
            p: 2
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                spacing: 1,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                        variant: "h6",
                        children: "Run Workflow"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                        variant: "body2",
                        color: "text.secondary",
                        children: "Request"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                        fullWidth: true,
                        multiline: true,
                        minRows: 6,
                        maxRows: 12,
                        variant: "outlined",
                        value: requestJsonString,
                        slotProps: {
                            htmlInput: {
                                sx: {
                                    fontFamily: 'monospace',
                                    whiteSpace: 'nowrap'
                                }
                            }
                        },
                        onChange: (e)=>handleRequestJsonChange(e.target.value),
                        error: requestError,
                        sx: {
                            backgroundColor: theme.palette.background.paper
                        }
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                direction: "row",
                spacing: 1,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_15__["default"], {
                        variant: "contained",
                        onClick: handleRunClick,
                        disabled: runningMode !== null,
                        loading: runningMode === 'run',
                        startIcon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                            symbol: "play_arrow"
                        }),
                        children: "Run"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_16__["default"], {
                        control: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_17__["default"], {
                            checked: showProgress,
                            onChange: (event)=>setShowProgress(event.target.checked)
                        }),
                        label: "Show progress"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_18__["default"], {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                spacing: 1,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                        direction: "row",
                        spacing: 1,
                        sx: {
                            alignItems: 'center'
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                variant: "body1",
                                children: "Response"
                            }),
                            'err' in responseContent ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                symbol: "error",
                                sx: {
                                    color: theme.palette.error.main
                                }
                            }) : 'raw' in responseContent && responseContent.raw.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_nodes__WEBPACK_IMPORTED_MODULE_6__.MaterialSymbol, {
                                symbol: "check_circle",
                                sx: {
                                    color: theme.palette.success.main
                                }
                            }) : null
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_14__["default"], {
                        fullWidth: true,
                        multiline: true,
                        minRows: 6,
                        maxRows: 12,
                        variant: "outlined",
                        value: responseValue,
                        slotProps: {
                            htmlInput: {
                                sx: {
                                    fontFamily: 'monospace',
                                    whiteSpace: 'nowrap'
                                }
                            }
                        },
                        error: responseError
                    })
                ]
            }),
            showProgress && executionTimeline.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                spacing: 1,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                        variant: "body1",
                        children: "Execution timeline"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_19__["default"], {
                        sx: {
                            border: `1px solid ${theme.palette.divider}`,
                            borderRadius: 1,
                            maxHeight: 220,
                            overflowY: 'auto',
                            px: 1,
                            py: 0.5
                        },
                        children: executionTimeline.map((entry)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                direction: "row",
                                spacing: 1,
                                sx: {
                                    alignItems: 'baseline'
                                },
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                        variant: "caption",
                                        color: "text.secondary",
                                        children: entry.seq
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mui_material__WEBPACK_IMPORTED_MODULE_13__["default"], {
                                        variant: "body2",
                                        sx: {
                                            fontFamily: 'monospace',
                                            overflow: 'hidden',
                                            textOverflow: 'ellipsis',
                                            whiteSpace: 'nowrap'
                                        },
                                        children: entry.operationId
                                    })
                                ]
                            }, entry.seq))
                    })
                ]
            })
        ]
    });
}


}),
459: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  TemplatesProvider: () => (TemplatesProvider),
  useTemplates: () => (useTemplates)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const TemplatesContextComp = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
function TemplatesProvider(param) {
    let { children } = param;
    const [templates, setTemplates] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TemplatesContextComp.Provider, {
        value: [
            templates,
            setTemplates
        ],
        children: children
    });
}
function useTemplates() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(TemplatesContextComp);
    if (!context) {
        throw new Error('useTemplates must be used within a TemplatesProvider');
    }
    return context;
}


}),
845: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  TransientEditorDraftProvider: () => (TransientEditorDraftProvider),
  useTransientEditorDrafts: () => (useTransientEditorDrafts)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _draft_workspace__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(846);



const TransientEditorDraftContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
function TransientEditorDraftProvider(param) {
    let { children } = param;
    const [drafts, setDrafts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_draft_workspace__WEBPACK_IMPORTED_MODULE_2__.EMPTY_TRANSIENT_EDITOR_DRAFTS);
    const replaceDrafts = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((nextDrafts)=>setDrafts(nextDrafts), []);
    const setScriptEnvironmentDraft = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((draft)=>setDrafts((prev)=>({
                ...prev,
                scriptEnvironment: draft
            })), []);
    const setOperationConfigDraft = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((key, value)=>setDrafts((prev)=>{
            const operationConfigs = {
                ...prev.operationConfigs
            };
            if (value === undefined) {
                delete operationConfigs[key];
            } else {
                operationConfigs[key] = value;
            }
            return {
                ...prev,
                operationConfigs
            };
        }), []);
    const clearOperationConfigDrafts = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((keys)=>setDrafts((prev)=>{
            const operationConfigs = {
                ...prev.operationConfigs
            };
            let changed = false;
            for (const key of keys){
                const nodeKey = `node:${key}:config`;
                const scriptKey = `script:${key}:config`;
                if (nodeKey in operationConfigs) {
                    delete operationConfigs[nodeKey];
                    changed = true;
                }
                if (scriptKey in operationConfigs) {
                    delete operationConfigs[scriptKey];
                    changed = true;
                }
            }
            return changed ? {
                ...prev,
                operationConfigs
            } : prev;
        }), []);
    const setTemplateRenameDraft = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((draft)=>setDrafts((prev)=>({
                ...prev,
                templateRename: draft
            })), []);
    const clearDrafts = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>setDrafts(_draft_workspace__WEBPACK_IMPORTED_MODULE_2__.EMPTY_TRANSIENT_EDITOR_DRAFTS), []);
    const value = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>({
            drafts,
            replaceDrafts,
            setScriptEnvironmentDraft,
            setOperationConfigDraft,
            clearOperationConfigDrafts,
            setTemplateRenameDraft,
            clearDrafts,
            hasUncommittedBuffers: drafts.scriptEnvironment !== undefined || drafts.templateRename !== undefined || Object.keys(drafts.operationConfigs).length > 0
        }), [
        clearDrafts,
        clearOperationConfigDrafts,
        drafts,
        replaceDrafts,
        setOperationConfigDraft,
        setScriptEnvironmentDraft,
        setTemplateRenameDraft
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(TransientEditorDraftContext.Provider, {
        value: value,
        children: children
    });
}
function useTransientEditorDrafts() {
    const value = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(TransientEditorDraftContext);
    if (!value) {
        throw new Error('useTransientEditorDrafts must be used within TransientEditorDraftProvider');
    }
    return value;
}


}),
1188: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  useBeforeUnloadWarning: () => (useBeforeUnloadWarning)
});
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useBeforeUnloadWarning(enabled) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (!enabled) {
            return;
        }
        const warnBeforeUnload = (event)=>{
            event.preventDefault();
            event.returnValue = '';
        };
        window.addEventListener('beforeunload', warnBeforeUnload);
        return ()=>window.removeEventListener('beforeunload', warnBeforeUnload);
    }, [
        enabled
    ]);
}


}),
1189: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  useDraftPagehideFlush: () => (useDraftPagehideFlush)
});
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* ESM import */var _draft_workspace__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(846);


function useDraftPagehideFlush(latestWorkspace, shouldFlush, setStorageFailed) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const flushWorkspace = ()=>{
            if (!shouldFlush || !latestWorkspace.current) {
                return;
            }
            try {
                (0,_draft_workspace__WEBPACK_IMPORTED_MODULE_1__.writeDraftWorkspace)(latestWorkspace.current);
                setStorageFailed(false);
            } catch  {
                setStorageFailed(true);
            }
        };
        window.addEventListener('pagehide', flushWorkspace);
        return ()=>window.removeEventListener('pagehide', flushWorkspace);
    }, [
        latestWorkspace,
        setStorageFailed,
        shouldFlush
    ]);
}


}),
813: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  EdgesProvider: () => (EdgesProvider),
  useEdges: () => (useEdges)
});
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const EdgesContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)([]);
const EdgesProvider = EdgesContext.Provider;
function useEdges() {
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(EdgesContext);
}


}),
814: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  useDiagramSidePanelWidth: () => (useDiagramSidePanelWidth),
  useResponsiveEditPopoverPosition: () => (useResponsiveEditPopoverPosition)
});
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* ESM import */var _diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(769);
/* ESM import */var _diagram_side_panel_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(815);



function useViewportWidth() {
    const [viewportWidth, setViewportWidth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(()=>typeof window === 'undefined' ? 0 : window.innerWidth);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const updateViewportWidth = ()=>setViewportWidth(window.innerWidth);
        window.addEventListener('resize', updateViewportWidth);
        return ()=>window.removeEventListener('resize', updateViewportWidth);
    }, []);
    return viewportWidth;
}
function useDiagramSidePanelWidth() {
    const { state: { open, expanded } } = (0,_diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_1__.useDiagramSidePanel)();
    const viewportWidth = useViewportWidth();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>(0,_diagram_side_panel_layout__WEBPACK_IMPORTED_MODULE_2__.getDiagramSidePanelWidth)(viewportWidth, {
            open,
            expanded
        }), [
        expanded,
        open,
        viewportWidth
    ]);
}
function useResponsiveEditPopoverPosition(anchorPosition) {
    const { state: { open, expanded } } = (0,_diagram_side_panel_controller__WEBPACK_IMPORTED_MODULE_1__.useDiagramSidePanel)();
    const viewportWidth = useViewportWidth();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>anchorPosition ? (0,_diagram_side_panel_layout__WEBPACK_IMPORTED_MODULE_2__.constrainEditPopoverPosition)({
            anchorPosition,
            viewportWidth,
            sidePanel: {
                open,
                expanded
            }
        }) : undefined, [
        anchorPosition,
        expanded,
        open,
        viewportWidth
    ]);
}


}),
701: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ADD_OPERATION_DEFINITIONS: () => (ADD_OPERATION_DEFINITIONS),
  filterCompatibleAddOperations: () => (filterCompatibleAddOperations),
  getAddOperationCandidates: () => (getAddOperationCandidates),
  getRegistryNodeBuilderCandidates: () => (getRegistryNodeBuilderCandidates),
  getVisibleAddOperations: () => (getVisibleAddOperations)
});
/* ESM import */var uuid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(311);
/* ESM import */var _forms_schema_config_form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(702);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);
/* ESM import */var _connection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(298);
/* ESM import */var _namespace__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(671);
/* ESM import */var _unique_value__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(712);






function createSectionInputChange(remappedId, targetId, position) {
    return {
        type: 'add',
        item: (0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createSectionInputNode)(remappedId, targetId, position)
    };
}
function createSectionOutputChange(outputId, position) {
    return {
        type: 'add',
        item: (0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createSectionOutputNode)(outputId, position)
    };
}
function createSectionBufferChange(remappedId, targetId, position) {
    return {
        type: 'add',
        item: (0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createSectionBufferNode)(remappedId, targetId, position)
    };
}
function createNodeChange(namespace, parentId, newNodePosition, op) {
    if (op.type === 'scope') {
        return (0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createScopeNode)(namespace, parentId, newNodePosition, op, (0,uuid__WEBPACK_IMPORTED_MODULE_5__["default"])()).map((node)=>({
                type: 'add',
                item: node
            }));
    }
    return [
        {
            type: 'add',
            item: (0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, newNodePosition, op, (0,uuid__WEBPACK_IMPORTED_MODULE_5__["default"])())
        }
    ];
}
const ADD_OPERATION_DEFINITIONS = [
    {
        key: 'sectionInput',
        label: 'Section Input',
        templateOnlyRoot: true,
        createPreviewNode: ()=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createSectionInputNode)('preview_input', {
                builtin: 'dispose'
            }, {
                x: 0,
                y: 0
            }),
        createChanges: (param)=>{
            let { newNodePosition, nodeManager } = param;
            const remappedId = (0,_unique_value__WEBPACK_IMPORTED_MODULE_4__.addUniqueSuffix)('new_input', nodeManager.nodes.filter(_nodes__WEBPACK_IMPORTED_MODULE_1__.isSectionInputNode).map((n)=>n.data.remappedId));
            return [
                createSectionInputChange(remappedId, {
                    builtin: 'dispose'
                }, newNodePosition)
            ];
        }
    },
    {
        key: 'sectionOutput',
        label: 'Section Output',
        templateOnlyRoot: true,
        createPreviewNode: ()=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createSectionOutputNode)('preview_output', {
                x: 0,
                y: 0
            }),
        createChanges: (param)=>{
            let { newNodePosition, nodeManager } = param;
            const outputId = (0,_unique_value__WEBPACK_IMPORTED_MODULE_4__.addUniqueSuffix)('new_output', nodeManager.nodes.filter(_nodes__WEBPACK_IMPORTED_MODULE_1__.isSectionOutputNode).map((n)=>n.data.outputId));
            return [
                createSectionOutputChange(outputId, newNodePosition)
            ];
        }
    },
    {
        key: 'sectionBuffer',
        label: 'Section Buffer',
        templateOnlyRoot: true,
        createPreviewNode: ()=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createSectionBufferNode)('preview_buffer', {
                builtin: 'dispose'
            }, {
                x: 0,
                y: 0
            }),
        createChanges: (param)=>{
            let { newNodePosition, nodeManager } = param;
            const remappedId = (0,_unique_value__WEBPACK_IMPORTED_MODULE_4__.addUniqueSuffix)('new_buffer', nodeManager.nodes.filter(_nodes__WEBPACK_IMPORTED_MODULE_1__.isSectionBufferNode).map((n)=>n.data.remappedId));
            return [
                createSectionBufferChange(remappedId, {
                    builtin: 'dispose'
                }, newNodePosition)
            ];
        }
    },
    {
        key: 'node',
        label: 'Node',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'node',
                builder: '',
                next: {
                    builtin: 'dispose'
                }
            }, 'preview_node'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'node',
                builder: '',
                next: {
                    builtin: 'dispose'
                }
            });
        }
    },
    {
        key: 'fork_clone',
        label: 'Fork Clone',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'fork_clone',
                next: []
            }, 'preview_fork_clone'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'fork_clone',
                next: []
            });
        }
    },
    {
        key: 'unzip',
        label: 'Unzip',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'unzip',
                next: []
            }, 'preview_unzip'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'unzip',
                next: []
            });
        }
    },
    {
        key: 'fork_result',
        label: 'Fork Result',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'fork_result',
                err: {
                    builtin: 'dispose'
                },
                ok: {
                    builtin: 'dispose'
                }
            }, 'preview_fork_result'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'fork_result',
                err: {
                    builtin: 'dispose'
                },
                ok: {
                    builtin: 'dispose'
                }
            });
        }
    },
    {
        key: 'split',
        label: 'Split',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'split'
            }, 'preview_split'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'split'
            });
        }
    },
    {
        key: 'join',
        label: 'Join',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'join',
                buffers: [],
                next: {
                    builtin: 'dispose'
                }
            }, 'preview_join'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'join',
                buffers: [],
                next: {
                    builtin: 'dispose'
                }
            });
        }
    },
    {
        key: 'transform',
        label: 'Transform',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'transform',
                cel: '',
                next: {
                    builtin: 'dispose'
                }
            }, 'preview_transform'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'transform',
                cel: '',
                next: {
                    builtin: 'dispose'
                }
            });
        }
    },
    {
        key: 'buffer',
        label: 'Buffer',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'buffer'
            }, 'preview_buffer_node'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'buffer'
            });
        }
    },
    {
        key: 'buffer_access',
        label: 'Buffer Access',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'buffer_access',
                buffers: [],
                next: {
                    builtin: 'dispose'
                }
            }, 'preview_buffer_access'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'buffer_access',
                buffers: [],
                next: {
                    builtin: 'dispose'
                }
            });
        }
    },
    {
        key: 'listen',
        label: 'Listen',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'listen',
                buffers: [],
                next: {
                    builtin: 'dispose'
                }
            }, 'preview_listen'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'listen',
                buffers: [],
                next: {
                    builtin: 'dispose'
                }
            });
        }
    },
    {
        key: 'stream_out',
        label: 'Stream Out',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'stream_out',
                name: ''
            }, 'preview_stream_out'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'stream_out',
                name: ''
            });
        }
    },
    {
        key: 'scope',
        label: 'Scope',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createScopeNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'scope',
                start: {
                    builtin: 'dispose'
                },
                ops: {},
                next: {
                    builtin: 'dispose'
                }
            }, 'preview_scope')[0],
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'scope',
                start: {
                    builtin: 'dispose'
                },
                ops: {},
                next: {
                    builtin: 'dispose'
                }
            });
        }
    },
    {
        key: 'section',
        label: 'Section',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'section',
                template: ''
            }, 'preview_section'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'section',
                template: ''
            });
        }
    },
    {
        key: 'script',
        label: 'Script',
        createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, {
                type: 'script',
                environment: '',
                run: '',
                next: {
                    builtin: 'dispose'
                }
            }, 'preview_script'),
        createChanges: (param)=>{
            let { namespace, parentId, newNodePosition } = param;
            return createNodeChange(namespace, parentId, newNodePosition, {
                type: 'script',
                environment: '',
                run: '',
                next: {
                    builtin: 'dispose'
                }
            });
        }
    }
];
function getVisibleAddOperations(options) {
    return ADD_OPERATION_DEFINITIONS.filter((definition)=>{
        if (!definition.templateOnlyRoot) {
            return true;
        }
        return options.isTemplateMode && options.namespace === _namespace__WEBPACK_IMPORTED_MODULE_3__.ROOT_NAMESPACE;
    });
}
function filterCompatibleAddOperations(definitions, anchorNode, anchorHandle, options) {
    let anchorHandleType = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 'source';
    return definitions.filter((definition)=>{
        const previewNode = definition.createPreviewNode(options.namespace, options.parentId);
        if (anchorHandleType === 'target' && previewNode.type === 'fork_result') {
            return false;
        }
        return anchorHandleType === 'source' ? (0,_connection__WEBPACK_IMPORTED_MODULE_2__.getValidEdgeTypes)(anchorNode, anchorHandle, previewNode, null).length > 0 : (0,_connection__WEBPACK_IMPORTED_MODULE_2__.getValidEdgeTypes)(previewNode, null, anchorNode, anchorHandle).length > 0;
    });
}
function getRegistryNodeBuilderCandidates(registry) {
    return Object.entries(registry.nodes).sort((param, param1)=>{
        let [left] = param, [right] = param1;
        return left.localeCompare(right);
    }).map((param)=>{
        let [builder, metadata] = param;
        return {
            key: `node:${builder}`,
            label: metadata.default_display_text || builder,
            createPreviewNode: (namespace, parentId)=>(0,_nodes__WEBPACK_IMPORTED_MODULE_1__.createOperationNode)(namespace, parentId, {
                    x: 0,
                    y: 0
                }, {
                    type: 'node',
                    builder,
                    next: {
                        builtin: 'dispose'
                    }
                }, `preview_node_${builder}`),
            createChanges: (param)=>{
                let { namespace, parentId, newNodePosition } = param;
                const config = (0,_forms_schema_config_form__WEBPACK_IMPORTED_MODULE_0__.getSchemaConfigDefaults)(metadata.config_schema, registry.schemas);
                return createNodeChange(namespace, parentId, newNodePosition, {
                    type: 'node',
                    builder,
                    ...config !== undefined && {
                        config
                    },
                    next: {
                        builtin: 'dispose'
                    }
                });
            }
        };
    });
}
function getAddOperationCandidates(registry) {
    let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    const { includeGenericNode = true, includeRegistryNodes = false, includeBuiltins = true, builtins = ADD_OPERATION_DEFINITIONS } = options;
    const candidates = [];
    if (includeBuiltins) {
        candidates.push(...builtins.filter((definition)=>includeGenericNode || definition.key !== 'node'));
    }
    if (includeRegistryNodes) {
        candidates.push(...getRegistryNodeBuilderCandidates(registry));
    }
    return candidates;
}


}),
155: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__),
  getSchema: () => (getSchema)
});
/* ESM import */var ajv_dist_2020__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(156);
/* ESM import */var ajv_dist_2020__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ajv_dist_2020__WEBPACK_IMPORTED_MODULE_0__);
/* ESM import */var ajv_formats__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(245);
/* ESM import */var ajv_formats__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(ajv_formats__WEBPACK_IMPORTED_MODULE_1__);
/* ESM import */var _api_preprocessed_schema_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(251);



const ajv = ajv_formats__WEBPACK_IMPORTED_MODULE_1___default()(new (ajv_dist_2020__WEBPACK_IMPORTED_MODULE_0___default())({
    allowUnionTypes: true
})).addFormat('uint', /^[0-9]+$/);
ajv.compile(_api_preprocessed_schema_json__WEBPACK_IMPORTED_MODULE_2__);
function getSchema(key) {
    const validate = ajv.getSchema(`#/$defs/${key}`);
    if (!validate) {
        throw new Error(`cannot validate ${key}`);
    }
    return validate;
}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ajv);


}),
718: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  autoLayout: () => (autoLayout)
});
/* ESM import */var _dagrejs_dagre__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(719);
/* ESM import */var _dagrejs_dagre__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_dagrejs_dagre__WEBPACK_IMPORTED_MODULE_0__);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(147);
/* ESM import */var _layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(677);
/* ESM import */var _namespace__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(671);





function isScopeNode(node) {
    return node.type === 'scope';
}
function autoLayout(nodes, edges, options) {
    const nodeManager = new _node_manager__WEBPACK_IMPORTED_MODULE_1__.NodeManager(nodes);
    const dagreGraph = new _dagrejs_dagre__WEBPACK_IMPORTED_MODULE_0__.graphlib.Graph().setDefaultEdgeLabel(()=>({}));
    dagreGraph.setGraph({
        rankdir: 'TB',
        ranksep: options.nodeHeight
    });
    const scopeChildrens = {};
    for (const node of nodes){
        const parentNode = node.parentId ? nodeManager.tryGetNode(node.parentId) : null;
        if (parentNode === null || parentNode === void 0 ? void 0 : parentNode.id) {
            if (!scopeChildrens[parentNode.id]) {
                scopeChildrens[parentNode.id] = [];
            }
            scopeChildrens[parentNode.id].push(node);
        }
        // exclude scope node from auto layout
        if (!isScopeNode(node)) {
            dagreGraph.setNode(node.id, {
                // dagre requires the node dimensions to be known, the easy solution is to only use
                // fixed size nodes. The complex alternative is to delay auto layout until ReactFlow
                // finishes measuring the nodes, this is complex because
                //   1. There is no hook for when ReactFlow finishes measurements
                //   2. ReactFlow does not delay updating the DOM until the measurements are complete.
                //     2.1. This means that when loading a new diagram, there will be a short period where the layout is not yet computed.
                //   3. Measurements of a node may change multiple times before it "stabilizes".
                //     3.1. This means that even if all nodes have measurements, they may not be final measurements.
                //          If the measurements change after the layout is computed, the layout will be wrong.
                width: options.nodeWidth,
                height: options.nodeHeight
            });
        }
    }
    /**
   * In some cases, we may want to ensure that the outputs are positioned in order to prevent
   * the edges from "crossing" each other. dagre does not support this directly, but we can work
   * around by pushing edges to the back so that dagre process it later.
   */ const prioritizedEdges = [
        [],
        []
    ];
    for (const edge of edges){
        switch(edge.type){
            case 'streamOut':
            case 'forkResultErr':
                {
                    prioritizedEdges[1].push(edge);
                    break;
                }
            default:
                {
                    prioritizedEdges[0].push(edge);
                }
        }
    }
    for (const edge of prioritizedEdges.flat()){
        const sourceNode = nodeManager.getNode(edge.source);
        const targetNode = nodeManager.getNode(edge.target);
        if (targetNode.type === 'scope') {
            dagreGraph.setEdge(edge.source, nodeManager.getNodeFromNamespaceOpId((0,_namespace__WEBPACK_IMPORTED_MODULE_4__.joinNamespaces)(targetNode.data.namespace, targetNode.data.opId), _nodes__WEBPACK_IMPORTED_MODULE_2__.START_ID).id, {
                minlen: 2
            });
        } else if (sourceNode.type === 'scope') {
            dagreGraph.setEdge(nodeManager.getNodeFromNamespaceOpId((0,_namespace__WEBPACK_IMPORTED_MODULE_4__.joinNamespaces)(sourceNode.data.namespace, sourceNode.data.opId), _nodes__WEBPACK_IMPORTED_MODULE_2__.TERMINATE_ID).id, edge.target, {
                minlen: 2
            });
        } else {
            dagreGraph.setEdge(edge.source, edge.target);
        }
    }
    _dagrejs_dagre__WEBPACK_IMPORTED_MODULE_0__.layout(dagreGraph);
    const scopeBounds = {};
    for (const [scopeNodeId, children] of Object.entries(scopeChildrens)){
        scopeBounds[scopeNodeId] = (0,_layout__WEBPACK_IMPORTED_MODULE_3__.calculateScopeBounds)(children.map((n)=>dagreGraph.node(n.id)));
    }
    const changes = [];
    for (const node of nodes){
        const nodePosition = dagreGraph.node(node.id);
        if (isScopeNode(node)) {
            continue;
        }
        if (node.parentId) {
            const scope = scopeBounds[node.parentId];
            changes.push({
                type: 'position',
                id: node.id,
                position: {
                    x: nodePosition.x - // convert position to be relative to scope
                    scope.x,
                    y: nodePosition.y - // convert position to be relative to scope
                    scope.y
                }
            });
        } else {
            changes.push({
                type: 'position',
                id: node.id,
                position: {
                    x: nodePosition.x,
                    y: nodePosition.y
                }
            });
        }
    }
    for (const [scopeNodeId, bounds] of Object.entries(scopeBounds)){
        changes.push({
            type: 'position',
            id: scopeNodeId,
            position: {
                x: bounds.x,
                y: bounds.y
            }
        });
        changes.push({
            type: 'dimensions',
            id: scopeNodeId,
            dimensions: {
                width: bounds.width,
                height: bounds.height
            },
            setAttributes: true
        });
    }
    return changes;
}


}),
854: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  getRetentionMode: () => (getRetentionMode)
});
function getRetentionMode(retention) {
    return typeof retention === 'string' ? 'keep_all' : Object.keys(retention)[0];
}


}),
1190: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  isRemoveChange: () => (isRemoveChange)
});
function isRemoveChange(change) {
    return change.type === 'remove';
}


}),
297: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  buildCompatibilityRequest: () => (buildCompatibilityRequest),
  buildConnectionPreview: () => (buildConnectionPreview),
  checkCompatibility: () => (checkCompatibility),
  prepareConnection: () => (prepareConnection)
});
/* ESM import */var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(673);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);
/* ESM import */var _connection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(298);
/* ESM import */var _export_diagram__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(670);
/* ESM import */var _namespace__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(671);






const TEMPLATE_SECTION = '__template__';
function cloneJson(value) {
    return JSON.parse(JSON.stringify(value));
}
function namespaceList(namespace, templateSection) {
    const namespaces = (0,_namespace__WEBPACK_IMPORTED_MODULE_4__.splitNamespaces)(namespace).filter((part)=>part !== _namespace__WEBPACK_IMPORTED_MODULE_4__.ROOT_NAMESPACE);
    return templateSection ? [
        templateSection,
        ...namespaces
    ] : namespaces;
}
function namedOperation(namespaces, name, exposedNamespace) {
    return {
        named: {
            namespaces,
            exposed_namespace: exposedNamespace ?? null,
            name
        }
    };
}
function namedOutput(namespaces, operation, key) {
    return {
        Named: {
            namespaces,
            operation,
            key
        }
    };
}
function inputPort(operation) {
    return {
        Input: operation
    };
}
function outputPort(output) {
    return {
        Output: output
    };
}
function operationInputPort(node, edge, templateSection) {
    if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isBuiltinNode)(node)) {
        switch(node.type){
            case 'terminate':
                {
                    return inputPort({
                        terminate: namespaceList(node.data.namespace, templateSection)
                    });
                }
            case 'start':
                {
                    return null;
                }
        }
    }
    if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isOperationNode)(node)) {
        if (node.type === 'section' && ((edge === null || edge === void 0 ? void 0 : edge.data.input.type) === 'sectionInput' || (edge === null || edge === void 0 ? void 0 : edge.data.input.type) === 'sectionBuffer')) {
            return inputPort(namedOperation(namespaceList(node.data.namespace, templateSection), edge.data.input.inputId, node.data.opId));
        }
        return inputPort(namedOperation(namespaceList(node.data.namespace, templateSection), node.data.opId));
    }
    if (node.type === 'sectionOutput') {
        if (templateSection) {
            return outputPort(namedOutput([], templateSection, [
                'connect',
                node.data.outputId
            ]));
        }
        return inputPort(namedOperation([], node.data.outputId));
    }
    return null;
}
function forkCloneOutputIndex(edge, edges) {
    return edges.filter((candidate)=>candidate.source === edge.source).findIndex((candidate)=>candidate.id === edge.id);
}
function operationOutputKey(sourceNode, edge, edges) {
    switch(edge.type){
        case 'default':
            {
                if (sourceNode.type === 'fork_clone') {
                    return [
                        'next',
                        Math.max(0, forkCloneOutputIndex(edge, edges))
                    ];
                }
                return [
                    'next'
                ];
            }
        case 'forkResultOk':
            {
                return [
                    'ok'
                ];
            }
        case 'forkResultErr':
            {
                return [
                    'err'
                ];
            }
        case 'splitKey':
            {
                return [
                    'keyed',
                    edge.data.output.key
                ];
            }
        case 'splitSeq':
        case 'unzip':
            {
                return [
                    'next',
                    edge.data.output.seq
                ];
            }
        case 'splitRemaining':
            {
                return [
                    'remaining'
                ];
            }
        case 'streamOut':
            {
                return [
                    'stream_out',
                    edge.data.output.streamId
                ];
            }
        case 'section':
            {
                return [
                    'connect',
                    edge.data.output.output
                ];
            }
        case 'buffer':
            {
                return null;
            }
    }
}
function operationOutputPort(node, edge, edges, templateSection) {
    if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isBuiltinNode)(node)) {
        switch(node.type){
            case 'start':
                {
                    return outputPort({
                        Start: namespaceList(node.data.namespace, templateSection)
                    });
                }
            case 'terminate':
                {
                    return null;
                }
        }
    }
    if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isOperationNode)(node)) {
        if (edge.type === 'buffer') {
            return inputPort(namedOperation(namespaceList(node.data.namespace, templateSection), node.type === 'section' ? edge.data.output.bufferId ?? '' : node.data.opId, node.type === 'section' ? node.data.opId : undefined));
        }
        const key = operationOutputKey(node, edge, edges);
        if (!key) {
            return null;
        }
        return outputPort(namedOutput(namespaceList(node.data.namespace, templateSection), node.data.opId, key));
    }
    if (node.type === 'sectionInput' || node.type === 'sectionBuffer') {
        return inputPort(namedOperation([], node.data.remappedId, templateSection));
    }
    return null;
}
function portRefsForEdge(nodeManager, edge, edges, templateSection) {
    const sourceNode = nodeManager.getNode(edge.source);
    const targetNode = nodeManager.getNode(edge.target);
    if (edge.type === 'buffer') {
        const bufferPort = operationOutputPort(sourceNode, edge, edges, templateSection);
        const focusPorts = bufferPort ? [
            bufferPort
        ] : [];
        if ((0,_nodes__WEBPACK_IMPORTED_MODULE_1__.isOperationNode)(targetNode)) {
            focusPorts.push(outputPort(namedOutput(namespaceList(targetNode.data.namespace, templateSection), targetNode.data.opId, [
                'next'
            ])));
        }
        return {
            focusPorts
        };
    }
    const sourcePort = operationOutputPort(sourceNode, edge, edges, templateSection) ?? undefined;
    const targetPort = operationInputPort(targetNode, edge, templateSection) ?? undefined;
    const focusPorts = [
        sourcePort,
        targetPort
    ].filter((port)=>Boolean(port));
    // Interface aliases describe the edited template, but carry no external
    // producer or consumer type until a concrete section instance is connected.
    return {
        focusPorts,
        sourcePort: templateSection && (sourceNode.type === 'sectionInput' || sourceNode.type === 'sectionBuffer') ? undefined : sourcePort,
        targetPort: templateSection && targetNode.type === 'sectionOutput' ? undefined : targetPort
    };
}
function buildCompatibilityRequest(graph) {
    let focusEdges = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : graph.edges;
    const nodeManager = graph.nodeManager;
    const focusIds = new Set(focusEdges.map((param)=>{
        let { id } = param;
        return id;
    }));
    const localResults = [];
    const edges = cloneJson(graph.edges).filter((edge)=>{
        const validation = (0,_connection__WEBPACK_IMPORTED_MODULE_2__.validateEdgeSimple)(edge, nodeManager, graph.edges);
        if (!validation.valid && focusIds.has(edge.id)) {
            localResults.push({
                id: edge.id,
                status: 'incompatible',
                reason: validation.error
            });
        }
        return validation.valid;
    });
    const validEdgeIds = new Set(edges.map((param)=>{
        let { id } = param;
        return id;
    }));
    const templateSection = graph.templateId === undefined ? undefined : TEMPLATE_SECTION;
    const diagram = graph.templateId === undefined ? (0,_export_diagram__WEBPACK_IMPORTED_MODULE_3__.exportDiagram)(graph.registry, nodeManager, edges, cloneJson(graph.templates), cloneJson(graph.diagramProperties)) : {
        version: '0.1.0',
        start: {
            builtin: 'dispose'
        },
        ops: {
            [TEMPLATE_SECTION]: {
                type: 'section',
                template: graph.templateId
            }
        },
        templates: {
            ...cloneJson(graph.templates),
            [graph.templateId]: (0,_export_diagram__WEBPACK_IMPORTED_MODULE_3__.exportTemplate)(graph.registry, nodeManager, edges)
        },
        script_environments: cloneJson(graph.diagramProperties).script_environments
    };
    const request = {
        diagram,
        connections: focusEdges.filter((param)=>{
            let { id } = param;
            return validEdgeIds.has(id);
        }).map((edge)=>({
                id: edge.id,
                ...portRefsForEdge(nodeManager, edge, edges, templateSection)
            }))
    };
    return {
        request,
        localResults
    };
}
function prepareConnection(param) {
    let { connection, nodeManager, edges, registry, templates, edgeId } = param;
    const edgeResult = (0,_connection__WEBPACK_IMPORTED_MODULE_2__.createEdgeFromConnection)(connection, nodeManager, edges, edgeId);
    if (!edgeResult.valid) {
        return edgeResult;
    }
    const { edge } = edgeResult;
    function sectionPorts(nodeId, kind) {
        var _registry_sections_op_builder;
        const node = nodeManager.getNode(nodeId);
        if (node.type !== 'section') return [];
        const op = node.data.op;
        const definition = typeof op.builder === 'string' ? (_registry_sections_op_builder = registry.sections[op.builder]) === null || _registry_sections_op_builder === void 0 ? void 0 : _registry_sections_op_builder.interface : typeof op.template === 'string' ? templates[op.template] : undefined;
        const ports = definition === null || definition === void 0 ? void 0 : definition[kind];
        return Array.isArray(ports) ? ports : Object.keys(ports ?? {});
    }
    if (edge.type === 'section' && !edge.data.output.output) {
        const outputs = sectionPorts(edge.source, 'outputs').filter((output)=>!edges.some((existing)=>existing.id !== edge.id && existing.source === edge.source && existing.type === 'section' && existing.data.output.output === output));
        if (outputs.length === 1) edge.data.output = {
            output: outputs[0]
        };
    }
    if (edge.type === 'buffer' && !edge.data.output.bufferId) {
        const buffers = sectionPorts(edge.source, 'buffers');
        if (buffers.length === 1) edge.data.output = {
            bufferId: buffers[0]
        };
    }
    if ((edge.data.input.type === 'sectionInput' || edge.data.input.type === 'sectionBuffer') && !edge.data.input.inputId) {
        const source = nodeManager.getNode(edge.source);
        const inputs = [
            ...source.type === 'sectionBuffer' ? [] : sectionPorts(edge.target, 'inputs').map((inputId)=>({
                    type: 'sectionInput',
                    inputId
                })),
            ...sectionPorts(edge.target, 'buffers').map((inputId)=>({
                    type: 'sectionBuffer',
                    inputId
                }))
        ];
        if (inputs.length === 1) edge.data.input = inputs[0];
    }
    const validation = (0,_connection__WEBPACK_IMPORTED_MODULE_2__.validateEdgeSimple)(edge, nodeManager, edges);
    return validation.valid ? {
        valid: true,
        edge
    } : validation;
}
function buildConnectionPreview(param) {
    let { connection, nodeChanges = [], edgeId, ...graph } = param;
    const candidateManager = new _node_manager__WEBPACK_IMPORTED_MODULE_0__.NodeManager([
        ...graph.nodeManager.nodes,
        ...nodeChanges.map((param)=>{
            let { item } = param;
            return item;
        })
    ]);
    const edgeResult = prepareConnection({
        ...graph,
        connection,
        nodeManager: candidateManager,
        edgeId
    });
    if (!edgeResult.valid) return {
        request: null,
        localResults: [
            {
                id: 'preview',
                status: 'incompatible',
                reason: edgeResult.error
            }
        ]
    };
    const { edge } = edgeResult;
    const built = buildCompatibilityRequest({
        ...graph,
        nodeManager: candidateManager,
        edges: [
            ...graph.edges.filter((param)=>{
                let { id } = param;
                return id !== edge.id;
            }),
            edge
        ]
    }, [
        edge
    ]);
    built.request.connections[0].id = 'preview';
    return built;
}
async function checkCompatibility(apiClient, request) {
    const response = await (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.firstValueFrom)(apiClient.checkCompatibility(request));
    return new Map(response.results.map((result)=>[
            result.id,
            result
        ]));
}


}),
298: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  createConnectionFromDraggedHandle: () => (createConnectionFromDraggedHandle),
  createConnectionFromHandles: () => (createConnectionFromHandles),
  createEdgeFromConnection: () => (createEdgeFromConnection),
  getValidEdgeTypes: () => (getValidEdgeTypes),
  validateConnectionQuick: () => (validateConnectionQuick),
  validateConnectionSimple: () => (validateConnectionSimple),
  validateDraggedHandlePair: () => (validateDraggedHandlePair),
  validateEdgeFull: () => (validateEdgeFull),
  validateEdgeQuick: () => (validateEdgeQuick),
  validateEdgeSimple: () => (validateEdgeSimple),
  validateSourceOutputCapacity: () => (validateSourceOutputCapacity)
});
/* ESM import */var _edges__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(299);
/* ESM import */var _forms_edit_edge_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(318);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(149);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(147);
/* ESM import */var _exhaustive_check__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(319);





/**
 * List of edge types that a node can output.
 * TODO: Consider defining for each handle, e.g.
 *
 * ```ts
 * {
 *   node: {
 *     default: 'default',
 *     dataStream: 'streamOut',
 *   }
 * }
 * ```
 */ const ALLOWED_OUTPUT_EDGES = {
    buffer: [
        'buffer'
    ],
    buffer_access: [
        'default'
    ],
    fork_clone: [
        'default'
    ],
    fork_result: [
        'forkResultOk',
        'forkResultErr'
    ],
    join: [
        'default'
    ],
    listen: [
        'default'
    ],
    node: [
        'default',
        'streamOut'
    ],
    scope: [
        'default',
        'streamOut'
    ],
    script: [
        'default',
        'streamOut'
    ],
    section: [
        'section',
        'buffer'
    ],
    sectionInput: [
        'default'
    ],
    sectionOutput: [],
    sectionBuffer: [
        'default'
    ],
    split: [
        'splitKey',
        'splitSeq',
        'splitRemaining'
    ],
    start: [
        'default'
    ],
    stream_out: [],
    terminate: [],
    transform: [
        'default'
    ],
    unzip: [
        'unzip'
    ]
};
const ALLOWED_INPUT_EDGE_CATEGORIES = {
    buffer: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    buffer_access: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data,
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Buffer
    ],
    fork_clone: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    fork_result: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    join: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Buffer
    ],
    listen: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Buffer
    ],
    node: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    scope: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    script: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    section: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    sectionInput: [],
    sectionOutput: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    sectionBuffer: [],
    split: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    start: [],
    stream_out: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    terminate: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    transform: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    unzip: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ]
};
const ALLOWED_HANDLE_OUTPUT_EDGES = {
    dataStream: [
        'streamOut'
    ],
    forkResultOk: [
        'forkResultOk'
    ],
    forkResultErr: [
        'forkResultErr'
    ]
};
/// List of edge types that the default handle should not allow. These edges are expected to have their own handles.
const DISALLOWED_DEFAULT_HANDLE_OUTPUT_EDGES = [
    'streamOut'
];
const ALLOWED_HANDLE_INPUT_EDGE_CATEGORIES = {
    dataStream: [
        _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data
    ],
    forkResultOk: [],
    forkResultErr: []
};
function arrayIntersection(a, b) {
    const intersection = [];
    for (const elem of a){
        if (b.includes(elem)) {
            intersection.push(elem);
        }
    }
    return intersection;
}
function arrayDifference(a, b) {
    const result = [];
    for (const elem of a){
        if (!b.includes(elem)) {
            result.push(elem);
        }
    }
    return result;
}
function getValidEdgeTypes(sourceNode, sourceHandle, targetNode, targetHandle) {
    if (sourceNode.type === 'sectionBuffer') {
        return !sourceHandle && !targetHandle && (targetNode.type === 'buffer' || targetNode.type === 'section') ? [
            'default'
        ] : [];
    }
    let allowedOutputEdges = ALLOWED_OUTPUT_EDGES[sourceNode.type];
    if (sourceHandle) {
        const allowedHandleOutput = ALLOWED_HANDLE_OUTPUT_EDGES[sourceHandle];
        if (allowedHandleOutput) {
            // we are only dealing with very small arrays, no need to create a Set.
            allowedOutputEdges = arrayIntersection(allowedOutputEdges, allowedHandleOutput);
        } else {
            console.error('failed to get allowed handle output edges');
        }
    } else {
        allowedOutputEdges = arrayDifference(allowedOutputEdges, DISALLOWED_DEFAULT_HANDLE_OUTPUT_EDGES);
    }
    let allowedInputEdgeCategories = ALLOWED_INPUT_EDGE_CATEGORIES[targetNode.type];
    if (targetHandle) {
        const allowedHandleInput = ALLOWED_HANDLE_INPUT_EDGE_CATEGORIES[targetHandle];
        if (allowedHandleInput) {
            // we are only dealing with very small arrays, no need to create a Set.
            allowedInputEdgeCategories = arrayIntersection(allowedInputEdgeCategories, allowedHandleInput);
        } else {
            console.error('failed to get allowed handle input edge categories');
        }
    }
    return Array.from(allowedOutputEdges).filter((edgeType)=>allowedInputEdgeCategories.includes(_edges__WEBPACK_IMPORTED_MODULE_0__.EDGE_CATEGORIES[edgeType]));
}
var CardinalityType = /*#__PURE__*/ function(CardinalityType) {
    CardinalityType[CardinalityType["Single"] = 0] = "Single";
    CardinalityType[CardinalityType["Pair"] = 1] = "Pair";
    CardinalityType[CardinalityType["Many"] = 2] = "Many";
    return CardinalityType;
}(CardinalityType || {});
function getOutputCardinality(type, handleId) {
    if (handleId === _handles__WEBPACK_IMPORTED_MODULE_2__.HandleId.DataStream) {
        return 2;
    }
    switch(type){
        case 'fork_clone':
        case 'unzip':
        case 'buffer':
        case 'section':
        case 'split':
            {
                return 2;
            }
        case 'fork_result':
        case 'node':
        case 'buffer_access':
        case 'join':
        case 'listen':
        case 'scope':
        case 'script':
        case 'stream_out':
        case 'transform':
        case 'start':
        case 'terminate':
        case 'sectionBuffer':
        case 'sectionInput':
        case 'sectionOutput':
            {
                return 0;
            }
        default:
            {
                (0,_exhaustive_check__WEBPACK_IMPORTED_MODULE_4__.exhaustiveCheck)(type);
                throw new Error('unknown op type');
            }
    }
}
function createValidationError(error) {
    return {
        valid: false,
        error
    };
}
function createConnectionFromDraggedHandle(args) {
    return args.fromHandleType === 'source' ? {
        source: args.fromNodeId,
        sourceHandle: args.fromHandleId || null,
        target: args.otherNodeId,
        targetHandle: args.otherHandleId || null
    } : {
        source: args.otherNodeId,
        sourceHandle: args.otherHandleId || null,
        target: args.fromNodeId,
        targetHandle: args.fromHandleId || null
    };
}
function createConnectionFromHandles(fromHandle, otherNodeId, otherHandleId) {
    return createConnectionFromDraggedHandle({
        fromNodeId: fromHandle.nodeId,
        fromHandleId: fromHandle.id,
        fromHandleType: fromHandle.type,
        otherNodeId,
        otherHandleId
    });
}
function validateDraggedHandlePair(args) {
    if (args.fromHandleType === args.otherHandleType) {
        return createValidationError(args.fromHandleType === 'source' ? 'Cannot connect an output to another output' : 'Cannot connect an input to another input');
    }
    return {
        valid: true
    };
}
/**
 * Perform a quick check if an edge is valid.
 * This only checks if the edge type is valid, does not check for conflicting edges, data correctness etc.
 *
 * Complexity is O(1).
 */ function validateEdgeQuick(edge, nodeManager) {
    const sourceNode = nodeManager.tryGetNode(edge.source);
    const targetNode = nodeManager.tryGetNode(edge.target);
    if (!sourceNode || !targetNode) {
        return createValidationError('cannot find source or target node');
    }
    const validEdgeTypes = getValidEdgeTypes(sourceNode, edge.sourceHandle, targetNode, edge.targetHandle);
    if (!validEdgeTypes.includes(edge.type)) {
        return createValidationError('invalid edge type');
    }
    return {
        valid: true,
        validEdgeTypes
    };
}
/**
 * Perform a quick check if connection is valid.
 * This only checks if there is a valid edge type, does not check for conflicting edges, data correctness etc.
 *
 * Complexity is O(1).
 *
 * validateEdgeQuick checks if a given edge is valid while validateConnectionQuick check if there
 * is at least 1 valid edge type for a given connection.
 */ function validateConnectionQuick(conn, nodeManager) {
    const sourceNode = nodeManager.tryGetNode(conn.source);
    const targetNode = nodeManager.tryGetNode(conn.target);
    if (!sourceNode || !targetNode) {
        return createValidationError('cannot find source or target node');
    }
    if ((sourceNode.parentId || targetNode.parentId) && sourceNode.parentId !== targetNode.parentId) {
        return createValidationError('source and target nodes are in different sections');
    }
    const validEdgeTypes = getValidEdgeTypes(sourceNode, conn.sourceHandle, targetNode, conn.targetHandle);
    if (validEdgeTypes.length === 0) {
        return createValidationError('no valid edge type');
    }
    return {
        valid: true
    };
}
function validateSourceOutputCapacity(sourceNode, sourceHandle, edges, edgeId) {
    // Check if the source supports emitting multiple outputs.
    // NOTE: All nodes supports "Many" inputs so we don't need to check that.
    const outputCardinality = getOutputCardinality(sourceNode.type, sourceHandle);
    switch(outputCardinality){
        case 0:
            {
                if (edges.some((e)=>e.source === sourceNode.id && (sourceHandle || null) === (e.sourceHandle || null) && edgeId !== e.id)) {
                    return createValidationError('This output can only be connected to one input');
                }
                break;
            }
        case 1:
            {
                let count = 0;
                for (const e of edges){
                    if (e.source === sourceNode.id && edgeId !== e.id) {
                        count++;
                    }
                    if (count > 1) {
                        return createValidationError('This output can only be connected to two inputs');
                    }
                }
                break;
            }
        case 2:
            {
                break;
            }
        default:
            {
                (0,_exhaustive_check__WEBPACK_IMPORTED_MODULE_4__.exhaustiveCheck)(outputCardinality);
                throw new Error('unknown output cardinality');
            }
    }
    return {
        valid: true
    };
}
function validateConnectionSimple(conn, nodeManager, edges) {
    const quickCheck = validateConnectionQuick(conn, nodeManager);
    if (!quickCheck.valid) {
        return quickCheck;
    }
    const sourceNode = nodeManager.tryGetNode(conn.source);
    if (!sourceNode) {
        return createValidationError('cannot find source or target node');
    }
    if ('type' in conn) {
        const slot = outputSlot(conn);
        if (slot !== undefined && edges.some((edge)=>edge.id !== conn.id && edge.source === conn.source && outputSlot(edge) === slot)) {
            return createValidationError('This output slot is already connected to another input');
        }
    }
    return validateSourceOutputCapacity(sourceNode, conn.sourceHandle, edges, 'id' in conn ? conn.id : undefined);
}
function outputSlot(edge) {
    switch(edge.type){
        case 'unzip':
        case 'splitSeq':
            return `${edge.type}:${edge.data.output.seq}`;
        case 'splitKey':
            return `splitKey:${edge.data.output.key}`;
        case 'splitRemaining':
        case 'forkResultOk':
        case 'forkResultErr':
            return edge.type;
        case 'streamOut':
            return edge.data.output.streamId ? `streamOut:${edge.data.output.streamId}` : undefined;
        case 'section':
            return edge.data.output.output ? `section:${edge.data.output.output}` : undefined;
        default:
            return undefined;
    }
}
function nextBufferKey(sourceNode, existingKeys) {
    const baseKey = (0,_nodes__WEBPACK_IMPORTED_MODULE_3__.isOperationNode)(sourceNode) ? sourceNode.data.opId : 'buffer';
    if (!existingKeys.has(baseKey)) {
        return baseKey;
    }
    let suffix = 1;
    while(existingKeys.has(`${baseKey}_${suffix}`)){
        suffix++;
    }
    return `${baseKey}_${suffix}`;
}
function adjustBufferEdgeInputForTarget(edge, sourceNode, targetNode, edges) {
    if (edge.type !== 'buffer' || !(0,_nodes__WEBPACK_IMPORTED_MODULE_3__.isOperationNode)(targetNode) || targetNode.type !== 'buffer_access' && targetNode.type !== 'join' && targetNode.type !== 'listen') {
        return;
    }
    const inputs = edges.filter((existing)=>existing.type === 'buffer' && existing.target === targetNode.id && existing.id !== edge.id).map((existing)=>existing.data.input);
    const keyed = inputs.length ? inputs.some((input)=>input.type === 'bufferKey') : !Array.isArray(targetNode.data.op.buffers);
    if (keyed) {
        edge.data.input = {
            type: 'bufferKey',
            key: nextBufferKey(sourceNode, new Set(inputs.flatMap((input)=>input.type === 'bufferKey' ? [
                    input.key
                ] : [])))
        };
    } else {
        const used = new Set(inputs.flatMap((input)=>input.type === 'bufferSeq' ? [
                input.seq
            ] : []));
        let seq = 0;
        while(used.has(seq))seq++;
        edge.data.input = {
            type: 'bufferSeq',
            seq
        };
    }
}
function createEdgeFromConnection(conn, nodeManager, edges, id) {
    const sourceNode = nodeManager.tryGetNode(conn.source);
    const targetNode = nodeManager.tryGetNode(conn.target);
    if (!sourceNode || !targetNode) {
        return createValidationError('cannot find source or target node');
    }
    const validEdges = getValidEdgeTypes(sourceNode, conn.sourceHandle, targetNode, conn.targetHandle);
    if (validEdges.length === 0) {
        return createValidationError(`cannot connect "${sourceNode.type}" to "${targetNode.type}"`);
    }
    const previous = edges.find((edge)=>edge.id === id);
    const preserveOutput = (previous === null || previous === void 0 ? void 0 : previous.source) === conn.source && (previous.sourceHandle || null) === (conn.sourceHandle || null);
    const sourceEdges = edges.filter((edge)=>edge.source === conn.source && edge.id !== id);
    let edgeType = previous && validEdges.includes(previous.type) ? previous.type : validEdges[0];
    if (preserveOutput) {
        if (!validEdges.includes(previous.type)) {
            return createValidationError('The selected output cannot connect to this input');
        }
    } else if (!(previous && validEdges.includes(previous.type)) && sourceNode.type === 'split' && !sourceEdges.some((edge)=>edge.type === 'splitKey') && (sourceEdges.some((edge)=>edge.type === 'splitSeq') || sourceNode.data.op.sequential && !Object.keys(sourceNode.data.op.keyed ?? {}).length)) {
        edgeType = 'splitSeq';
    }
    const newEdge = {
        ...(0,_edges__WEBPACK_IMPORTED_MODULE_0__.createBaseEdge)(conn.source, conn.sourceHandle, conn.target, conn.targetHandle, id),
        type: edgeType,
        data: (0,_forms_edit_edge_form__WEBPACK_IMPORTED_MODULE_1__.defaultEdgeData)(edgeType)
    };
    if (preserveOutput) {
        newEdge.data.output = {
            ...previous.data.output
        };
    } else if (newEdge.type === 'unzip' || newEdge.type === 'splitSeq') {
        const used = new Set(sourceEdges.flatMap((edge)=>edge.type === newEdge.type && (edge.type === 'unzip' || edge.type === 'splitSeq') ? [
                edge.data.output.seq
            ] : []));
        let seq = 0;
        while(used.has(seq))seq++;
        newEdge.data.output = {
            seq
        };
    } else if (newEdge.type === 'splitKey') {
        const used = new Set(sourceEdges.flatMap((edge)=>edge.type === 'splitKey' ? [
                edge.data.output.key
            ] : []));
        let key = 'unnamed_key';
        let suffix = 1;
        while(used.has(key))key = `unnamed_key_${suffix++}`;
        newEdge.data.output = {
            key
        };
    }
    if (targetNode.type === 'section') {
        if (sourceNode.type === 'sectionBuffer') {
            newEdge.data.input = {
                type: 'sectionBuffer',
                inputId: ''
            };
        } else if (_edges__WEBPACK_IMPORTED_MODULE_0__.EDGE_CATEGORIES[newEdge.type] === _edges__WEBPACK_IMPORTED_MODULE_0__.EdgeCategory.Data) {
            newEdge.data.input = {
                type: 'sectionInput',
                inputId: ''
            };
        }
    }
    adjustBufferEdgeInputForTarget(newEdge, sourceNode, targetNode, edges);
    if ((previous === null || previous === void 0 ? void 0 : previous.target) === conn.target && (previous.targetHandle || null) === (conn.targetHandle || null) && _edges__WEBPACK_IMPORTED_MODULE_0__.EDGE_CATEGORIES[previous.type] === _edges__WEBPACK_IMPORTED_MODULE_0__.EDGE_CATEGORIES[newEdge.type] && (sourceNode.type !== 'sectionBuffer' || targetNode.type !== 'section' || previous.data.input.type === 'sectionBuffer')) {
        newEdge.data.input = {
            ...previous.data.input
        };
    }
    return {
        valid: true,
        edge: newEdge
    };
}
/**
 * Perform a simple check of the validity of edges.
 * Includes the checks in `validateEdgeQuick` and the following:
 *   * Check that the number of output edges does not exceed what the node allows.
 *   * Reject conflicting output slots and buffer consumer selections.
 *
 * Complexity is O(numOfEdges).
 */ function validateEdgeSimple(edge, nodeManager, edges) {
    const quickCheck = validateEdgeQuick(edge, nodeManager);
    if (!quickCheck.valid) {
        return quickCheck;
    }
    if ((edge.type === 'unzip' || edge.type === 'splitSeq') && (!Number.isInteger(edge.data.output.seq) || edge.data.output.seq < 0)) {
        return createValidationError('A sequential output index must be a non-negative integer');
    }
    const sourceNode = nodeManager.tryGetNode(edge.source);
    const targetNode = nodeManager.tryGetNode(edge.target);
    if (!sourceNode || !targetNode) {
        return createValidationError('cannot find source or target node');
    }
    if (targetNode.type === 'section') {
        if (edge.data.input.type !== 'sectionInput' && edge.data.input.type !== 'sectionBuffer') {
            return createValidationError('target is a section but there is no input slot');
        }
        if (sourceNode.type === 'sectionBuffer' && edge.data.input.type !== 'sectionBuffer') {
            return createValidationError('An exposed buffer must alias a buffer inside the section');
        }
    }
    if (edge.type === 'buffer') {
        const input = edge.data.input;
        if (input.type !== 'bufferKey' && input.type !== 'bufferSeq') {
            return createValidationError('A buffer consumer needs a keyed or sequential buffer slot');
        }
        if (input.type === 'bufferSeq' && (!Number.isInteger(input.seq) || input.seq < 0)) {
            return createValidationError('A sequential buffer index must be a non-negative integer');
        }
        const sequentialSlots = new Map();
        if (input.type === 'bufferSeq') sequentialSlots.set(input.seq, 1);
        for (const other of edges){
            if (other.id === edge.id || other.type !== 'buffer' || other.target !== edge.target) continue;
            if (other.data.input.type !== input.type) {
                return createValidationError('Buffer connections to one consumer must use the same slot type');
            }
            if (input.type === 'bufferKey' && other.data.input.type === 'bufferKey' && input.key === other.data.input.key || input.type === 'bufferSeq' && other.data.input.type === 'bufferSeq' && input.seq === other.data.input.seq) {
                return createValidationError('This buffer input slot is already connected');
            }
            if (other.data.input.type === 'bufferSeq' && validateEdgeQuick(other, nodeManager).valid && validateConnectionQuick(other, nodeManager).valid) {
                const seq = other.data.input.seq;
                sequentialSlots.set(seq, (sequentialSlots.get(seq) ?? 0) + 1);
            }
        }
        if (input.type === 'bufferSeq') {
            let firstMissing = 0;
            // Duplicate or invalid earlier slots will be excluded from diagnostic
            // export, so they cannot fill a gap in the serialized buffer selection.
            while(sequentialSlots.get(firstMissing) === 1)firstMissing++;
            if (input.seq > firstMissing) {
                return createValidationError(`Sequential buffer slot ${firstMissing} must be connected first`);
            }
        }
    }
    const outputCapacity = validateConnectionSimple(edge, nodeManager, edges);
    if (!outputCapacity.valid) {
        return outputCapacity;
    }
    return {
        valid: true,
        validEdgeTypes: quickCheck.validEdgeTypes
    };
}
/**
 * Perform a full check of the validity of edges.
 * Includes the checks in `validateEdgesSimple` and the following:
 *   * TODO: Export and send the diagram to `crossflow` for complete validation.
 *
 * This can be slow so it is not recommended to call this frequently.
 */ async function validateEdgeFull(edge, nodeManager, edges) {
    const simpleCheck = validateEdgeSimple(edge, nodeManager, edges);
    if (!simpleCheck.valid) {
        return simpleCheck;
    }
    // TODO: Writing the same logic as `crossflow` to do complete validation is hard, it is
    // be better to introduce a validation endpoint and have `crossflow` do the validation.
    return {
        valid: true,
        validEdgeTypes: simpleCheck.validEdgeTypes
    };
}


}),
1191: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  isTextEditingTarget: () => (isTextEditingTarget),
  shouldIgnoreEscapeClose: () => (shouldIgnoreEscapeClose)
});
function isTextEditingTarget(target) {
    if (!(target instanceof Element)) {
        return false;
    }
    if (target.closest('.cm-editor')) {
        return true;
    }
    const editable = target.closest('input, textarea, select, [contenteditable=""], [contenteditable="true"]');
    if (!editable) {
        return false;
    }
    if (editable instanceof HTMLInputElement && [
        'button',
        'checkbox',
        'color',
        'file',
        'image',
        'radio',
        'range',
        'reset',
        'submit'
    ].includes(editable.type)) {
        return false;
    }
    return true;
}
function shouldIgnoreEscapeClose(target) {
    return isTextEditingTarget(target);
}


}),
319: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  exhaustiveCheck: () => (exhaustiveCheck)
});
/**
 * A trick to make typescript checks that the `switch` statement covers all cases.
 *
 * This works by taking an argument of type `never`, which will only be true when all cases are covered.
 *
 * # Example
 *
 * ```ts
 * switch (value) {
 *   case 'valueA':
 *     break;
 *   case 'valueB':
 *     break;
 *   default:
 *     exhaustiveCheck(type)
 * }
 * ```
 */ function exhaustiveCheck(_) {}


}),
670: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  exportDiagram: () => (exportDiagram),
  exportTemplate: () => (exportTemplate)
});
/* ESM import */var _xyflow_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(27);
/* ESM import */var _edges__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(299);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(147);
/* ESM import */var _exhaustive_check__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(319);
/* ESM import */var _namespace__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(671);
/* ESM import */var _operation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(672);







function markEdgeError(edge) {
    edge.style = {
        ...edge.style,
        stroke: 'var(--mui-palette-error-main)'
    };
}
function markEdgeNormal(edge) {
    edge.style = {
        ...edge.style,
        stroke: undefined
    };
}
function getSubOperations(root, namespace) {
    const namespaces = (0,_namespace__WEBPACK_IMPORTED_MODULE_4__.splitNamespaces)(namespace);
    let subOps = root;
    for (const namespace of namespaces.slice(1)){
        const scopeOp = subOps.ops[namespace];
        if (!scopeOp || scopeOp.type !== 'scope') {
            throw new Error(`expected ${namespace} to be a scope operation`);
        }
        subOps = scopeOp;
    }
    return subOps;
}
function syncStreamOut(nodeManager, sourceOp, edge) {
    sourceOp.stream_out = sourceOp.stream_out ? sourceOp.stream_out : {};
    sourceOp.stream_out[edge.data.output.streamId] = nodeManager.getTargetNextOp(edge);
}
function getBufferSelection(targetOp) {
    switch(targetOp.type){
        case 'buffer_access':
        case 'listen':
        case 'join':
            {
                return targetOp.buffers;
            }
        default:
            {
                throw new Error(`"${targetOp.type}" operation does not accept a buffer`);
            }
    }
}
function setBufferSelection(targetOp, bufferSelection) {
    switch(targetOp.type){
        case 'buffer_access':
        case 'listen':
        case 'join':
            {
                targetOp.buffers = bufferSelection;
                break;
            }
        default:
            {
                throw new Error(`"${targetOp.type}" operation does not accept a buffer`);
            }
    }
}
function syncBufferSelection(nodeManager, edge, edges) {
    if (edge.type === 'buffer') {
        var _edge_data_input, _edge_data_input1, _edge_data_input2, _edge_data_input3;
        const targetNode = nodeManager.getNode(edge.target);
        if (!(0,_nodes__WEBPACK_IMPORTED_MODULE_2__.isOperationNode)(targetNode)) {
            throw new Error('expected operation node');
        }
        const targetOp = targetNode.data.op;
        if (!targetOp) {
            throw new Error(`target operation "${edge.target}" not found`);
        }
        let bufferSelection = getBufferSelection(targetOp);
        if (((_edge_data_input = edge.data.input) === null || _edge_data_input === void 0 ? void 0 : _edge_data_input.type) === 'bufferKey' && Array.isArray(bufferSelection) && bufferSelection.length === 0) {
            // the array is empty so it is safe to change it to a keyed buffer selection
            bufferSelection = {};
            setBufferSelection(targetOp, bufferSelection);
        } else if (((_edge_data_input1 = edge.data.input) === null || _edge_data_input1 === void 0 ? void 0 : _edge_data_input1.type) === 'bufferSeq' && typeof bufferSelection === 'object' && !Array.isArray(bufferSelection) && Object.keys(bufferSelection).length === 0) {
            // the dict is empty so it is safe to change it to an array of buffers
            bufferSelection = [];
            setBufferSelection(targetOp, bufferSelection);
        }
        const sourceNode = nodeManager.getNode(edge.source);
        if (sourceNode.type !== 'buffer' && sourceNode.type !== 'section') {
            throw new Error('expected source to expose a buffer');
        }
        const bufferRef = sourceNode.type === 'section' ? {
            [sourceNode.data.opId]: edge.data.output.bufferId || ''
        } : sourceNode.data.opId;
        // check that the buffer selection is compatible
        if (edge.type === 'buffer' && ((_edge_data_input2 = edge.data.input) === null || _edge_data_input2 === void 0 ? void 0 : _edge_data_input2.type) === 'bufferSeq') {
            if (!(0,_operation__WEBPACK_IMPORTED_MODULE_5__.isArrayBufferSelection)(bufferSelection)) {
                (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_6__.getConnectedEdges)([
                    targetNode
                ], edges).filter((edge)=>edge.type === 'buffer' && edge.target === targetNode.id).forEach((edge)=>{
                    markEdgeError(edge);
                });
                throw new Error('A sequential buffer edge must be assigned to an array of buffers. \
          Ensure that other buffer edges connected to the same target node have \
          the same slot type.');
            }
            bufferSelection[edge.data.input.seq] = bufferRef;
        }
        if (edge.type === 'buffer' && ((_edge_data_input3 = edge.data.input) === null || _edge_data_input3 === void 0 ? void 0 : _edge_data_input3.type) === 'bufferKey') {
            if (!(0,_operation__WEBPACK_IMPORTED_MODULE_5__.isKeyedBufferSelection)(bufferSelection)) {
                (0,_xyflow_react__WEBPACK_IMPORTED_MODULE_6__.getConnectedEdges)([
                    targetNode
                ], edges).filter((edge)=>edge.type === 'buffer' && edge.target === targetNode.id).forEach((edge)=>{
                    markEdgeError(edge);
                });
                throw new Error('A keyed buffer edge must be assigned to a keyed buffer selection. \
          Ensure that other buffer edges connected to the same target node have \
          the same slot type.');
            }
            bufferSelection[edge.data.input.key] = bufferRef;
        }
        if (targetOp.type === 'join') {
            if (edge.data.input.fetchType === _edges__WEBPACK_IMPORTED_MODULE_0__.BufferFetchType.Clone) {
                var _edge_data_input4, _edge_data_input5;
                if (!targetOp.clone) {
                    targetOp.clone = [];
                }
                if (((_edge_data_input4 = edge.data.input) === null || _edge_data_input4 === void 0 ? void 0 : _edge_data_input4.type) === 'bufferSeq') {
                    targetOp.clone.push(edge.data.input.seq);
                }
                if (((_edge_data_input5 = edge.data.input) === null || _edge_data_input5 === void 0 ? void 0 : _edge_data_input5.type) === 'bufferKey') {
                    targetOp.clone.push(edge.data.input.key);
                }
            }
        }
        markEdgeNormal(edge);
    }
}
function setSequentialKey(sequences, idx, value) {
    while(sequences.length <= idx){
        sequences.push({
            builtin: 'dispose'
        });
    }
    sequences[idx] = value;
}
/**
 * Update a node's data with the edge, this updates fields like `next` and `buffer` to be
 * in sync with the edge data.
 */ function syncEdge(nodeManager, root, edge, edges) {
    if (edge.type === 'buffer') {
        syncBufferSelection(nodeManager, edge, edges);
        return;
    }
    const sourceNode = nodeManager.getNode(edge.source);
    if ((0,_nodes__WEBPACK_IMPORTED_MODULE_2__.isOperationNode)(sourceNode)) {
        const sourceOp = sourceNode.data.op;
        switch(sourceOp.type){
            case 'node':
                {
                    if (edge.type === 'streamOut') {
                        syncStreamOut(nodeManager, sourceOp, edge);
                    } else if (edge.type === 'default') {
                        sourceOp.next = nodeManager.getTargetNextOp(edge);
                    }
                    break;
                }
            case 'join':
            case 'transform':
            case 'buffer_access':
            case 'listen':
                {
                    if (edge.type !== 'default') {
                        throw new Error('expected "default" edge');
                    }
                    sourceOp.next = nodeManager.getTargetNextOp(edge);
                    break;
                }
            case 'script':
                {
                    if (edge.type === 'streamOut') {
                        syncStreamOut(nodeManager, sourceOp, edge);
                    } else if (edge.type === 'default') {
                        sourceOp.next = nodeManager.getTargetNextOp(edge);
                    }
                    break;
                }
            case 'section':
                {
                    if (edge.type !== 'section') {
                        throw new Error('expected section edge');
                    }
                    if (!sourceOp.connect) {
                        sourceOp.connect = {};
                    }
                    sourceOp.connect[edge.data.output.output] = nodeManager.getTargetNextOp(edge);
                    break;
                }
            case 'fork_clone':
                {
                    if (edge.type !== 'default') {
                        throw new Error('expected "default" edge');
                    }
                    sourceOp.next.push(nodeManager.getTargetNextOp(edge));
                    break;
                }
            case 'unzip':
                {
                    if (edge.type !== 'unzip') {
                        throw new Error('expected "unzip" edge');
                    }
                    setSequentialKey(sourceOp.next, edge.data.output.seq, nodeManager.getTargetNextOp(edge));
                    break;
                }
            case 'fork_result':
                {
                    switch(edge.type){
                        case 'forkResultOk':
                            {
                                sourceOp.ok = nodeManager.getTargetNextOp(edge);
                                break;
                            }
                        case 'forkResultErr':
                            {
                                sourceOp.err = nodeManager.getTargetNextOp(edge);
                                break;
                            }
                        default:
                            {
                                throw new Error('fork_result operation must have "ok" or "err" edge');
                            }
                    }
                    break;
                }
            case 'split':
                {
                    switch(edge.type){
                        case 'splitKey':
                            {
                                if (!sourceOp.keyed) {
                                    sourceOp.keyed = {};
                                }
                                sourceOp.keyed[edge.data.output.key] = nodeManager.getTargetNextOp(edge);
                                break;
                            }
                        case 'splitSeq':
                            {
                                if (!sourceOp.sequential) {
                                    sourceOp.sequential = [];
                                }
                                const next = nodeManager.getTargetNextOp(edge);
                                setSequentialKey(sourceOp.sequential, edge.data.output.seq, next);
                                break;
                            }
                        case 'splitRemaining':
                            {
                                sourceOp.remaining = nodeManager.getTargetNextOp(edge);
                                break;
                            }
                        default:
                            {
                                throw new Error('split operation must have "SplitKey", "SplitSequential", or "SplitRemaining" edge');
                            }
                    }
                    break;
                }
            case 'buffer':
                {
                    throw new Error('buffer operations cannot have connections');
                }
            case 'scope':
                {
                    if (edge.type === 'streamOut') {
                        syncStreamOut(nodeManager, sourceOp, edge);
                    } else if (edge.type === 'default') {
                        sourceOp.next = nodeManager.getTargetNextOp(edge);
                    } else {
                        throw new Error('scope operation must have default or streamOut edge');
                    }
                    break;
                }
            case 'stream_out':
                {
                    break;
                }
            default:
                {
                    (0,_exhaustive_check__WEBPACK_IMPORTED_MODULE_3__.exhaustiveCheck)(sourceOp);
                    throw new Error('unknown operation type');
                }
        }
    } else if (sourceNode.type === 'start') {
        const subOps = (()=>{
            if (!sourceNode.parentId) {
                return root;
            }
            const scopeNode = nodeManager.getNode(sourceNode.parentId);
            if (!(0,_nodes__WEBPACK_IMPORTED_MODULE_2__.isScopeNode)(scopeNode)) {
                throw new Error('expected parent to be a scope node');
            }
            return scopeNode.data.op;
        })();
        const target = nodeManager.getTargetNextOp(edge);
        subOps.start = target;
    } else if (sourceNode.type === 'sectionInput' || sourceNode.type === 'sectionBuffer') {
        sourceNode.data.targetId = nodeManager.getTargetNextOp(edge);
    }
}
function clearConnections(nodeManager, root) {
    root.start = {
        builtin: 'dispose'
    };
    for (const node of nodeManager.iterNodes()){
        switch(node.type){
            case 'node':
                {
                    node.data.op.next = {
                        builtin: 'dispose'
                    };
                    delete node.data.op.stream_out;
                    break;
                }
            case 'scope':
                {
                    node.data.op.next = {
                        builtin: 'dispose'
                    };
                    delete node.data.op.stream_out;
                    node.data.op.start = {
                        builtin: 'dispose'
                    };
                    break;
                }
            case 'fork_clone':
            case 'unzip':
                {
                    node.data.op.next = [];
                    break;
                }
            case 'transform':
                {
                    node.data.op.next = {
                        builtin: 'dispose'
                    };
                    break;
                }
            case 'script':
                {
                    node.data.op.next = {
                        builtin: 'dispose'
                    };
                    delete node.data.op.stream_out;
                    break;
                }
            case 'join':
                {
                    node.data.op.next = {
                        builtin: 'dispose'
                    };
                    node.data.op.buffers = [];
                    delete node.data.op.clone;
                    break;
                }
            case 'listen':
            case 'buffer_access':
                {
                    node.data.op.next = {
                        builtin: 'dispose'
                    };
                    node.data.op.buffers = [];
                    break;
                }
            case 'section':
                {
                    node.data.op.connect = {};
                    break;
                }
            case 'fork_result':
                {
                    node.data.op.ok = {
                        builtin: 'dispose'
                    };
                    node.data.op.err = {
                        builtin: 'dispose'
                    };
                    break;
                }
            case 'split':
                {
                    delete node.data.op.keyed;
                    delete node.data.op.sequential;
                    delete node.data.op.remaining;
                    break;
                }
            case 'buffer':
                {
                    break;
                }
            case 'stream_out':
                {
                    break;
                }
            case 'sectionInput':
            case 'sectionBuffer':
                {
                    node.data.targetId = {
                        builtin: 'dispose'
                    };
                    break;
                }
            case 'sectionOutput':
            case 'start':
            case 'terminate':
                break;
            default:
                {
                    (0,_exhaustive_check__WEBPACK_IMPORTED_MODULE_3__.exhaustiveCheck)(node);
                }
        }
    }
}
/**
 * Update the operation connections from the edges.
 *
 * @param root only used to update the `start` field, does not actually populate the operations.
 */ function syncEdges(registry, nodeManager, root, edges) {
    // first clear all the connections
    clearConnections(nodeManager, root);
    const validEdges = edges.filter((edge)=>{
        // Filter out zombie stream edges that connects to a node without streams
        // Reactflow does not synchronous the `Node.handles` property to the actual handles of a node,
        // so we need to rely on the registry to cross reference.
        if (edge.type === 'streamOut') {
            const sourceNode = nodeManager.getNode(edge.source);
            if ((0,_nodes__WEBPACK_IMPORTED_MODULE_2__.isOperationNode)(sourceNode)) {
                if (sourceNode.data.op.type === 'script' || sourceNode.data.op.type === 'scope') {
                    return true;
                }
                if (sourceNode.data.op.type === 'node') {
                    const builderMetadata = registry.nodes[sourceNode.data.op.builder];
                    const hasStreams = (builderMetadata === null || builderMetadata === void 0 ? void 0 : builderMetadata.streams) ? Object.keys(builderMetadata.streams).length > 0 : false;
                    return hasStreams;
                }
            }
            return false;
        }
        return true;
    });
    for (const edge of validEdges){
        syncEdge(nodeManager, root, edge, edges);
    }
}
/**
 * Split the node's namespace if it has one, else return `[ROOT_NAMESPACE]`.
 */ function splitNodeNamespace(node) {
    if ((0,_nodes__WEBPACK_IMPORTED_MODULE_2__.isBuiltinNode)(node) || (0,_nodes__WEBPACK_IMPORTED_MODULE_2__.isOperationNode)(node)) {
        return (0,_namespace__WEBPACK_IMPORTED_MODULE_4__.splitNamespaces)(node.data.namespace);
    }
    return [
        _namespace__WEBPACK_IMPORTED_MODULE_4__.ROOT_NAMESPACE
    ];
}
function exportDiagram(registry, nodeManager, edges, templates, diagramProperties) {
    nodeManager = new _node_manager__WEBPACK_IMPORTED_MODULE_1__.NodeManager(JSON.parse(JSON.stringify(nodeManager.nodes)));
    const diagram = {
        $schema: 'https://raw.githubusercontent.com/open-rmf/crossflow/refs/heads/main/diagram.schema.json',
        version: '0.1.0',
        templates,
        start: {
            builtin: 'dispose'
        },
        ops: {}
    };
    syncEdges(registry, nodeManager, diagram, edges);
    // visit the nodes breath first to ensure that the parents exist in the diagram before
    // populating the children.
    const sortedNodes = Array.from(nodeManager.iterNodes()).sort((a, b)=>splitNodeNamespace(a).length - splitNodeNamespace(b).length);
    for (const node of sortedNodes){
        if (!(0,_nodes__WEBPACK_IMPORTED_MODULE_2__.isOperationNode)(node)) {
            continue;
        }
        const subOps = getSubOperations(diagram, node.data.namespace);
        subOps.ops[node.data.opId] = {
            ...node.data.op
        };
        if (node.data.op.type === 'scope') {
            // do not carry over stale ops from the node data
            subOps.ops[node.data.opId].ops = {};
        }
    }
    diagram.description = diagramProperties.description;
    diagram.input_examples = diagramProperties.input_examples;
    diagram.script_environments = diagramProperties.script_environments;
    return diagram;
}
function exportTemplate(registry, nodeManager, edges) {
    nodeManager = new _node_manager__WEBPACK_IMPORTED_MODULE_1__.NodeManager(JSON.parse(JSON.stringify(nodeManager.nodes)));
    const fakeRoot = {
        start: {
            builtin: 'dispose'
        },
        ops: {}
    };
    const template = {
        inputs: {},
        outputs: [],
        buffers: {},
        ops: fakeRoot.ops
    };
    syncEdges(registry, nodeManager, fakeRoot, edges);
    // visit the nodes breath first to ensure that the parents exist in the diagram before
    // populating the children.
    const sortedNodes = Array.from(nodeManager.iterNodes()).sort((a, b)=>splitNodeNamespace(a).length - splitNodeNamespace(b).length);
    for (const node of sortedNodes){
        if ((0,_nodes__WEBPACK_IMPORTED_MODULE_2__.isOperationNode)(node)) {
            const subOps = getSubOperations(fakeRoot, node.data.namespace);
            subOps.ops[node.data.opId] = {
                ...node.data.op
            };
            if (node.data.op.type === 'scope') {
                // do not carry over stale ops from the node data
                subOps.ops[node.data.opId].ops = {};
            }
        } else if (node.type === 'sectionInput') {
            template.inputs[node.data.remappedId] = node.data.targetId;
        } else if (node.type === 'sectionOutput') {
            template.outputs.push(node.data.outputId);
        } else if (node.type === 'sectionBuffer') {
            template.buffers[node.data.remappedId] = node.data.targetId;
        }
    }
    return template;
}


}),
677: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  LAYOUT_OPTIONS: () => (LAYOUT_OPTIONS),
  calculateScopeBounds: () => (calculateScopeBounds)
});
const LAYOUT_OPTIONS = {
    nodeWidth: 200,
    nodeHeight: 50,
    scopePadding: {
        leftRight: 75,
        topBottom: 50
    }
};
function calculateScopeBounds(childrenPosition) {
    if (childrenPosition.length === 0) {
        return {
            x: 0,
            y: 0,
            width: LAYOUT_OPTIONS.scopePadding.leftRight * 2,
            height: LAYOUT_OPTIONS.scopePadding.topBottom * 2
        };
    }
    const minX = Math.min(...childrenPosition.map((n)=>n.x));
    const maxX = Math.max(...childrenPosition.map((n)=>n.x + LAYOUT_OPTIONS.nodeWidth));
    const minY = Math.min(...childrenPosition.map((n)=>n.y));
    const maxY = Math.max(...childrenPosition.map((n)=>n.y + LAYOUT_OPTIONS.nodeHeight));
    return {
        x: minX - LAYOUT_OPTIONS.scopePadding.leftRight,
        y: minY - LAYOUT_OPTIONS.scopePadding.topBottom,
        width: maxX - minX + LAYOUT_OPTIONS.scopePadding.leftRight * 2,
        height: maxY - minY + LAYOUT_OPTIONS.scopePadding.topBottom * 2
    };
}


}),
1192: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  loadDiagram: () => (loadDiagram),
  loadDiagramJson: () => (loadDiagramJson),
  loadEmpty: () => (loadEmpty),
  loadTemplate: () => (loadTemplate)
});
/* ESM import */var _edges__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(299);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(147);
/* ESM import */var _persist_state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(850);
/* ESM import */var _ajv__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(155);
/* ESM import */var _export_diagram__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(670);
/* ESM import */var _namespace__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(671);
/* ESM import */var _operation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(672);








async function loadDiagram(diagram) {
    const state = await (0,_persist_state__WEBPACK_IMPORTED_MODULE_3__.loadState)(diagram);
    if (state) {
        return {
            graph: {
                nodes: state.nodes,
                edges: state.edges
            },
            isRestored: true
        };
    }
    const graph = buildGraph(diagram);
    return {
        graph,
        isRestored: false
    };
}
function validateScriptEnvironments(diagram) {
    const envs = diagram.script_environments || {};
    function checkOps(ops) {
        for (const [opId, op] of Object.entries(ops)){
            if (op.type === 'script' && op.environment && !Object.keys(envs).includes(op.environment)) {
                throw new Error(`Script node '${opId}' references unknown environment '${op.environment}'`);
            }
            if (op.type === 'scope' && op.ops) {
                checkOps(op.ops);
            }
        }
    }
    if (diagram.ops) {
        checkOps(diagram.ops);
    }
}
async function loadDiagramJson(jsonStr) {
    const diagram = JSON.parse(jsonStr);
    const valid = validate(diagram);
    if (!valid) {
        var _validate_errors;
        const error = (_validate_errors = validate.errors) === null || _validate_errors === void 0 ? void 0 : _validate_errors[0];
        if (!error) {
            throw 'unknown error';
        }
        throw `${error.instancePath} ${error.message}`;
    }
    validateScriptEnvironments(diagram);
    return [
        diagram,
        await loadDiagram(diagram)
    ];
}
function loadEmpty() {
    return {
        nodes: [
            (0,_nodes__WEBPACK_IMPORTED_MODULE_2__.createStartNode)(_namespace__WEBPACK_IMPORTED_MODULE_6__.ROOT_NAMESPACE, {
                x: 0,
                y: 0
            }),
            (0,_nodes__WEBPACK_IMPORTED_MODULE_2__.createTerminateNode)(_namespace__WEBPACK_IMPORTED_MODULE_6__.ROOT_NAMESPACE, {
                x: 0,
                y: 400
            })
        ],
        edges: []
    };
}
function buildGraph(diagram, initialGraph) {
    const graph = initialGraph ?? loadEmpty();
    const nodes = graph.nodes;
    const stack = [
        ...Object.entries(diagram.ops).map((param)=>{
            let [opId, op] = param;
            return {
                parentId: undefined,
                namespace: _namespace__WEBPACK_IMPORTED_MODULE_6__.ROOT_NAMESPACE,
                opId,
                op
            };
        })
    ];
    for(let state = stack.pop(); state !== undefined; state = stack.pop()){
        const { parentId, namespace, opId, op } = state;
        if (op.type === 'scope') {
            const scopeNodes = (0,_nodes__WEBPACK_IMPORTED_MODULE_2__.createScopeNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, op, opId);
            const scopeId = scopeNodes[0].id;
            nodes.push(...scopeNodes);
            for (const [innerOpId, innerOp] of Object.entries(op.ops)){
                stack.push({
                    parentId: scopeId,
                    namespace: (0,_namespace__WEBPACK_IMPORTED_MODULE_6__.joinNamespaces)(namespace, opId),
                    opId: innerOpId,
                    op: innerOp
                });
            }
        } else {
            nodes.push((0,_nodes__WEBPACK_IMPORTED_MODULE_2__.createOperationNode)(namespace, parentId, {
                x: 0,
                y: 0
            }, op, opId));
        }
    }
    const edges = graph.edges;
    const diagramStart = diagram.start;
    const startNode = new _node_manager__WEBPACK_IMPORTED_MODULE_1__.NodeManager(nodes).getNodeFromNextOp(_namespace__WEBPACK_IMPORTED_MODULE_6__.ROOT_NAMESPACE, diagramStart);
    if (startNode) {
        edges.push((0,_operation__WEBPACK_IMPORTED_MODULE_7__.withTargetInput)((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createDefaultEdge)((0,_namespace__WEBPACK_IMPORTED_MODULE_6__.joinNamespaces)(_namespace__WEBPACK_IMPORTED_MODULE_6__.ROOT_NAMESPACE, _nodes__WEBPACK_IMPORTED_MODULE_2__.START_ID), null, startNode.id, null), diagramStart));
    }
    edges.push(...(0,_operation__WEBPACK_IMPORTED_MODULE_7__.buildEdges)(graph.nodes));
    return graph;
}
const validate = (0,_ajv__WEBPACK_IMPORTED_MODULE_4__.getSchema)('Diagram');
function loadTemplate(template) {
    const stubRegistry = {
        messages: [],
        nodes: {},
        reverse_message_lookup: {
            result: [],
            split: [],
            unzip: []
        },
        schemas: {},
        sections: {},
        scripting: {},
        trace_supported: false
    };
    const stubDiagram = (0,_export_diagram__WEBPACK_IMPORTED_MODULE_5__.exportDiagram)(stubRegistry, new _node_manager__WEBPACK_IMPORTED_MODULE_1__.NodeManager([]), [], {}, {});
    stubDiagram.ops = template.ops;
    const initialNodes = [];
    if (template.inputs) {
        if (Array.isArray(template.inputs)) {
            for (const input of template.inputs){
                initialNodes.push((0,_nodes__WEBPACK_IMPORTED_MODULE_2__.createSectionInputNode)(input, input, {
                    x: 0,
                    y: 0
                }));
            }
        } else {
            for (const [remappedId, targetId] of Object.entries(template.inputs)){
                initialNodes.push((0,_nodes__WEBPACK_IMPORTED_MODULE_2__.createSectionInputNode)(remappedId, targetId, {
                    x: 0,
                    y: 0
                }));
            }
        }
    }
    if (template.buffers) {
        if (Array.isArray(template.buffers)) {
            for (const buffer of template.buffers){
                initialNodes.push((0,_nodes__WEBPACK_IMPORTED_MODULE_2__.createSectionBufferNode)(buffer, buffer, {
                    x: 0,
                    y: 0
                }));
            }
        } else {
            for (const [remappedId, targetId] of Object.entries(template.buffers)){
                initialNodes.push((0,_nodes__WEBPACK_IMPORTED_MODULE_2__.createSectionBufferNode)(remappedId, targetId, {
                    x: 0,
                    y: 0
                }));
            }
        }
    }
    if (template.outputs) {
        for (const output of template.outputs){
            initialNodes.push((0,_nodes__WEBPACK_IMPORTED_MODULE_2__.createSectionOutputNode)(output, {
                x: 0,
                y: 0
            }));
        }
    }
    return buildGraph(stubDiagram, {
        nodes: initialNodes,
        edges: []
    });
}


}),
671: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  ROOT_NAMESPACE: () => (ROOT_NAMESPACE),
  joinNamespaces: () => (joinNamespaces),
  splitNamespaces: () => (splitNamespaces)
});
/**
 * The root namespace is an empty string so namespaces that begins with `:` can be identified as
 * absolute.
 */ const ROOT_NAMESPACE = '';
function joinNamespaces() {
    for(var _len = arguments.length, namespaces = new Array(_len), _key = 0; _key < _len; _key++){
        namespaces[_key] = arguments[_key];
    }
    return namespaces.join(':');
}
function splitNamespaces(namespace) {
    return namespace.split(':');
}


}),
672: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  buildEdges: () => (buildEdges),
  formatNextOperation: () => (formatNextOperation),
  isArrayBufferSelection: () => (isArrayBufferSelection),
  isBuiltin: () => (isBuiltin),
  isKeyedBufferSelection: () => (isKeyedBufferSelection),
  isSectionBuilder: () => (isSectionBuilder),
  withTargetInput: () => (withTargetInput)
});
/* ESM import */var _edges__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(299);
/* ESM import */var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(149);
/* ESM import */var _node_manager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(145);
/* ESM import */var _nodes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(147);
/* ESM import */var _exhaustive_check__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(319);
/* ESM import */var _namespace__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(671);






function isKeyedBufferSelection(bufferSelection) {
    return typeof bufferSelection !== 'string' && !Array.isArray(bufferSelection);
}
function isArrayBufferSelection(bufferSelection) {
    return Array.isArray(bufferSelection);
}
function withTargetInput(edge, next) {
    if (typeof next === 'object' && !isBuiltin(next)) {
        edge.data.input = {
            type: 'sectionInput',
            inputId: Object.values(next)[0]
        };
    }
    return edge;
}
function createStreamOutEdges(streamOuts, node, nodeManager) {
    const edges = [];
    for (const [streamId, nextOp] of Object.entries(streamOuts)){
        const targetNode = nodeManager.getNodeFromNextOp(node.data.namespace, nextOp);
        if (targetNode) {
            const target = targetNode.id;
            edges.push(withTargetInput((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createStreamOutEdge)(node.id, _handles__WEBPACK_IMPORTED_MODULE_1__.HandleId.DataStream, target, null, {
                streamId
            }), nextOp));
        }
    }
    return edges;
}
function getBufferFetchType(node, key) {
    var _node_data_op_clone;
    if (node.type !== 'join' || node.data.op.type !== 'join') {
        return null;
    }
    if ((_node_data_op_clone = node.data.op.clone) === null || _node_data_op_clone === void 0 ? void 0 : _node_data_op_clone.includes(key)) {
        return _edges__WEBPACK_IMPORTED_MODULE_0__.BufferFetchType.Clone;
    } else {
        return _edges__WEBPACK_IMPORTED_MODULE_0__.BufferFetchType.Pull;
    }
}
function createBufferEdges(node, buffers, nodeManager) {
    const edges = [];
    if (isArrayBufferSelection(buffers)) {
        for (const [idx, buffer] of buffers.entries()){
            var _nodeManager_getNodeFromNextOp;
            const source = (_nodeManager_getNodeFromNextOp = nodeManager.getNodeFromNextOp(node.data.namespace, buffer)) === null || _nodeManager_getNodeFromNextOp === void 0 ? void 0 : _nodeManager_getNodeFromNextOp.id;
            if (source) {
                const fetchType = getBufferFetchType(node, idx);
                const edge = (0,_edges__WEBPACK_IMPORTED_MODULE_0__.createBufferEdge)(source, null, node.id, null, {
                    type: 'bufferSeq',
                    seq: idx,
                    ...fetchType !== null ? {
                        fetchType
                    } : {}
                });
                if (typeof buffer === 'object' && !isBuiltin(buffer)) {
                    edge.data.output = {
                        bufferId: Object.values(buffer)[0]
                    };
                }
                edges.push(edge);
            }
        }
    } else if (isKeyedBufferSelection(buffers)) {
        for (const [key, buffer] of Object.entries(buffers)){
            var _nodeManager_getNodeFromNextOp1;
            const source = (_nodeManager_getNodeFromNextOp1 = nodeManager.getNodeFromNextOp(node.data.namespace, buffer)) === null || _nodeManager_getNodeFromNextOp1 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp1.id;
            if (source) {
                const fetchType = getBufferFetchType(node, key);
                const edge = (0,_edges__WEBPACK_IMPORTED_MODULE_0__.createBufferEdge)(source, null, node.id, null, {
                    type: 'bufferKey',
                    key,
                    ...fetchType !== null ? {
                        fetchType
                    } : {}
                });
                if (typeof buffer === 'object' && !isBuiltin(buffer)) {
                    edge.data.output = {
                        bufferId: Object.values(buffer)[0]
                    };
                }
                edges.push(edge);
            }
        }
    }
    return edges;
}
function buildEdges(nodes) {
    const edges = [];
    const nodeManager = new _node_manager__WEBPACK_IMPORTED_MODULE_2__.NodeManager(nodes);
    const addDataEdge = (edge, next)=>{
        edges.push(withTargetInput(edge, next));
    };
    const stack = [
        ...nodes.map((node)=>({
                namespace: _namespace__WEBPACK_IMPORTED_MODULE_5__.ROOT_NAMESPACE,
                opId: node.data.opId,
                op: node.data.op
            }))
    ];
    for (const node of nodes){
        if ((0,_nodes__WEBPACK_IMPORTED_MODULE_3__.isOperationNode)(node)) {
            const op = node.data.op;
            const opId = node.data.opId;
            switch(op.type){
                case 'buffer':
                    {
                        break;
                    }
                case 'buffer_access':
                case 'join':
                case 'listen':
                    {
                        var _nodeManager_getNodeFromNextOp;
                        edges.push(...createBufferEdges(node, op.buffers, nodeManager));
                        const nextNodeId = (_nodeManager_getNodeFromNextOp = nodeManager.getNodeFromNextOp(node.data.namespace, op.next)) === null || _nodeManager_getNodeFromNextOp === void 0 ? void 0 : _nodeManager_getNodeFromNextOp.id;
                        if (nextNodeId) {
                            addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createDefaultEdge)(node.id, null, nextNodeId, null), op.next);
                        }
                        break;
                    }
                case 'node':
                    {
                        var _nodeManager_getNodeFromNextOp1;
                        const target = (_nodeManager_getNodeFromNextOp1 = nodeManager.getNodeFromNextOp(node.data.namespace, op.next)) === null || _nodeManager_getNodeFromNextOp1 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp1.id;
                        if (target) {
                            addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createDefaultEdge)(node.id, null, target, null), op.next);
                        }
                        if (op.stream_out) {
                            edges.push(...createStreamOutEdges(op.stream_out, node, nodeManager));
                        }
                        break;
                    }
                case 'script':
                    {
                        var _nodeManager_getNodeFromNextOp2;
                        const target = (_nodeManager_getNodeFromNextOp2 = nodeManager.getNodeFromNextOp(node.data.namespace, op.next)) === null || _nodeManager_getNodeFromNextOp2 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp2.id;
                        if (target) {
                            addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createDefaultEdge)(node.id, null, target, null), op.next);
                        }
                        if (op.stream_out) {
                            edges.push(...createStreamOutEdges(op.stream_out, node, nodeManager));
                        }
                        break;
                    }
                case 'transform':
                    {
                        var _nodeManager_getNodeFromNextOp3;
                        const target = (_nodeManager_getNodeFromNextOp3 = nodeManager.getNodeFromNextOp(node.data.namespace, op.next)) === null || _nodeManager_getNodeFromNextOp3 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp3.id;
                        if (target) {
                            addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createDefaultEdge)(node.id, null, target, null), op.next);
                        }
                        break;
                    }
                case 'fork_clone':
                    {
                        for (const next of op.next.values()){
                            var _nodeManager_getNodeFromNextOp4;
                            const target = (_nodeManager_getNodeFromNextOp4 = nodeManager.getNodeFromNextOp(node.data.namespace, next)) === null || _nodeManager_getNodeFromNextOp4 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp4.id;
                            if (target) {
                                addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createDefaultEdge)(node.id, null, target, null), next);
                            }
                        }
                        break;
                    }
                case 'unzip':
                    {
                        for (const [idx, next] of op.next.entries()){
                            var _nodeManager_getNodeFromNextOp5;
                            const target = (_nodeManager_getNodeFromNextOp5 = nodeManager.getNodeFromNextOp(node.data.namespace, next)) === null || _nodeManager_getNodeFromNextOp5 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp5.id;
                            if (target) {
                                addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createUnzipEdge)(node.id, null, target, null, {
                                    seq: idx
                                }), next);
                            }
                        }
                        break;
                    }
                case 'fork_result':
                    {
                        var _nodeManager_getNodeFromNextOp6, _nodeManager_getNodeFromNextOp7;
                        const okTarget = (_nodeManager_getNodeFromNextOp6 = nodeManager.getNodeFromNextOp(node.data.namespace, op.ok)) === null || _nodeManager_getNodeFromNextOp6 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp6.id;
                        const errTarget = (_nodeManager_getNodeFromNextOp7 = nodeManager.getNodeFromNextOp(node.data.namespace, op.err)) === null || _nodeManager_getNodeFromNextOp7 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp7.id;
                        if (okTarget) {
                            addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createForkResultOkEdge)(node.id, _handles__WEBPACK_IMPORTED_MODULE_1__.HandleId.ForkResultOk, okTarget, null), op.ok);
                        }
                        if (errTarget) {
                            addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createForkResultErrEdge)(node.id, _handles__WEBPACK_IMPORTED_MODULE_1__.HandleId.ForkResultErr, errTarget, null), op.err);
                        }
                        break;
                    }
                case 'split':
                    {
                        if (op.keyed) {
                            for (const [key, next] of Object.entries(op.keyed)){
                                var _nodeManager_getNodeFromNextOp8;
                                const target = (_nodeManager_getNodeFromNextOp8 = nodeManager.getNodeFromNextOp(node.data.namespace, next)) === null || _nodeManager_getNodeFromNextOp8 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp8.id;
                                if (target) {
                                    addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createSplitKeyEdge)(node.id, null, target, null, {
                                        key
                                    }), next);
                                }
                            }
                        }
                        if (op.sequential) {
                            for (const [idx, next] of op.sequential.entries()){
                                var _nodeManager_getNodeFromNextOp9;
                                const target = (_nodeManager_getNodeFromNextOp9 = nodeManager.getNodeFromNextOp(node.data.namespace, next)) === null || _nodeManager_getNodeFromNextOp9 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp9.id;
                                if (target) {
                                    addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createSplitSeqEdge)(node.id, null, target, null, {
                                        seq: idx
                                    }), next);
                                }
                            }
                        }
                        if (op.remaining) {
                            var _nodeManager_getNodeFromNextOp10;
                            const target = (_nodeManager_getNodeFromNextOp10 = nodeManager.getNodeFromNextOp(node.data.namespace, op.remaining)) === null || _nodeManager_getNodeFromNextOp10 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp10.id;
                            if (target) {
                                addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createSplitRemainingEdge)(node.id, null, target, null), op.remaining);
                            }
                        }
                        break;
                    }
                case 'section':
                    {
                        if (op.connect) {
                            for (const [outputId, next] of Object.entries(op.connect)){
                                var _nodeManager_getNodeFromNextOp11;
                                const target = (_nodeManager_getNodeFromNextOp11 = nodeManager.getNodeFromNextOp(node.data.namespace, next)) === null || _nodeManager_getNodeFromNextOp11 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp11.id;
                                if (target) {
                                    addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createSectionEdge)(node.id, null, target, null, {
                                        output: outputId
                                    }), next);
                                }
                            }
                        }
                        break;
                    }
                case 'scope':
                    {
                        var _nodeManager_getNodeFromNextOp12;
                        const target = (_nodeManager_getNodeFromNextOp12 = nodeManager.getNodeFromNextOp(node.data.namespace, op.next)) === null || _nodeManager_getNodeFromNextOp12 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp12.id;
                        if (target) {
                            addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createDefaultEdge)(node.id, null, target, null), op.next);
                        }
                        if (op.stream_out) {
                            edges.push(...createStreamOutEdges(op.stream_out, node, nodeManager));
                        }
                        const scopeStart = nodeManager.getNodeFromNamespaceOpId((0,_namespace__WEBPACK_IMPORTED_MODULE_5__.joinNamespaces)(node.data.namespace, opId), _nodes__WEBPACK_IMPORTED_MODULE_3__.START_ID);
                        const scopeStartTarget = nodeManager.getNodeFromNextOp((0,_namespace__WEBPACK_IMPORTED_MODULE_5__.joinNamespaces)(node.data.namespace, opId), op.start);
                        if (scopeStart && scopeStartTarget) {
                            addDataEdge((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createDefaultEdge)(scopeStart.id, null, scopeStartTarget.id, null), op.start);
                        }
                        for (const [innerOpId, innerOp] of Object.entries(op.ops)){
                            stack.push({
                                namespace: (0,_namespace__WEBPACK_IMPORTED_MODULE_5__.joinNamespaces)(node.data.namespace, opId),
                                opId: innerOpId,
                                op: innerOp
                            });
                        }
                        break;
                    }
                case 'stream_out':
                    {
                        break;
                    }
                default:
                    {
                        (0,_exhaustive_check__WEBPACK_IMPORTED_MODULE_4__.exhaustiveCheck)(op);
                        throw new Error('unknown op');
                    }
            }
        } else if (node.type === 'sectionInput' || node.type === 'sectionBuffer') {
            var _nodeManager_getNodeFromNextOp13;
            const target = (_nodeManager_getNodeFromNextOp13 = nodeManager.getNodeFromNextOp(_namespace__WEBPACK_IMPORTED_MODULE_5__.ROOT_NAMESPACE, node.data.targetId)) === null || _nodeManager_getNodeFromNextOp13 === void 0 ? void 0 : _nodeManager_getNodeFromNextOp13.id;
            if (target) {
                const edge = withTargetInput((0,_edges__WEBPACK_IMPORTED_MODULE_0__.createDefaultEdge)(node.id, null, target, null), node.data.targetId);
                if (node.type === 'sectionBuffer' && edge.data.input.type === 'sectionInput') {
                    edge.data.input = {
                        ...edge.data.input,
                        type: 'sectionBuffer'
                    };
                }
                edges.push(edge);
            }
        }
    }
    return edges;
}
function isBuiltin(next) {
    return next !== null && typeof next === 'object' && 'builtin' in next;
}
function isSectionBuilder(nodeData) {
    return 'builder' in nodeData;
}
function formatNextOperation(nextOp) {
    if (isBuiltin(nextOp)) {
        return `builtin:${nextOp.builtin}`;
    }
    if (typeof nextOp === 'object') {
        const [ns, opId] = Object.entries(nextOp)[0];
        return `${ns}:${opId}`;
    }
    return nextOp;
}


}),
712: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  addUniqueSuffix: () => (addUniqueSuffix)
});
/**
 * Returns a string that does not conflict with existing values by adding suffix to it.
 */ function addUniqueSuffix(prefix, existing) {
    let sep = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : '_';
    const set = new Set(existing);
    if (!set.has(prefix)) {
        return prefix;
    }
    for(let i = 1; i < existing.length; ++i){
        const candidate = `${prefix}${sep}${i}`;
        if (!set.has(candidate)) {
            return candidate;
        }
    }
    return `${prefix}${sep}${existing.length + 1}`;
}


}),
251: (function (module) {
module.exports = JSON.parse('{"$schema":"https://json-schema.org/draft/2020-12/schema","$defs":{"BufferAccessMetadata":{"properties":{"layout":{"$ref":"#/$defs/BufferMapLayoutHints"},"request_message":{"description":"The underlying request message type, excluding the buffer access","format":"uint","minimum":0,"type":"integer"}},"required":["request_message","layout"],"type":"object"},"BufferAccessSchema":{"description":"Zip a message together with access to one or more buffers.\\n\\nThe receiving node must have an input type of `(Message, Keys)`\\nwhere `Keys` implements the [`Accessor`][1] trait.\\n\\n[1]: crate::Accessor\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"fork_clone\\",\\n    \\"ops\\": {\\n        \\"fork_clone\\": {\\n            \\"type\\": \\"fork_clone\\",\\n            \\"next\\": [\\"num_output\\", \\"string_output\\"]\\n        },\\n        \\"num_output\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"num_output\\",\\n            \\"next\\": \\"buffer_access\\"\\n        },\\n        \\"string_output\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"string_output\\",\\n            \\"next\\": \\"string_buffer\\"\\n        },\\n        \\"string_buffer\\": {\\n            \\"type\\": \\"buffer\\"\\n        },\\n        \\"buffer_access\\": {\\n            \\"type\\": \\"buffer_access\\",\\n            \\"buffers\\": [\\"string_buffer\\"],\\n            \\"next\\": \\"with_buffer_access\\"\\n        },\\n        \\"with_buffer_access\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"with_buffer_access\\",\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```","properties":{"buffers":{"$ref":"#/$defs/BufferSelection"},"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"next":{"$ref":"#/$defs/NextOperation"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["next","buffers"],"type":"object"},"BufferMapLayoutHints":{"oneOf":[{"additionalProperties":false,"description":"The buffers in this map and their message types are not necessarily known in advance.","properties":{"dynamic":{"$ref":"#/$defs/DynamicBufferMapLayoutHints"}},"required":["dynamic"],"type":"object"},{"additionalProperties":false,"description":"The buffer identifiers and their message types are fixed in advance.","properties":{"static":{"additionalProperties":{"$ref":"#/$defs/MessageTypeHint"},"patternProperties":{"^\\\\d+$":{"$ref":"#/$defs/MessageTypeHint"}},"type":"object"}},"required":["static"],"type":"object"}]},"BufferSchema":{"description":"Create a [`Buffer`][1] which can be used to store and pull data within\\na scope.\\n\\nBy default the [`BufferSettings`][2] will keep the single last message\\npushed to the buffer. You can change that with the optional `settings`\\nproperty.\\n\\nUse the `\\"serialize\\": true` option to serialize the messages into\\n[`JsonMessage`] before they are inserted into the buffer. This\\nallows any serializable message type to be pushed into the buffer. If\\nleft unspecified, the buffer will store the specific data type that gets\\npushed into it. If the buffer inputs are not being serialized, then all\\nincoming messages being pushed into the buffer must have the same type.\\n\\n[1]: crate::Buffer\\n[2]: crate::BufferSettings\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"fork_clone\\",\\n    \\"ops\\": {\\n        \\"fork_clone\\": {\\n            \\"type\\": \\"fork_clone\\",\\n            \\"next\\": [\\"num_output\\", \\"string_output\\", \\"all_num_buffer\\", \\"serialized_num_buffer\\"]\\n        },\\n        \\"num_output\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"num_output\\",\\n            \\"next\\": \\"buffer_access\\"\\n        },\\n        \\"string_output\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"string_output\\",\\n            \\"next\\": \\"string_buffer\\"\\n        },\\n        \\"string_buffer\\": {\\n            \\"type\\": \\"buffer\\",\\n            \\"settings\\": {\\n                \\"retention\\": { \\"keep_last\\": 10 }\\n            }\\n        },\\n        \\"all_num_buffer\\": {\\n            \\"type\\": \\"buffer\\",\\n            \\"settings\\": {\\n                \\"retention\\": \\"keep_all\\"\\n            }\\n        },\\n        \\"serialized_num_buffer\\": {\\n            \\"type\\": \\"buffer\\",\\n            \\"serialize\\": true\\n        },\\n        \\"buffer_access\\": {\\n            \\"type\\": \\"buffer_access\\",\\n            \\"buffers\\": [\\"string_buffer\\"],\\n            \\"next\\": \\"with_buffer_access\\"\\n        },\\n        \\"with_buffer_access\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"with_buffer_access\\",\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```","properties":{"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"serialize":{"description":"If true, messages will be serialized before sending into the buffer.","type":"boolean"},"settings":{"$ref":"#/$defs/BufferSettings"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"type":"object"},"BufferSelection":{"anyOf":[{"additionalProperties":{"$ref":"#/$defs/NextOperation"},"type":"object"},{"items":{"$ref":"#/$defs/NextOperation"},"type":"array"}]},"BufferSettings":{"description":"Settings to describe the behavior of a buffer.","properties":{"retention":{"$ref":"#/$defs/RetentionPolicy"}},"required":["retention"],"type":"object"},"BuiltinTarget":{"oneOf":[{"const":"terminate","description":"Use the output to terminate the current scope. The value passed into\\nthis operation will be the return value of the scope.","type":"string"},{"const":"dispose","description":"Dispose of the output.","type":"string"},{"const":"cancel","description":"When triggered, cancel the current scope. If this is an inner scope of a\\nworkflow then the parent scope will see a disposal happen. If this is\\nthe root scope of a workflow then the whole workflow will cancel.\\n\\nWhen there is a path within a scope that can reach a cancel operation,\\nwe consider that scope to still be reachable. This allows you to safely\\nand reliably perform cleanup actions along the path to a cancellation.\\nHowever this also means that if any part of a scope can reach a cancel\\noperation then the scope will keep running, even if that part of the\\nworkflow far removed from the intended happy path of the workflow.\\nConsider using implicit cancel if you do not want the cancellation to\\naffect the lifespan of the scope.","type":"string"},{"const":"implicit_cancel","description":"Same as cancel, except using this will not affect the lifespan of the\\nscope.","type":"string"}]},"CompatibilityConnection":{"properties":{"focusPorts":{"default":[],"items":{"$ref":"#/$defs/PortRef"},"type":"array"},"id":{"type":"string"},"sourcePort":{"anyOf":[{"$ref":"#/$defs/PortRef"},{"type":"null"}]},"targetPort":{"anyOf":[{"$ref":"#/$defs/PortRef"},{"type":"null"}]}},"required":["id"],"type":"object"},"CompatibilityRequest":{"properties":{"connections":{"items":{"$ref":"#/$defs/CompatibilityConnection"},"type":"array"},"diagram":{"$ref":"#/$defs/Diagram"}},"required":["diagram","connections"],"type":"object"},"CompatibilityResponse":{"properties":{"results":{"items":{"$ref":"#/$defs/CompatibilityResult"},"type":"array"}},"required":["results"],"type":"object"},"CompatibilityResult":{"properties":{"id":{"type":"string"},"provisional":{"type":"boolean"},"reason":{"type":"string"},"sourceType":{"type":["string","null"]},"status":{"$ref":"#/$defs/CompatibilityStatus"},"targetType":{"type":["string","null"]}},"required":["id","status","reason"],"type":"object"},"CompatibilityStatus":{"enum":["compatible","incompatible","unknown"],"type":"string"},"ConfigExample":{"properties":{"config":{"description":"The value of the config"},"description":{"description":"A description of what this config is for","type":"string"}},"required":["description","config"],"type":"object"},"Diagram":{"properties":{"default_trace":{"$ref":"#/$defs/TraceToggle"},"description":{"description":"Optional text to describe the workflow.","type":"string"},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"input_examples":{"description":"Examples of inputs that can be used with this workflow.","items":{"$ref":"#/$defs/InputExample"},"type":"array"},"on_implicit_error":{"anyOf":[{"$ref":"#/$defs/NextOperation"},{"type":"null"}]},"ops":{"additionalProperties":{"$ref":"#/$defs/DiagramOperation"},"description":"Operations that define the workflow","type":"object"},"script_environments":{"additionalProperties":{"$ref":"#/$defs/ScriptEnvironmentSchema"},"default":{},"description":"Custom script environments used by this diagram.\\n\\nTo run a script operation you will need to specify what its environment\\nis. A script environment determines the language and interpreter for the\\nscript, as well as any other factors specific to the environment.\\n\\nScript environment builders may have automatic configs, which you should\\nconsider using before creating a custom environment.","type":"object"},"start":{"$ref":"#/$defs/NextOperation"},"templates":{"additionalProperties":{"$ref":"#/$defs/SectionTemplate"},"default":{},"description":"Section templates used by this diagram.","type":"object"},"version":{"description":"Version of the diagram, should always be `0.1.0`.","type":"string"}},"required":["version","start","ops"],"type":"object"},"DiagramElementMetadata":{"properties":{"messages":{"items":{"$ref":"#/$defs/MessageMetadata"},"type":"array"},"nodes":{"additionalProperties":{"$ref":"#/$defs/NodeMetadata"},"type":"object"},"reverse_message_lookup":{"$ref":"#/$defs/ReverseMessageLookup"},"schemas":{"additionalProperties":true,"type":"object"},"scripting":{"additionalProperties":{"$ref":"#/$defs/ScriptEnvironmentMetadata"},"type":"object"},"sections":{"additionalProperties":{"$ref":"#/$defs/SectionMetadata"},"type":"object"},"trace_supported":{"type":"boolean"}},"required":["nodes","sections","scripting","messages","schemas","reverse_message_lookup","trace_supported"],"type":"object"},"DiagramOperation":{"oneOf":[{"allOf":[{"$ref":"#/$defs/NodeSchema"},{"properties":{"type":{"const":"node","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/SectionSchema"},{"properties":{"type":{"const":"section","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/ScopeSchema"},{"properties":{"type":{"const":"scope","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/StreamOutSchema"},{"properties":{"type":{"const":"stream_out","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/ForkCloneSchema"},{"properties":{"type":{"const":"fork_clone","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/UnzipSchema"},{"properties":{"type":{"const":"unzip","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/ForkResultSchema"},{"properties":{"type":{"const":"fork_result","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/SplitSchema"},{"properties":{"type":{"const":"split","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/JoinSchema"},{"properties":{"type":{"const":"join","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/TransformSchema"},{"properties":{"type":{"const":"transform","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/BufferSchema"},{"properties":{"type":{"const":"buffer","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/BufferAccessSchema"},{"properties":{"type":{"const":"buffer_access","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/ListenSchema"},{"properties":{"type":{"const":"listen","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"$ref":"#/$defs/ScriptSchema"},{"properties":{"type":{"const":"script","type":"string"}},"required":["type"],"type":"object"}]}]},"DynamicBufferMapLayoutHints":{"properties":{"hint":{"anyOf":[{"$ref":"#/$defs/MessageTypeHint"},{"type":"null"}]},"indices":{"description":"The buffer identifiers can include indices.","type":"boolean"},"names":{"description":"The buffer identifiers can include names.","type":"boolean"}},"required":["indices","names"],"type":"object"},"ForkCloneSchema":{"description":"If the request is cloneable, clone it into multiple responses that can\\neach be sent to a different operation. The `next` property is an array.\\n\\nThis creates multiple simultaneous branches of execution within the\\nworkflow. Usually when you have multiple branches you will either\\n* race - connect all branches to `terminate` and the first branch to\\n  finish \\"wins\\" the race and gets to the be output\\n* join - connect each branch into a buffer and then use the `join`\\n  operation to reunite them\\n* collect - TODO(@mxgrey): [add the collect operation](https://github.com/open-rmf/crossflow/issues/59)\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"begin_race\\",\\n    \\"ops\\": {\\n        \\"begin_race\\": {\\n            \\"type\\": \\"fork_clone\\",\\n            \\"next\\": [\\n                \\"ferrari\\",\\n                \\"mustang\\"\\n            ]\\n        },\\n        \\"ferrari\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"drive\\",\\n            \\"config\\": \\"ferrari\\",\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" }\\n        },\\n        \\"mustang\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"drive\\",\\n            \\"config\\": \\"mustang\\",\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())","properties":{"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"next":{"items":{"$ref":"#/$defs/NextOperation"},"type":"array"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["next"],"type":"object"},"ForkResultSchema":{"description":"If the request is a [`Result<T, E>`], send the output message down an\\n`ok` branch or down an `err` branch depending on whether the result has\\nan [`Ok`] or [`Err`] value. The `ok` branch will receive a `T` while the\\n`err` branch will receive an `E`.\\n\\nOnly one branch will be activated by each input message that enters the\\noperation.\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"fork_result\\",\\n    \\"ops\\": {\\n        \\"fork_result\\": {\\n            \\"type\\": \\"fork_result\\",\\n            \\"ok\\": { \\"builtin\\": \\"terminate\\" },\\n            \\"err\\": { \\"builtin\\": \\"dispose\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```","properties":{"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"err":{"$ref":"#/$defs/NextOperation"},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"ok":{"$ref":"#/$defs/NextOperation"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["ok","err"],"type":"object"},"IdentifierRef":{"anyOf":[{"description":"Identify by a name","type":"string"},{"description":"Identify by an index value","format":"uint","minimum":0,"type":"integer"}]},"InputExample":{"properties":{"description":{"type":"string"},"value":true},"required":["value","description"],"type":"object"},"InputRemapping":{"anyOf":[{"description":"Do a simple 1:1 forwarding of the names listed in the array","items":{"type":"string"},"type":"array"},{"additionalProperties":{"$ref":"#/$defs/NextOperation"},"description":"Rename an operation inside the section to expose it externally. The key\\nof the map is what siblings of the section can connect to, and the value\\nof the entry is the identifier of the input inside the section that is\\nbeing exposed.\\n\\nThis allows a section to expose inputs and buffers that are provided\\nby inner sections.","type":"object"}]},"InteractionSessionMessage":{"oneOf":[{"allOf":[{"oneOf":[{"properties":{"operationStarted":{"type":"string"}},"required":["operationStarted"],"type":"object"},{"properties":{"operationFinished":{"type":"string"}},"required":["operationFinished"],"type":"object"}]},{"properties":{"type":{"const":"feedback","type":"string"}},"required":["type"],"type":"object"}]},{"allOf":[{"oneOf":[{"properties":{"ok":true},"required":["ok"],"type":"object"},{"properties":{"err":{"type":"string"}},"required":["err"],"type":"object"}]},{"properties":{"type":{"const":"finish","type":"string"}},"required":["type"],"type":"object"}]}]},"JoinSchema":{"description":"Wait for exactly one item to be available in each buffer listed in\\n`buffers`, then join each of those items into a single output message\\nthat gets sent to `next`.\\n\\nIf the `next` operation is not a `node` type (e.g. `fork_clone`) then\\nyou must specify a `target_node` so that the diagram knows what data\\nstructure to join the values into.\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"begin_measuring\\",\\n    \\"ops\\": {\\n        \\"begin_measuring\\": {\\n            \\"type\\": \\"fork_clone\\",\\n            \\"next\\": [\\"localize\\", \\"imu\\"]\\n        },\\n        \\"localize\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"localize\\",\\n            \\"next\\": \\"estimated_position\\"\\n        },\\n        \\"imu\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"imu\\",\\n            \\"config\\": \\"velocity\\",\\n            \\"next\\": \\"estimated_velocity\\"\\n        },\\n        \\"estimated_position\\": { \\"type\\": \\"buffer\\" },\\n        \\"estimated_velocity\\": { \\"type\\": \\"buffer\\" },\\n        \\"gather_state\\": {\\n            \\"type\\": \\"join\\",\\n            \\"buffers\\": {\\n                \\"position\\": \\"estimate_position\\",\\n                \\"velocity\\": \\"estimate_velocity\\"\\n            },\\n            \\"next\\": \\"report_state\\"\\n        },\\n        \\"report_state\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"publish_state\\",\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```","properties":{"buffers":{"$ref":"#/$defs/BufferSelection"},"clone":{"description":"List of the keys in the `buffers` dictionary whose value should be cloned\\ninstead of removed from the buffer (pulled) when the join occurs. Cloning\\nthe value will leave the buffer unchanged after the join operation takes\\nplace.","items":{"$ref":"#/$defs/IdentifierRef"},"type":"array"},"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"next":{"$ref":"#/$defs/NextOperation"},"serialize":{"description":"Whether or not to automatically serialize the inputs into a single JsonMessage.\\nThis will only work if all input types are serializable, otherwise you will\\nget a [`DiagramError`][super::DiagramError].","type":"boolean"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["next","buffers"],"type":"object"},"ListenSchema":{"description":"Listen on a buffer.\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"num_output\\",\\n    \\"ops\\": {\\n        \\"buffer\\": {\\n            \\"type\\": \\"buffer\\"\\n        },\\n        \\"num_output\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"num_output\\",\\n            \\"next\\": \\"buffer\\"\\n        },\\n        \\"listen\\": {\\n            \\"type\\": \\"listen\\",\\n            \\"buffers\\": [\\"buffer\\"],\\n            \\"next\\": \\"listen_buffer\\"\\n        },\\n        \\"listen_buffer\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"listen_buffer\\",\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())","properties":{"buffers":{"$ref":"#/$defs/BufferSelection"},"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"next":{"$ref":"#/$defs/NextOperation"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["next","buffers"],"type":"object"},"MessageMetadata":{"properties":{"operations":{"anyOf":[{"$ref":"#/$defs/MessageOperationsMetadata"},{"type":"null"}]},"schema":{"anyOf":[{"$ref":"#/$defs/Schema"},{"type":"null"}]},"type_name":{"type":"string"}},"required":["type_name"],"type":"object"},"MessageOperationsMetadata":{"properties":{"buffer_access":{"anyOf":[{"$ref":"#/$defs/BufferAccessMetadata"},{"type":"null"}]},"deserialize":{"type":["object","null"]},"fork_clone":{"type":["object","null"]},"fork_result":{"items":{"format":"uint","minimum":0,"type":"integer"},"maxItems":2,"minItems":2,"type":["array","null"]},"from":{"items":{"format":"uint","minimum":0,"type":"integer"},"type":"array","uniqueItems":true},"from_script_message":{"type":["object","null"]},"into":{"items":{"format":"uint","minimum":0,"type":"integer"},"type":"array","uniqueItems":true},"into_script_message":{"type":["object","null"]},"join":{"anyOf":[{"$ref":"#/$defs/BufferMapLayoutHints"},{"type":"null"}]},"listen":{"anyOf":[{"$ref":"#/$defs/BufferMapLayoutHints"},{"type":"null"}]},"serialize":{"type":["object","null"]},"split":{"format":"uint","minimum":0,"type":["integer","null"]},"try_from":{"items":{"format":"uint","minimum":0,"type":"integer"},"type":"array","uniqueItems":true},"try_into":{"items":{"format":"uint","minimum":0,"type":"integer"},"type":"array","uniqueItems":true},"unzip":{"items":{"format":"uint","minimum":0,"type":"integer"},"type":["array","null"]}},"required":["into","try_into","from","try_from"],"type":"object"},"MessageTypeHint":{"oneOf":[{"additionalProperties":false,"description":"An accessor is asking specifically for this type T via `BufferKey<T>`","properties":{"exact":{"format":"uint","minimum":0,"type":"integer"}},"required":["exact"],"type":"object"},{"additionalProperties":false,"description":"An accessor is using a generalized buffer, e.g. JsonBuffer or AnyBuffer,\\nwhich can be represented by this type, but an exact type should be used\\nif any other accessor has one.","properties":{"fallback":{"format":"uint","minimum":0,"type":"integer"}},"required":["fallback"],"type":"object"}]},"NamedOperationRef":{"properties":{"exposed_namespace":{"description":"If this references an exposed operation, such as an exposed input or\\noutput of a session, this will contain the session name. Suppose we have\\na section named `sec` and it has an exposed output named `out`. Then\\nthere are two values of `NamedOperationRef` to consider:\\n\\n```\\n# use crossflow::diagram::{NamedOperationRef, NamespaceList};\\n# use smallvec::smallvec;\\n\\nlet op_id = NamedOperationRef {\\n    namespaces: NamespaceList::for_child_of(\\"sec\\".into()),\\n    exposed_namespace: None,\\n    name: \\"out\\".into(),\\n};\\n```\\n\\nis the internal reference to `sec:out` that will be used by other\\noperations inside of `sec`. On the other hand, operations that are\\nsiblings of `sec` would instead connect to\\n\\n```\\n# use crossflow::diagram::NamedOperationRef;\\n# use smallvec::smallvec;\\n\\nlet op_id = NamedOperationRef {\\n    namespaces: Default::default(),\\n    exposed_namespace: Some(\\"sec\\".into()),\\n    name: \\"out\\".into(),\\n};\\n```\\n\\nWe need to make this distinction because operations inside `sec` do not\\nknow which of their siblings are exposed, and we don\'t want operations\\noutside of `sec` to accidentally connect to operations that are supposed\\nto be internal to `sec`.","type":["string","null"]},"name":{"type":"string"},"namespaces":{"$ref":"#/$defs/NamespaceList"}},"required":["namespaces","name"],"type":"object"},"NamedOutputRef":{"properties":{"key":{"$ref":"#/$defs/OutputKey"},"namespaces":{"$ref":"#/$defs/NamespaceList"},"operation":{"description":"The name of the output\'s operation within the scope of the namespaces","type":"string"}},"required":["namespaces","operation","key"],"type":"object"},"NamespaceList":{"items":{"type":"string"},"type":"array"},"NamespacedOperation":{"additionalProperties":{"type":"string"},"description":"Refer to an operation inside of a namespace, e.g. { \\"<namespace>\\": \\"<operation>\\"","maxProperties":1,"minProperties":1,"title":"NamespacedOperation","type":"object"},"NextOperation":{"anyOf":[{"type":"string"},{"properties":{"builtin":{"$ref":"#/$defs/BuiltinTarget"}},"required":["builtin"],"type":"object"},{"$ref":"#/$defs/NamespacedOperation"}]},"NodeMetadata":{"properties":{"config_examples":{"items":{"$ref":"#/$defs/ConfigExample"},"type":"array"},"config_schema":{"$ref":"#/$defs/Schema"},"default_display_text":{"description":"If the user does not specify a default display text, the node ID will\\nbe used here.","type":"string"},"description":{"type":["string","null"]},"request":{"format":"uint","minimum":0,"type":"integer"},"response":{"format":"uint","minimum":0,"type":"integer"},"streams":{"additionalProperties":{"format":"uint","minimum":0,"type":"integer"},"type":"object"}},"required":["default_display_text","request","response","streams","config_schema","config_examples"],"type":"object"},"NodeSchema":{"description":"Create an operation that that takes an input message and produces an\\noutput message.\\n\\nThe behavior is determined by the choice of node `builder` and\\noptionally the `config` that you provide. Each type of node builder has\\nits own schema for the config.\\n\\nThe output message will be sent to the operation specified by `next`.\\n\\nTODO(@mxgrey): [Support stream outputs](https://github.com/open-rmf/crossflow/issues/43)\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"cutting_board\\",\\n    \\"ops\\": {\\n        \\"cutting_board\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"chop\\",\\n            \\"config\\": \\"diced\\",\\n            \\"next\\": \\"bowl\\"\\n        },\\n        \\"bowl\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"stir\\",\\n            \\"next\\": \\"oven\\"\\n        },\\n        \\"oven\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"bake\\",\\n            \\"config\\": {\\n                \\"temperature\\": 200,\\n                \\"duration\\": 120\\n            },\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())","properties":{"builder":{"type":"string"},"config":true,"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"next":{"$ref":"#/$defs/NextOperation"},"stream_out":{"additionalProperties":{"$ref":"#/$defs/NextOperation"},"type":"object"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["builder","next"],"type":"object"},"OperationRef":{"oneOf":[{"enum":["dispose"],"type":"string"},{"additionalProperties":false,"properties":{"named":{"$ref":"#/$defs/NamedOperationRef"}},"required":["named"],"type":"object"},{"additionalProperties":false,"properties":{"terminate":{"$ref":"#/$defs/NamespaceList"}},"required":["terminate"],"type":"object"},{"additionalProperties":false,"properties":{"cancel":{"$ref":"#/$defs/NamespaceList"}},"required":["cancel"],"type":"object"},{"additionalProperties":false,"properties":{"implicit_cancel":{"$ref":"#/$defs/NamespaceList"}},"required":["implicit_cancel"],"type":"object"},{"additionalProperties":false,"properties":{"stream_out":{"$ref":"#/$defs/StreamOutRef"}},"required":["stream_out"],"type":"object"}]},"OutputKey":{"items":{"oneOf":[{"type":"string"},{"type":"number"}]},"type":"array"},"OutputRef":{"oneOf":[{"additionalProperties":false,"properties":{"Named":{"$ref":"#/$defs/NamedOutputRef"}},"required":["Named"],"type":"object"},{"additionalProperties":false,"properties":{"Start":{"$ref":"#/$defs/NamespaceList"}},"required":["Start"],"type":"object"}]},"PortRef":{"oneOf":[{"additionalProperties":false,"properties":{"Input":{"$ref":"#/$defs/OperationRef"}},"required":["Input"],"type":"object"},{"additionalProperties":false,"properties":{"Output":{"$ref":"#/$defs/OutputRef"}},"required":["Output"],"type":"object"}]},"PostRunRequest":{"properties":{"diagram":{"$ref":"#/$defs/Diagram"},"request":true},"required":["diagram","request"],"type":"object"},"RetentionPolicy":{"oneOf":[{"additionalProperties":false,"description":"Keep the last N items that were stored into the buffer. Once the limit\\nis reached, the oldest item will be removed any time a new item arrives.","properties":{"keep_last":{"format":"uint","minimum":0,"type":"integer"}},"required":["keep_last"],"type":"object"},{"additionalProperties":false,"description":"Keep the first N items that are stored into the buffer. Once the limit\\nis reached, any new item that arrives will be discarded.","properties":{"keep_first":{"format":"uint","minimum":0,"type":"integer"}},"required":["keep_first"],"type":"object"},{"const":"keep_all","description":"Do not limit how many items can be stored in the buffer.","type":"string"}]},"ReverseMessageLookup":{"properties":{"json_message":{"description":"The index where the [`JsonMessage`] type is registered.","format":"uint","minimum":0,"type":["integer","null"]},"result":{"description":"Map from [T, E] output registrations to Result<T, E> registration.","items":{"maxItems":2,"minItems":2,"prefixItems":[{"items":{"format":"uint","minimum":0,"type":"integer"},"maxItems":2,"minItems":2,"type":"array"},{"format":"uint","minimum":0,"type":"integer"}],"type":"array"},"type":"array"},"script_message":{"format":"uint","minimum":0,"type":["integer","null"]},"split":{"description":"Map from the message type of the item that comes out of a split to all\\nmessage types that can be split into it.","items":{"maxItems":2,"minItems":2,"prefixItems":[{"format":"uint","minimum":0,"type":"integer"},{"items":{"format":"uint","minimum":0,"type":"integer"},"type":"array"}],"type":"array"},"type":"array"},"unzip":{"description":"Map from the unzipped types to the original zipped type.","items":{"maxItems":2,"minItems":2,"prefixItems":[{"items":{"format":"uint","minimum":0,"type":"integer"},"type":"array"},{"format":"uint","minimum":0,"type":"integer"}],"type":"array"},"type":"array"}},"required":["result","unzip","split"],"type":"object"},"Schema":{"type":["object","boolean"]},"ScopeSchema":{"description":"Create a scope which will function like its own encapsulated workflow\\nwithin the paren workflow. Each message that enters a scope will trigger\\na new independent session for that scope to begin running with the incoming\\nmessage itself being the input message of the scope. When multiple sessions\\nfor the same scope are running, they cannot see or interfere with each other.\\n\\nOnce a session terminates, the scope will send the terminating message as\\nits output. Scopes can use the `stream_out` operation to stream messages out\\nto the parent workflow while running.\\n\\nScopes have two common uses:\\n* isolate - Prevent simultaneous runs of the same workflow components\\n  (especially buffers) from interfering with each other.\\n* race - Run multiple branches simultaneously inside the scope and race\\n  them against each ohter. The first branch that reaches the scope\'s\\n  terminate operation \\"wins\\" the race, and only its output will continue\\n  on in the parent workflow. All other branches will be disposed.\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"approach_door\\",\\n    \\"ops\\": {\\n        \\"approach_door\\": {\\n            \\"type\\": \\"scope\\",\\n            \\"start\\": \\"begin\\",\\n            \\"ops\\": {\\n                \\"begin\\": {\\n                    \\"type\\": \\"fork_clone\\",\\n                    \\"next\\": [\\n                        \\"move_to_door\\",\\n                        \\"detect_door_proximity\\"\\n                    ]\\n                },\\n                \\"move_to_door\\": {\\n                    \\"type\\": \\"node\\",\\n                    \\"builder\\": \\"move\\",\\n                    \\"config\\": {\\n                        \\"place\\": \\"L1_north_lobby_outside\\"\\n                    },\\n                    \\"next\\": { \\"builtin\\" : \\"terminate\\" }\\n                },\\n                \\"detect_proximity\\": {\\n                    \\"type\\": \\"node\\",\\n                    \\"builder\\": \\"detect_proximity\\",\\n                    \\"config\\": {\\n                        \\"type\\": \\"door\\",\\n                        \\"name\\": \\"L1_north_lobby\\"\\n                    },\\n                    \\"next\\": { \\"builtin\\" : \\"terminate\\" }\\n                }\\n            },\\n            \\"next\\": { \\"builtin\\" : \\"try_open_door\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```","properties":{"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"next":{"$ref":"#/$defs/NextOperation"},"on_implicit_error":{"anyOf":[{"$ref":"#/$defs/NextOperation"},{"type":"null"}]},"ops":{"additionalProperties":{"$ref":"#/$defs/DiagramOperation"},"description":"Operations that exist inside this scope.","type":"object"},"settings":{"$ref":"#/$defs/ScopeSettings"},"start":{"$ref":"#/$defs/NextOperation"},"stream_out":{"additionalProperties":{"$ref":"#/$defs/NextOperation"},"default":{},"description":"Where to connect streams that are coming out of this scope.","type":"object"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["start","ops","next"],"type":"object"},"ScopeSettings":{"description":"Settings which determine how the top-level scope of the workflow behaves.","properties":{"uninterruptible":{"description":"Should we prevent the scope from being interrupted (e.g. cancelled)?\\nFalse by default, meaning by default scopes can be cancelled or\\ninterrupted.","type":"boolean"}},"required":["uninterruptible"],"type":"object"},"ScriptConfigExample":{"description":"An example of how to configure an environment","properties":{"config":{"description":"The example configuration"},"description":{"description":"A description of this example","type":"string"},"name":{"description":"The name of this example","type":"string"},"run":{"description":"How to run this example environment, i.e. what goes into the `run` field\\nof the [`ScriptSchema`][1].\\n\\n[1]: crate::ScriptSchema","type":"string"}},"required":["name","description","config","run"],"type":"object"},"ScriptEnvironmentMetadata":{"properties":{"config_examples":{"description":"Examples of valid configurations for this builder","items":{"$ref":"#/$defs/ScriptConfigExample"},"type":"array"},"config_schema":{"$ref":"#/$defs/Schema"},"description":{"description":"A description of what kind of environments are made by this builder","type":["string","null"]},"display_text":{"description":"Human-friendly name for the script environment builder","type":["string","null"]},"interpreter":{"description":"The interpreter that will be used to process the scripting language","type":"string"},"language":{"description":"The scripting language that will be used for this environment","type":"string"}},"required":["language","interpreter","config_schema","config_examples"],"type":"object"},"ScriptEnvironmentSchema":{"description":"Description of a scripting environment that a diagram uses to run scripts.","properties":{"builder":{"type":"string"},"config":true},"required":["builder","config"],"type":"object"},"ScriptSchema":{"description":"Settings that describe how an operation should be traced. It is recommended\\nto add this to each operation with #[serde(flatten)].","properties":{"config":{"description":"Configured data to pass into the function that `run` refers to. This will\\nbe passed in as a keyword argument named `config`."},"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"environment":{"description":"Name of the environment that will be used to execute this script operation.","type":"string"},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"next":{"$ref":"#/$defs/NextOperation"},"on_error":{"anyOf":[{"$ref":"#/$defs/NextOperation"},{"type":"null"}]},"run":{"description":"What to run in the environment","type":"string"},"stream_out":{"additionalProperties":{"$ref":"#/$defs/NextOperation"},"description":"A map from the name of a stream to the operation that its outputs should\\nbe passed to.","type":"object"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["environment","run","next"],"type":"object"},"SectionBuffer":{"properties":{"message_type":{"format":"uint","minimum":0,"type":["integer","null"]}},"type":"object"},"SectionInput":{"properties":{"message_type":{"format":"uint","minimum":0,"type":"integer"}},"required":["message_type"],"type":"object"},"SectionInterface":{"properties":{"buffers":{"additionalProperties":{"$ref":"#/$defs/SectionBuffer"},"type":"object"},"inputs":{"additionalProperties":{"$ref":"#/$defs/SectionInput"},"type":"object"},"outputs":{"additionalProperties":{"$ref":"#/$defs/SectionOutput"},"type":"object"}},"required":["inputs","outputs","buffers"],"type":"object"},"SectionMetadata":{"properties":{"config_examples":{"items":{"$ref":"#/$defs/ConfigExample"},"type":"array"},"config_schema":{"$ref":"#/$defs/Schema"},"default_display_text":{"type":"string"},"description":{"type":["string","null"]},"interface":{"$ref":"#/$defs/SectionInterface"}},"required":["default_display_text","interface","config_schema","config_examples"],"type":"object"},"SectionOutput":{"properties":{"message_type":{"format":"uint","minimum":0,"type":"integer"}},"required":["message_type"],"type":"object"},"SectionSchema":{"allOf":[{"oneOf":[{"properties":{"builder":{"type":"string"}},"required":["builder"],"type":"object"},{"properties":{"template":{"type":"string"}},"required":["template"],"type":"object"}]},{"description":"Connect the request to a registered section.\\n\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"section_op\\",\\n    \\"ops\\": {\\n        \\"section_op\\": {\\n            \\"type\\": \\"section\\",\\n            \\"builder\\": \\"my_section_builder\\",\\n            \\"connect\\": {\\n                \\"my_section_output\\": { \\"builtin\\": \\"terminate\\" }\\n            }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```\\n\\nCustom sections can also be created via templates\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"templates\\": {\\n        \\"my_template\\": {\\n            \\"inputs\\": [\\"section_input\\"],\\n            \\"outputs\\": [\\"section_output\\"],\\n            \\"buffers\\": [],\\n            \\"ops\\": {\\n                \\"section_input\\": {\\n                    \\"type\\": \\"node\\",\\n                    \\"builder\\": \\"my_node\\",\\n                    \\"next\\": \\"section_output\\"\\n                }\\n            }\\n        }\\n    },\\n    \\"start\\": \\"section_op\\",\\n    \\"ops\\": {\\n        \\"section_op\\": {\\n            \\"type\\": \\"section\\",\\n            \\"template\\": \\"my_template\\",\\n            \\"connect\\": {\\n                \\"section_output\\": { \\"builtin\\": \\"terminate\\" }\\n            }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```","properties":{"config":{"default":null},"connect":{"additionalProperties":{"$ref":"#/$defs/NextOperation"},"default":{},"type":"object"},"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"type":"object"}]},"SectionTemplate":{"properties":{"buffers":{"$ref":"#/$defs/InputRemapping"},"inputs":{"$ref":"#/$defs/InputRemapping"},"ops":{"additionalProperties":{"$ref":"#/$defs/DiagramOperation"},"description":"Operations that define the behavior of the section.","type":"object"},"outputs":{"default":[],"description":"These are the outputs that the section is exposing so you can connect\\nthem into siblings of the section.","items":{"type":"string"},"type":"array"}},"required":["ops"],"type":"object"},"SplitSchema":{"description":"If the input message is a list-like or map-like object, split it into\\nmultiple output messages.\\n\\nNote that the type of output message from the split depends on how the\\ninput message implements the [`Splittable`][1] trait. In many cases this\\nwill be a tuple of `(key, value)`.\\n\\nThere are three ways to specify where the split output messages should\\ngo, and all can be used at the same time:\\n* `sequential` - For array-like collections, send the \\"first\\" element of\\n  the collection to the first operation listed in the `sequential` array.\\n  The \\"second\\" element of the collection goes to the second operation\\n  listed in the `sequential` array. And so on for all elements in the\\n  collection. If one of the elements in the collection is mentioned in\\n  the `keyed` set, then the sequence will pass over it as if the element\\n  does not exist at all.\\n* `keyed` - For map-like collections, send the split element associated\\n  with the specified key to its associated output.\\n* `remaining` - Any elements that are were not captured by `sequential`\\n  or by `keyed` will be sent to this.\\n\\n[1]: crate::Splittable\\n\\n# Examples\\n\\nSuppose I am an animal rescuer sorting through a new collection of\\nanimals that need recuing. My home has space for three exotic animals\\nplus any number of dogs and cats.\\n\\nI have a custom `SpeciesCollection` data structure that implements\\n[`Splittable`][1] by allowing you to key on the type of animal.\\n\\nIn the workflow below, we send all cats and dogs to `home`, and we also\\nsend the first three non-dog and non-cat species to `home`. All\\nremaining animals go to the zoo.\\n\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"select_animals\\",\\n    \\"ops\\": {\\n        \\"select_animals\\": {\\n            \\"type\\": \\"split\\",\\n            \\"sequential\\": [\\n                \\"home\\",\\n                \\"home\\",\\n                \\"home\\"\\n            ],\\n            \\"keyed\\": {\\n                \\"cat\\": \\"home\\",\\n                \\"dog\\": \\"home\\"\\n            },\\n            \\"remaining\\": \\"zoo\\"\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```\\n\\nIf we input `[\\"frog\\", \\"cat\\", \\"bear\\", \\"beaver\\", \\"dog\\", \\"rabbit\\", \\"dog\\", \\"monkey\\"]`\\nthen `frog`, `bear`, and `beaver` will be sent to `home` since those are\\nthe first three animals that are not `dog` or `cat`, and we will also\\nsend one `cat` and two `dog` home. `rabbit` and `monkey` will be sent to the zoo.","properties":{"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"keyed":{"additionalProperties":{"$ref":"#/$defs/NextOperation"},"type":"object"},"remaining":{"anyOf":[{"$ref":"#/$defs/NextOperation"},{"type":"null"}]},"sequential":{"items":{"$ref":"#/$defs/NextOperation"},"type":"array"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"type":"object"},"StreamOutRef":{"properties":{"name":{"description":"The name of the stream (within its scope) that is being referred to","type":"string"},"namespaces":{"$ref":"#/$defs/NamespaceList"}},"required":["namespaces","name"],"type":"object"},"StreamOutSchema":{"description":"Declare a stream output for the current scope. Outputs that you connect\\nto this operation will be streamed out of the scope that this operation\\nis declared in.\\n\\nFor the root-level scope, make sure you use a stream pack that is\\ncompatible with all stream out operations that you declare, otherwise\\nyou may get a connection error at runtime.\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"plan\\",\\n    \\"ops\\": {\\n        \\"progress_stream\\": {\\n            \\"type\\": \\"stream_out\\",\\n            \\"name\\": \\"progress\\"\\n        },\\n        \\"plan\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"planner\\",\\n            \\"next\\": \\"drive\\",\\n            \\"stream_out\\" : {\\n                \\"progress\\": \\"progress_stream\\"\\n            }\\n        },\\n        \\"drive\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"navigation\\",\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" },\\n            \\"stream_out\\": {\\n                \\"progress\\": \\"progress_stream\\"\\n            }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```","properties":{"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"name":{"description":"The name of the stream exiting the workflow or scope.","type":"string"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["name"],"type":"object"},"TraceToggle":{"oneOf":[{"const":"off","description":"Do not emit any signal when the operation is activated.","type":"string"},{"const":"on","description":"Emit a minimal signal with just the operation information when the\\noperation is activated.","type":"string"},{"const":"messages","description":"Emit a signal that includes a serialized copy of the message when the\\noperation is activated. This may substantially increase the overhead of\\ntriggering operations depending on the size and frequency of the messages,\\nso it is recommended only for high-level workflows or for debugging.\\n\\nIf the message is not serializable then it will simply not be included\\nin the event information.","type":"string"}]},"TransformSchema":{"description":"If the request is serializable, transform it by running it through a [CEL](https://cel.dev/) program.\\nThe context includes a \\"request\\" variable which contains the input message.\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"transform\\",\\n    \\"ops\\": {\\n        \\"transform\\": {\\n            \\"type\\": \\"transform\\",\\n            \\"cel\\": \\"request.name\\",\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```\\n\\nNote that due to how `serde_json` performs serialization, positive integers are always\\nserialized as unsigned. In CEL, You can\'t do an operation between unsigned and signed so\\nit is recommended to always perform explicit casts.\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"transform\\",\\n    \\"ops\\": {\\n        \\"transform\\": {\\n            \\"type\\": \\"transform\\",\\n            \\"cel\\": \\"int(request.score) * 3\\",\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```","properties":{"cel":{"type":"string"},"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"next":{"$ref":"#/$defs/NextOperation"},"on_error":{"anyOf":[{"$ref":"#/$defs/NextOperation"},{"type":"null"}]},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["cel","next"],"type":"object"},"UnzipSchema":{"description":"If the input message is a tuple of (T1, T2, T3, ...), unzip it into\\nmultiple output messages of T1, T2, T3, ...\\n\\nEach output message may have a different type and can be sent to a\\ndifferent operation. This creates multiple simultaneous branches of\\nexecution within the workflow. See [`DiagramOperation::ForkClone`] for\\nmore information on parallel branches.\\n\\n# Examples\\n```\\n# crossflow::Diagram::from_json_str(r#\\"\\n{\\n    \\"version\\": \\"0.1.0\\",\\n    \\"start\\": \\"name_phone_address\\",\\n    \\"ops\\": {\\n        \\"name_phone_address\\": {\\n            \\"type\\": \\"unzip\\",\\n            \\"next\\": [\\n                \\"process_name\\",\\n                \\"process_phone_number\\",\\n                \\"process_address\\"\\n            ]\\n        },\\n        \\"process_name\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"process_name\\",\\n            \\"next\\": \\"name_processed\\"\\n        },\\n        \\"process_phone_number\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"process_phone_number\\",\\n            \\"next\\": \\"phone_number_processed\\"\\n        },\\n        \\"process_address\\": {\\n            \\"type\\": \\"node\\",\\n            \\"builder\\": \\"process_address\\",\\n            \\"next\\": \\"address_processed\\"\\n        },\\n        \\"name_processed\\": { \\"type\\": \\"buffer\\" },\\n        \\"phone_number_processed\\": { \\"type\\": \\"buffer\\" },\\n        \\"address_processed\\": { \\"type\\": \\"buffer\\" },\\n        \\"finished\\": {\\n            \\"type\\": \\"join\\",\\n            \\"buffers\\": [\\n                \\"name_processed\\",\\n                \\"phone_number_processed\\",\\n                \\"address_processed\\"\\n            ],\\n            \\"next\\": { \\"builtin\\": \\"terminate\\" }\\n        }\\n    }\\n}\\n# \\"#)?;\\n# Ok::<_, serde_json::Error>(())\\n```\\n\\n[`DiagramOperation::ForkClone`]: super::DiagramOperation::ForkClone","properties":{"display_text":{"description":"Override for text that should be displayed for an operation within an\\neditor.","type":["string","null"]},"extensions":{"additionalProperties":true,"default":{},"description":"Settings for each extension.","type":"object"},"next":{"items":{"$ref":"#/$defs/NextOperation"},"type":"array"},"trace":{"anyOf":[{"$ref":"#/$defs/TraceToggle"},{"type":"null"}]}},"required":["next"],"type":"object"}}}')

}),

});
/************************************************************************/
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
id: moduleId,
loaded: false,
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Flag the module as loaded
module.loaded = true;
// Return the exports of the module
return module.exports;

}

// expose the modules object (__webpack_modules__)
__webpack_require__.m = __webpack_modules__;

/************************************************************************/
// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/create_fake_namespace_object
(() => {
var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
var leafPrototypes;
// create a fake namespace object
// mode & 1: value is a module id, require it
// mode & 2: merge all properties of value into the ns
// mode & 4: return value when already ns object
// mode & 16: return value when it's Promise-like
// mode & 8|1: behave like require
__webpack_require__.t = function(value, mode) {
	if(mode & 1) value = this(value);
	if(mode & 8) return value;
	if(typeof value === 'object' && value) {
		if((mode & 4) && value.__esModule) return value;
		if((mode & 16) && typeof value.then === 'function') return value;
	}
	var ns = Object.create(null);
  __webpack_require__.r(ns);
	var def = {};
	leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
	for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
		Object.getOwnPropertyNames(current).forEach((key) => { def[key] = () => (value[key]) });
	}
	def['default'] = () => (value);
	__webpack_require__.d(ns, def);
	return ns;
};
})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
// webpack/runtime/node_module_decorator
(() => {
__webpack_require__.nmd = (module) => {
  module.paths = [];
  if (!module.children) module.children = [];
  return module;
};
})();
// webpack/runtime/on_chunk_loaded
(() => {
var deferred = [];
__webpack_require__.O = (result, chunkIds, fn, priority) => {
	if (chunkIds) {
		priority = priority || 0;
		for (var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--)
			deferred[i] = deferred[i - 1];
		deferred[i] = [chunkIds, fn, priority];
		return;
	}
	var notFulfilled = Infinity;
	for (var i = 0; i < deferred.length; i++) {
		var [chunkIds, fn, priority] = deferred[i];
		var fulfilled = true;
		for (var j = 0; j < chunkIds.length; j++) {
			if (
				(priority & (1 === 0) || notFulfilled >= priority) &&
				Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))
			) {
				chunkIds.splice(j--, 1);
			} else {
				fulfilled = false;
				if (priority < notFulfilled) notFulfilled = priority;
			}
		}
		if (fulfilled) {
			deferred.splice(i--, 1);
			var r = fn();
			if (r !== undefined) result = r;
		}
	}
	return result;
};

})();
// webpack/runtime/rspack_version
(() => {
__webpack_require__.rv = () => ("1.3.11")
})();
// webpack/runtime/jsonp_chunk_loading
(() => {

      // object to store loaded and loading chunks
      // undefined = chunk not loaded, null = chunk preloaded/prefetched
      // [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
      var installedChunks = {"1": 0,};
      __webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
// install a JSONP callback for chunk loading
var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
	var [chunkIds, moreModules, runtime] = data;
	// add "moreModules" to the modules object,
	// then flag all "chunkIds" as loaded and fire callback
	var moduleId, chunkId, i = 0;
	if (chunkIds.some((id) => (installedChunks[id] !== 0))) {
		for (moduleId in moreModules) {
			if (__webpack_require__.o(moreModules, moduleId)) {
				__webpack_require__.m[moduleId] = moreModules[moduleId];
			}
		}
		if (runtime) var result = runtime(__webpack_require__);
	}
	if (parentChunkLoadingFunction) parentChunkLoadingFunction(data);
	for (; i < chunkIds.length; i++) {
		chunkId = chunkIds[i];
		if (
			__webpack_require__.o(installedChunks, chunkId) &&
			installedChunks[chunkId]
		) {
			installedChunks[chunkId][0]();
		}
		installedChunks[chunkId] = 0;
	}
	return __webpack_require__.O(result);
};

var chunkLoadingGlobal = self["webpackChunkdiagram_editor"] = self["webpackChunkdiagram_editor"] || [];
chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));

})();
// webpack/runtime/rspack_unique_id
(() => {
__webpack_require__.ruid = "bundler=rspack@1.3.11";

})();
/************************************************************************/
// startup
// Load entry module and return exports
// This entry module depends on other loaded chunks and execution need to be delayed
var __webpack_exports__ = __webpack_require__.O(undefined, ["2", "0"], function() { return __webpack_require__(0) });
__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
})()
;
//# sourceMappingURL=index.js.map